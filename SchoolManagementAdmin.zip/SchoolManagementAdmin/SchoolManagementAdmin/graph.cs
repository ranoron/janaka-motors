﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace SchoolManagementAdmin
{
    public partial class graph : Form
    {
        public graph(string uname)
        {
            InitializeComponent();
            txt_uname.Text = uname;
        }

        private void button1_Click(object sender, EventArgs e)
        {
           

        }

        private void graph_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");

                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("Select * from stock_table", con);
                SqlDataReader dr;
                con.Open();
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    this.chart1.Series["stock"].Points.AddXY(dr["item_name"].ToString(), dr["remaining"].ToString());
                    //this.chart1.Series["total"].Points.AddXY(dr["item_name"].ToString(), dr["Total_purchas"].ToString());


                }
            }
            catch (SqlException ee)
            {
                MessageBox.Show("error" + ee);
            }

        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            frmMain frm = new frmMain(txt_uname.Text);
            frm.Show();
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }
    }
}
