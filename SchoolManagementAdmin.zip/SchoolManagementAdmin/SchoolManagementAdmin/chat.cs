﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

using System.Net;
using System.Net.Sockets;


namespace SchoolManagementAdmin
{
    public partial class chat : Form
    {
        Socket sck;
        EndPoint eplocal, epremort;
        public chat()
        {
            InitializeComponent();

            sck = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            sck.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);

            txt_localip.Text = getlocalip();
            txt_friendip.Text = getlocalip();
        }

        private string getlocalip()
        {
            IPHostEntry host;
            host = Dns.GetHostEntry(Dns.GetHostName());

            foreach (IPAddress ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork )
                {
                    return ip.ToString();
                }
            }
            return "127.0.0.1";
        } 

        private void messagecallback(IAsyncResult aResult)
        {
            try
            {
                int size = sck.EndReceiveFrom(aResult, ref epremort);
                if (size > 0)
                {
                    byte[] receivedata = new byte[1464];
                    receivedata = (byte[])aResult.AsyncState;

                    ASCIIEncoding eEncoding = new ASCIIEncoding();
                    string receivedmessege = eEncoding.GetString(receivedata);

                    listBox1.Items.Add("friend  :" + receivedmessege);

                }
                byte[] buffer = new byte[1500];
                sck.BeginReceiveFrom(buffer, 0, buffer.Length, SocketFlags.None, ref epremort, new AsyncCallback(messagecallback), buffer);

            }
            catch (SqlException ee)
            {
                MessageBox.Show("error" + ee);
            }
        }

        private void chat_Load(object sender, EventArgs e)
        { 

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                eplocal = new IPEndPoint(IPAddress.Parse(txt_localip.Text), Convert.ToInt32(txt_localport.Text));
                sck.Bind(eplocal);

                epremort  = new IPEndPoint(IPAddress.Parse(txt_friendip.Text), Convert.ToInt32(txt_friendport.Text));
                sck.Connect(epremort);  

                byte[] buffer = new byte[1500];
                sck.BeginReceiveFrom(buffer, 0, buffer.Length, SocketFlags.None, ref epremort, new AsyncCallback(messagecallback), buffer);
                button1.Text = "conected";
            }
            catch (SqlException ee)
            {
                MessageBox.Show("error" + ee);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                System.Text.ASCIIEncoding enc = new ASCIIEncoding();
                byte[] msg = new byte[1500];
                msg = enc.GetBytes(textBox5.Text);

                sck.Send(msg);

                listBox1.Items.Add("Me  :" + textBox5.Text);
                textBox5.Clear();
            }
            catch (SqlException ee)
            {
                MessageBox.Show("error" + ee);
            }
        }
    }
}
