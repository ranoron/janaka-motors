﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;



namespace SchoolManagementAdmin
{
    public partial class frmMain : Form
    {
        public frmMain(string username)
        {
            InitializeComponent();
            txtunamemain.Text = username;
        }

        //For animated panels direction
        string optionsDirection = "down";
        string toastDirection = "down";
        string rightDirection = "right";

        //For animated panels timeout
       int optionsTimeOut = 0;
        int toastTimeOut = 0;
        int RightTimeOut = 0;

        //For animated panels position
       
        int rightX;
        int rightY;

        //method to set fullscreen
        private void setFullScreen()
        {
            int x = Screen.PrimaryScreen.Bounds.Width;
            int y = Screen.PrimaryScreen.Bounds.Height;
            Location = new Point(0, 0);
            Size = new Size(x, y);
        }

        //method to set the position of the main panel that holds the controls to center of the form.
        private void setMainPanelPosition()
        {
            int mX = (Width - pnlMain.Width) / 2;
            int mY = (Height - pnlMain.Height) / 2;
            pnlMain.Location = new Point(mX, mY);
        }

        private void setRightOptionsPanelPosition()
        {
            int y = Height;
            rightY = 0;
            rightX = Width + pnlRightOptions.Width;
            pnlRightOptions.Size = new Size(pnlRightOptions.Width, y);
            pnlRightOptions.Location = new Point(rightX, rightY);
            int rX = pnlRightMain.Location.X;
            int rY = (pnlRightOptions.Height - pnlRightMain.Height) / 2;
            pnlRightMain.Location = new Point(rX, rY);
        }
        // load the users first name and last name 
        private void frmMain_Load(object sender, EventArgs e)
        {
            setFullScreen();
            setRightOptionsPanelPosition();
            setMainPanelPosition();
            RightOptions.Start();
            FirstColumn.Start();

            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("Select * from staff_table where uname = '" + txtunamemain.Text + "'", con);
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    lbluname_main.Text = dr["fname"].ToString();
                    lbl2name.Text = dr["lname"].ToString();
                }
                con.Close();
            }
            catch (SqlException ee)
            {
                MessageBox.Show("" + ee);
            }

            //limitation for staffs and admin
                if (txtunamemain.Text == "admin")
                {
                    pbproduct.Enabled = true;
                    pictureBox2.Enabled = true;
                    pbAttendance.Enabled = true;
                    pbEmployees.Enabled = true;
                    
                    pictureBox3.Enabled = true;
                    lblMainTitle.Text = "janaka motors admin Mode Activated !!! ";
                }

        }

        // panal moving section  
        private void frmMain_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Y >= Height - 15 && e.X < (Width - pnlRightOptions.Width))
            {
                optionsDirection = "up";
                rightDirection = "right";
                optionsTimeOut = 0;
            }
            if (e.X >= Width - 15)
            {
                rightDirection = "left";
                RightTimeOut = 0;
                optionsDirection = "down";
            }
            if (e.X < (Width - pnlRightOptions.Width))
            {
                rightDirection = "Left";
            }
        }

        private void Options_Tick(object sender, EventArgs e)
        {

        }

        private void RightOptions_Tick(object sender, EventArgs e)
        {
            if (RightTimeOut < 1000)
            {
                RightTimeOut++;
            }
            if (RightTimeOut == 1000)
            {
                if (rightDirection == "left")
                {
                    rightDirection = "right";
                }
            }
            if (rightDirection == "left")
            {
                if (rightX > Width - pnlRightOptions.Width)
                {
                    rightX -= 2;
                    pnlRightOptions.Location = new Point(rightX, rightY);
                }
            }
            else
            {
                if (rightX < Width)
                {
                    rightX += 2;
                }
                pnlRightOptions.Location = new Point(rightX, rightY);
            }
        }

      

        private void pbExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pbHome_Click(object sender, EventArgs e)
        {
            rightDirection = "right";
        }

        private void FirstColumn_Tick(object sender, EventArgs e)
        {
            if (pnlproduct.BackColor == Color.Crimson)
            {
                pnlproduct.BackColor = Color.Red;
                pnlEmployees.BackColor = Color.Blue;
               
                pnlAttendance.BackColor = Color.Green;
                pnlAccounts.BackColor = Color.Crimson;
               
            }
            else if (pnlproduct.BackColor == Color.Red)
            {
                pnlproduct.BackColor = Color.Blue;
                pnlEmployees.BackColor = Color.DarkOrange;
             
                pnlAttendance.BackColor = Color.Crimson;
                pnlAccounts.BackColor = Color.Red;
              
            }
            else if (pnlproduct.BackColor == Color.Blue)
            {
                pnlproduct.BackColor = Color.DarkOrange;
                pnlEmployees.BackColor = Color.Purple;
              
                pnlAttendance.BackColor = Color.Red;
                pnlAccounts.BackColor = Color.Blue;
            }
            else if (pnlproduct.BackColor == Color.DarkOrange)
            {
                pnlproduct.BackColor = Color.Purple;
                pnlEmployees.BackColor = Color.Crimson;
              
                pnlAttendance.BackColor = Color.Blue;
                pnlAccounts.BackColor = Color.DarkOrange;
               
            }
            else
            {
                pnlproduct.BackColor = Color.Crimson;
                pnlEmployees.BackColor = Color.Red;
               
                pnlAttendance.BackColor = Color.DarkOrange;
                pnlAccounts.BackColor = Color.Purple;
            }
        }

        private void pbproduct_Click(object sender, EventArgs e)
        {
            product frm = new product(txtunamemain.Text);
            frm.Show();
            this.Hide();
        }

        private void pnlMain_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pbAttendance_Click(object sender, EventArgs e)
        {
            product frm = new product("staff");
            frm.Show();
            this.Hide();
        }

        private void pbReports_Click(object sender, EventArgs e)
        {
            buy frm = new buy(txtunamemain.Text);
            frm.Show();

        }

        private void pbAccounts_Click(object sender, EventArgs e)
        {
            product_stock frm = new product_stock(txtunamemain.Text);
            frm.Show();
        }

        private void pbSearch_Click(object sender, EventArgs e)
        {
            selling frm = new selling(txtunamemain.Text);
            frm.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            mail frm = new mail();
            frm.Show();
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            notification frm = new notification();
            frm.Show();

        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            product frm = new product("admin");
            frm.Show();

        }

        private void pbRestore_Click(object sender, EventArgs e)
        {
            graph frm = new graph(txtunamemain.Text);
            frm.Show();
        }

        private void pbEmployees_Click(object sender, EventArgs e)
        {
            product frm = new product("dealer");
            frm.Show();
        }

        private void pbLogout_Click(object sender, EventArgs e)
        {
            login frm = new login();
            frm.Show();
            this.Hide();
        }

        private void picbox_stock2_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            selling_history frm = new selling_history(txtunamemain.Text);
            frm.Show();
            
        }

        private void pbBackup_Click(object sender, EventArgs e)
        {
            camara frm = new camara();
            frm.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            chat frm = new chat();
            frm.Show();
           // this.Hide();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            chat frm = new chat();
            frm.Show();
        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {

        }

       
    }
}
