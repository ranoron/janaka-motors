﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Web;
using System.Net.Mail;
using System.Data.SqlClient;

namespace SchoolManagementAdmin
{
    public partial class mail : Form
    {
       // private object p;

        public mail()
        {
            InitializeComponent();
           
        }

       // public mail(object p)
        //{
            // TODO: Complete member initialization
         //   this.p = p;
        //}

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (txt_to.Text == "")
            {
                MessageBox.Show("Enter The Reciver's Mail ID To Send ");
            }
               
            else
            {
                if (attachment1.Text != "")
                {

                    MailMessage mail = new MailMessage(txt_from.Text, txt_to.Text, txt_sub.Text, richTextBox1.Text);

                    // this line for attachment 
                    mail.Attachments.Add(new Attachment(attachment1.Text));
                    SmtpClient client = new SmtpClient(txt_amtp.Text);
                    client.Port = 587;
                    client.Credentials = new System.Net.NetworkCredential(uname.Text, pwd.Text);
                    client.EnableSsl = true;
                    client.Send(mail);
                    DialogResult Confirmation;
                    Confirmation = MessageBox.Show("Mail Send Succesfully Do You Wants To Send Another?", "Remove", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (Confirmation == DialogResult.Yes)
                    {
                        txt_to.Text = "";
                        txt_sub.Text = "";
                        pictureBox2.SendToBack();
                    }

                    else
                    {
                        this.Close();


                    }
                    // MessageBox.Show("mail was send ");
                    // label8.Text = "DONE!";
                    //label8.BringToFront();
                }


                else
                {
                    MailMessage mail = new MailMessage(txt_from.Text, txt_to.Text, txt_sub.Text, richTextBox1.Text);

                    // this line for attachment 
                    // mail.Attachments.Add(new Attachment(attachment1.Text));
                    SmtpClient client = new SmtpClient(txt_amtp.Text);
                    client.Port = 587;
                    client.Credentials = new System.Net.NetworkCredential(uname.Text, pwd.Text);
                    client.EnableSsl = true;
                    client.Send(mail);
                    DialogResult Confirmation;
                    Confirmation = MessageBox.Show("Mail Send Succesfully Do You Wants To Send Another?", "Remove", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (Confirmation == DialogResult.Yes)
                    {
                        txt_to.Text = "";
                        txt_sub.Text = "";
                        pictureBox2.SendToBack();
                    }

                    else
                    {

                        this.Close();


                    }
                    // MessageBox.Show("mail was send ");
                    // label8.Text = "DONE!";
                    //label8.BringToFront();
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
           
            
            
            
            OpenFileDialog opg = new OpenFileDialog();
            opg.Filter = "Image files: (*.jpg)|*.jpg|(*.jpeg)|*.jpeg|(*.png)|*.png|(*.Gif)|*.Gif|(*.bmp)|*.bmp| All Files (*.*)|*.*";
            if (opg.ShowDialog() == DialogResult.OK)
            {
                string path = opg.FileName.ToString();
                pictureBox1.ImageLocation = path;
                attachment1.Text = path;
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void mail_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("select * from dealer_table", con);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {

                    cmbo_Vendor.Items.Add(dr["name"].ToString());
                 
                }
            }
            catch (SqlException ee)
            {
                MessageBox.Show("" + ee);
            }
        }

        private void txt_to_Validating(object sender, CancelEventArgs e)
        {
            if (txt_to.Text == "")
            {
                txt_to.BackColor = System.Drawing.Color.LightPink;
            }

            else
            {
                txt_to.BackColor = System.Drawing.Color.Gainsboro;
            }
        }

        private void txt_to_KeyPress(object sender, KeyPressEventArgs e)
        {
            txt_to.BackColor = System.Drawing.Color.Gainsboro;
        }

        private void txt_sub_Validating(object sender, CancelEventArgs e)
        {
            if (txt_sub.Text == "")
            {
                txt_sub.BackColor = System.Drawing.Color.LightPink;
            }

            else
            {
                txt_sub.BackColor = System.Drawing.Color.Gainsboro;
            }
        }

        private void txt_sub_KeyPress(object sender, KeyPressEventArgs e)
        {
            txt_sub.BackColor = System.Drawing.Color.Gainsboro;
        }

        private void cmbo_Vendor_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("select * from dealer_table where name='"+cmbo_Vendor.Text+"'", con);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {

                    txt_to.Text = dr["email"].ToString();
                }
            }
            catch (SqlException ee)
            {
                MessageBox.Show("" + ee);
            }
        }
    }
}
