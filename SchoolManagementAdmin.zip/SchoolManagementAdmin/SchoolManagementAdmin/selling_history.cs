﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

using ExcelLibrary.CompoundDocumentFormat;
using ExcelLibrary.SpreadSheet;
using ExcelLibrary.BinaryDrawingFormat;
using ExcelLibrary.BinaryFileFormat;

namespace SchoolManagementAdmin
{
    public partial class selling_history : Form
    {
        public selling_history(string uname)
        {
            InitializeComponent();
            txt_uname.Text = uname;
        }
        DataTable dbdataset;
        private void total()
        {
            try
            {
                int sum = 0;


                for (int i = 0; i < dataGridView1.Rows.Count; ++i)
                {
                    sum += Convert.ToInt32(dataGridView1.Rows[i].Cells[7].Value);
                }
                int counting_row = dataGridView1.Rows.Count;

                double avg = sum / counting_row;
                txt_avg.Text = avg.ToString();
                txt_total.Text = sum.ToString();
            }
            catch (SqlException ee)
            {
                MessageBox.Show("error" + ee);

            }
        }
        private void button11_Click(object sender, EventArgs e)
        {
            this.Hide();

        }

        private void selling_history_Load(object sender, EventArgs e)
        {
            
            this.selling_historyTableAdapter.Fill(this.janaka_dbDataSet2.selling_history);

            total();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                this.selling_historyTableAdapter.FillBy(this.janaka_dbDataSet2.selling_history, dateTimePicker1.Text, dateTimePicker2.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            total();
        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
           

        }

        private void fillByToolStripButton_Click_1(object sender, EventArgs e)
        {
           

        }

        private void button2_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Bitmap bm = new Bitmap(this.dataGridView1.Width, this.dataGridView1.Height);
            dataGridView1.DrawToBitmap(bm, new Rectangle(0, 0, this.dataGridView1.Width, this.dataGridView1.Height));
            e.Graphics.DrawImage(bm, 0, 0);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("Select * from selling_history", con);

                SqlDataAdapter sda = new SqlDataAdapter();
                sda.SelectCommand = cmd;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource bsource = new BindingSource();

                DataSet ds = new DataSet("New Dataset");
                ds.Locale = System.Threading.Thread.CurrentThread.CurrentCulture;
                sda.Fill(dbdataset);
                ds.Tables.Add(dbdataset);
                ExcelLibrary.DataSetHelper.CreateWorkbook("D:\\janaka\\selling_History.xls", ds);
                //MessageBox.Show("xls file saved in 'D:\\janaka\\selling_History.xls' ");
                pictureBox1.BringToFront();
                label7.BringToFront();
                button4.BringToFront();
            }
            catch (SqlException ee)
            {
                MessageBox.Show("error" + ee);
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            dataGridView1.BringToFront();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            DataView dv = new DataView(dbdataset);
            dv.RowFilter = string.Format("item_name LIKE '%{0}%'", textBox1.Text);
            dataGridView1.DataSource = dv;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            DataView dv = new DataView(dbdataset);
            dv.RowFilter = string.Format("item_id LIKE '%{0}%'", textBox2.Text);
            dataGridView1.DataSource = dv;
        }
    }
}
