﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

using System.Configuration;

namespace SchoolManagementAdmin
{
    public partial class buy : Form
    {
        public buy(string uname)
        {
            InitializeComponent();
            txt_uname.Text = uname;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            frmMain frm = new frmMain(txt_uname.Text);
            frm.Show();

        }

       
        

        private void send_grid()
        {
            int n = dataGridView1.Rows.Add();
            dataGridView1.Rows[n].Cells[0].Value = txt_uname.Text;
            dataGridView1.Rows[n].Cells[1].Value = cmbo_vendor_name.Text;
            dataGridView1.Rows[n].Cells[2].Value = cmbo_item_id.Text;
            dataGridView1.Rows[n].Cells[3].Value = cmbo_item_name.Text;
            dataGridView1.Rows[n].Cells[4].Value = txt_price.Text;
            dataGridView1.Rows[n].Cells[5].Value = txt_quantity.Text;
            dataGridView1.Rows[n].Cells[6].Value = txt_discount.Text;
            dataGridView1.Rows[n].Cells[7].Value = lbl_total.Text;
            btn_clear.Focus();
        }

        private void update_amount()
        {

            
                int old_amount,new_amount,net;
                old_amount = Convert.ToInt32(total_pur.Text);
                new_amount = Convert.ToInt32(txt_quantity.Text);
                net = old_amount+new_amount;

        
            try
            {

                int remain, amount, remain_total;
                remain = Convert.ToInt32(txt_quantity.Text);
                amount = Convert.ToInt32(txt_item_left.Text);

                remain_total = remain + amount;
                lbl_item_left.Text = remain_total.ToString();

                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("update stock_table set remaining ='" + lbl_item_left.Text + "',Total_purchas = '"+net+"' where item_id= '" + cmbo_item_id.Text + "'", con);
                cmd.ExecuteNonQuery();
                con.Close();
               // MessageBox.Show("stock updated ");
            }

            catch (SqlException error)
            {
                MessageBox.Show("error" + error);
            }

        }

        private void save_data()
        {
            int item_id, price, qty1, discount, total5;

            item_id = Convert.ToInt32(cmbo_item_id.Text);
            price = Convert.ToInt32(txt_price.Text);
            qty1 = Convert.ToInt32(txt_quantity.Text);
            discount = Convert.ToInt32(txt_discount.Text);

            total5 = Convert.ToInt32(lbl_total1.Text);
            DateTime date1 = DateTime.Parse(date_picker.Text);


            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();

                cmd = new SqlCommand("insert into purchasing_history (staff_incharge,item_id,item_name,vendor_name,price,discount,quantity,payment_type,total,date)values('" + txt_uname.Text + "',"
                                                                                                                    + item_id + ",'"
                                                                                                                    + cmbo_item_name.Text + "','"
                                                                                                                    + cmbo_vendor_name.Text + "',"
                                                                                                                    + price + ","
                                                                                                                    + discount + ","
                                                                                                                    + qty1 + ",'"
                                                                                                                    + cmbo_payment.Text + "',"
                                                                                                                    + total5 + ",'"+date1+"')", con);


                cmd.ExecuteNonQuery();

                con.Close();
               // MessageBox.Show("done");


            }
            catch (SqlException ee)
            {
                MessageBox.Show("error" + ee);
            }
        }
        private void load_vendor()
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("select * from dealer_table", con);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {

                    cmbo_vendor_name.Items.Add(dr["name"].ToString());

                }
            }
            catch (SqlException ee)
            {
                MessageBox.Show("error" + ee);
            }
        }
        private void button12_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void buy_Load(object sender, EventArgs e)
        {
            load_vendor();
            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("select * from product_table", con);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {

                    // cmbo_item_id.Items.Add(dr["id"].ToString());
                    cmbo_item_name.Items.Add(dr["name"].ToString());


                }
            }
            catch (SqlException ee)
            {
                MessageBox.Show("" + ee);
            }
        }

        private void cmbo_buy_id_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbo_item_name_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("select * from product_table where name='" + cmbo_item_name.Text + "';", con);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {

                    txt_price.Text = dr["price"].ToString();
                    txt_discount.Text = dr["discount"].ToString();
                    //cmbo_item_name.Text = dr["name"].ToString();
                    cmbo_item_id.Text = dr["id"].ToString();
                    txt_standert.Text = dr["standerd"].ToString();

                }
            }
            catch (SqlException ee)
            {
                MessageBox.Show("" + ee);
            }


            // select the items remaining 
            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("select * from stock_table where item_id='" + cmbo_item_id.Text + "'", con);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {

                    txt_item_left.Text = dr["remaining"].ToString();
                    total_pur.Text = dr["Total_purchas"].ToString();

                }
            }
            catch (SqlException ee)
            {
                MessageBox.Show("" + ee);
            }

            total_pur.Text = "0";
        }



        private void cmbo_item_id_SelectedValueChanged(object sender, EventArgs e)
        {


        }

        private void cmbo_vendor_name_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbo_vendor_name_SelectedValueChanged(object sender, EventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {

            
        }

        
        private void txt_quantity_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyValue == 13)
            {
                int price, amount, total, discount, discount2, gtotal, total2, totalg;
                try
                {
                    price = Convert.ToInt32(txt_price.Text);
                    amount = Convert.ToInt32(txt_quantity.Text);
                    discount = Convert.ToInt32(txt_discount.Text);
                    total2 = Convert.ToInt32(lbl_total1.Text);

                    total = price * amount;
                    first_total.Text = total.ToString();
                    discount2 = total * discount / 100;
                    lbl_discount.Text = discount2.ToString();
                    gtotal = total - discount2;
                    lbl_total.Text = gtotal.ToString();
                    totalg = gtotal + total2;
                    lbl_total1.Text = totalg.ToString();
                    //button14.Focus();

                    update_amount();
                    send_grid();
                    cash_amount.Focus();
                    save_data();

                }

                catch (SqlException ee)
                {
                    MessageBox.Show("please enter the amount and price " + ee);

                }
                
                
            }
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {

            cmbo_item_id.Text = "";
            cmbo_item_id.Items.Clear();

            lbl_discount.Text = "";
            cmbo_item_name.Text = "";
            txt_price.Text = "";
            txt_quantity.Text = "";
            txt_discount.Text = "";
            lbl_total.Text = "";
            cmbo_vendor_name.Text = "";
            lbl_item_left.Text = "";
            first_total.Text = "";
            txt_item_left.Text = "";
            lbl_total1.Text = "";
            lbl_balance.Text = "";
            cash_amount.Text = "";
            dataGridView1.Rows.Clear();
        }

        private void delete_Click(object sender, EventArgs e)
        {

        }
        

        private void cash_amount_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == 13)

                if (cash_amount.Text != "")
                {
                    int cash, total, balance;

                    total = Convert.ToInt32(lbl_total1.Text);
                    cash = Convert.ToInt32(cash_amount.Text);
                    DateTime date = DateTime.Parse(date_picker.Text);

                    balance = total - cash;
                    lbl_balance.Text = balance.ToString();
                    btn_clear.Focus();
                    //save_data();
                    //update_amount();
                    

                    
                }

                //if (cash_amount.Text == "")
                // MessageBox.Show("Paid Amount Empty");
                else

                {
                    DialogResult Confirmation;
                    Confirmation = MessageBox.Show("Cash Amount Is Empty Do You Like To Add Another Item", "Remove", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (Confirmation == DialogResult.Yes)
                    {
                        save_data();
                        cmbo_item_id.Text = "";
                        cmbo_item_id.Items.Clear();
                        lbl_discount.Text = "";
                        cmbo_item_name.Text = "";
                        txt_price.Text = "";
                        txt_quantity.Text = "";
                        txt_discount.Text = "";
                        lbl_total.Text = "";
                        cmbo_vendor_name.Text = "";
                        lbl_item_left.Text = "";
                        first_total.Text = "";
                        txt_item_left.Text = "";
                    }
                    //if (Confirmation == DialogResult.No)
                    else
                    {
                        cash_amount.Focus();
                       
                    }
                    
                }
    }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}


