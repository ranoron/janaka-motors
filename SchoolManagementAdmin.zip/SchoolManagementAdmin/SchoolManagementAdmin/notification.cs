﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace SchoolManagementAdmin
{
    public partial class notification : Form
    {
        public notification()
        {
            InitializeComponent();
        }

        


        private void notification_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'janaka_dbDataSet.stock_table' table. You can move, or remove it, as needed.
            this.stock_tableTableAdapter.Fill(this.janaka_dbDataSet.stock_table);
            try
            {
                this.stock_tableTableAdapter.FillBy11(this.janaka_dbDataSet.stock_table);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

       
        }

        private void fillBy1ToolStripButton_Click(object sender, EventArgs e)
        {
            

        }

        private void fillBy1ToolStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
           
        }

        private void fillByToolStripButton1_Click(object sender, EventArgs e)
        {
           
        }

        private void fillByToolStripButton_Click_1(object sender, EventArgs e)
        {
            

        }

        private void fillBy1ToolStripButton_Click_1(object sender, EventArgs e)
        {
           

        }

        private void fillBy2ToolStripButton_Click(object sender, EventArgs e)
        {
           

        }

        private void fillBy3ToolStripButton_Click(object sender, EventArgs e)
        {
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            mail frm = new mail();
            frm.Show();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void fillBy4ToolStripButton_Click(object sender, EventArgs e)
        {
            

        }

        private void fillBy1ToolStripButton_Click_2(object sender, EventArgs e)
        {
            try
            {
                this.stock_tableTableAdapter.FillBy1(this.janaka_dbDataSet.stock_table);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void fillBy1ToolStrip_ItemClicked_1(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void fillBy11ToolStripButton_Click(object sender, EventArgs e)
        {
            

        }
    }
}

