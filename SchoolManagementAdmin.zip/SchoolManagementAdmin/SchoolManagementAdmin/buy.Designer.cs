﻿namespace SchoolManagementAdmin
{
    partial class buy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(buy));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Qty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lbl_balance = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.cash_amount = new System.Windows.Forms.TextBox();
            this.lbl_item_left = new System.Windows.Forms.Label();
            this.first_total = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lbl_total1 = new System.Windows.Forms.Label();
            this.lbl_discount = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lbl_total = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbo_item_name = new System.Windows.Forms.ComboBox();
            this.cmbo_item_id = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_quantity = new System.Windows.Forms.TextBox();
            this.cmbo_vendor_name = new System.Windows.Forms.ComboBox();
            this.txt_item_left = new System.Windows.Forms.TextBox();
            this.txt_price = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_discount = new System.Windows.Forms.TextBox();
            this.Other = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.date_picker = new System.Windows.Forms.DateTimePicker();
            this.btn_clear = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_uname = new System.Windows.Forms.TextBox();
            this.txt_standert = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.total_pur = new System.Windows.Forms.Label();
            this.cmbo_payment = new System.Windows.Forms.ComboBox();
            this.button11 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.Other.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.lbl_item_left);
            this.groupBox1.Controls.Add(this.first_total);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.lbl_total1);
            this.groupBox1.Controls.Add(this.lbl_discount);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.lbl_total);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.cmbo_item_name);
            this.groupBox1.Controls.Add(this.cmbo_item_id);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.Other);
            this.groupBox1.Controls.Add(this.total_pur);
            this.groupBox1.Controls.Add(this.cmbo_payment);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 37);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1338, 608);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column3,
            this.Column7,
            this.Column1,
            this.Column2,
            this.Column5,
            this.Qty,
            this.Column6,
            this.Column4});
            this.dataGridView1.Location = new System.Drawing.Point(472, 23);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(847, 363);
            this.dataGridView1.TabIndex = 60;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Column3
            // 
            this.Column3.HeaderText = "staff Incharge";
            this.Column3.Name = "Column3";
            // 
            // Column7
            // 
            this.Column7.HeaderText = "Vendor";
            this.Column7.Name = "Column7";
            // 
            // Column1
            // 
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Transparent;
            this.Column1.DefaultCellStyle = dataGridViewCellStyle1;
            this.Column1.HeaderText = "Product ID";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Name";
            this.Column2.Name = "Column2";
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Unit Price";
            this.Column5.Name = "Column5";
            // 
            // Qty
            // 
            this.Qty.HeaderText = "Qty";
            this.Qty.Name = "Qty";
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Discount";
            this.Column6.Name = "Column6";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Grand Total";
            this.Column4.Name = "Column4";
            // 
            // label23
            // 
            this.label23.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(1184, 555);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(36, 23);
            this.label23.TabIndex = 74;
            this.label23.Text = "Rs.";
            // 
            // label22
            // 
            this.label22.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(893, 552);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(36, 23);
            this.label22.TabIndex = 73;
            this.label22.Text = "Rs.";
            // 
            // label21
            // 
            this.label21.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(893, 493);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(36, 23);
            this.label21.TabIndex = 72;
            this.label21.Text = "Rs.";
            // 
            // label20
            // 
            this.label20.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(893, 442);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(36, 23);
            this.label20.TabIndex = 71;
            this.label20.Text = "Rs.";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.lbl_balance);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.cash_amount);
            this.groupBox3.Location = new System.Drawing.Point(460, 404);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(324, 192);
            this.groupBox3.TabIndex = 60;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Payment ";
            // 
            // label19
            // 
            this.label19.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(133, 123);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(36, 23);
            this.label19.TabIndex = 71;
            this.label19.Text = "Rs.";
            // 
            // label16
            // 
            this.label16.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(133, 47);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(36, 23);
            this.label16.TabIndex = 70;
            this.label16.Text = "Rs.";
            // 
            // lbl_balance
            // 
            this.lbl_balance.BackColor = System.Drawing.Color.Gainsboro;
            this.lbl_balance.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_balance.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_balance.Location = new System.Drawing.Point(171, 102);
            this.lbl_balance.Name = "lbl_balance";
            this.lbl_balance.Size = new System.Drawing.Size(144, 50);
            this.lbl_balance.TabIndex = 69;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(1, 112);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(78, 25);
            this.label17.TabIndex = 43;
            this.label17.Text = "Balance";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(1, 41);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(125, 25);
            this.label14.TabIndex = 41;
            this.label14.Text = "Cash Amount";
            // 
            // cash_amount
            // 
            this.cash_amount.Location = new System.Drawing.Point(171, 44);
            this.cash_amount.Name = "cash_amount";
            this.cash_amount.Size = new System.Drawing.Size(144, 25);
            this.cash_amount.TabIndex = 1;
            this.cash_amount.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cash_amount_KeyDown);
            // 
            // lbl_item_left
            // 
            this.lbl_item_left.BackColor = System.Drawing.Color.Gainsboro;
            this.lbl_item_left.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_item_left.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_item_left.Location = new System.Drawing.Point(1221, 473);
            this.lbl_item_left.Name = "lbl_item_left";
            this.lbl_item_left.Size = new System.Drawing.Size(111, 43);
            this.lbl_item_left.TabIndex = 68;
            // 
            // first_total
            // 
            this.first_total.BackColor = System.Drawing.Color.Gainsboro;
            this.first_total.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.first_total.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.first_total.Location = new System.Drawing.Point(935, 422);
            this.first_total.Name = "first_total";
            this.first_total.Size = new System.Drawing.Size(111, 43);
            this.first_total.TabIndex = 67;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(1052, 478);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(93, 25);
            this.label15.TabIndex = 66;
            this.label15.Text = "Items Left";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(788, 429);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(87, 25);
            this.label13.TabIndex = 66;
            this.label13.Text = "Total    =";
            // 
            // lbl_total1
            // 
            this.lbl_total1.BackColor = System.Drawing.Color.Gainsboro;
            this.lbl_total1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_total1.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_total1.Location = new System.Drawing.Point(1221, 543);
            this.lbl_total1.Name = "lbl_total1";
            this.lbl_total1.Size = new System.Drawing.Size(111, 43);
            this.lbl_total1.TabIndex = 65;
            this.lbl_total1.Text = "0";
            // 
            // lbl_discount
            // 
            this.lbl_discount.BackColor = System.Drawing.Color.Gainsboro;
            this.lbl_discount.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_discount.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_discount.Location = new System.Drawing.Point(935, 483);
            this.lbl_discount.Name = "lbl_discount";
            this.lbl_discount.Size = new System.Drawing.Size(111, 43);
            this.lbl_discount.TabIndex = 64;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(788, 488);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(109, 25);
            this.label12.TabIndex = 63;
            this.label12.Text = "Discount   -";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(1051, 550);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(129, 25);
            this.label11.TabIndex = 62;
            this.label11.Text = "Grand Total =";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(788, 548);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(112, 25);
            this.label10.TabIndex = 57;
            this.label10.Text = "Net Total  =";
            // 
            // lbl_total
            // 
            this.lbl_total.BackColor = System.Drawing.Color.Gainsboro;
            this.lbl_total.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_total.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_total.Location = new System.Drawing.Point(935, 543);
            this.lbl_total.Name = "lbl_total";
            this.lbl_total.Size = new System.Drawing.Size(111, 43);
            this.lbl_total.TabIndex = 61;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(24, 260);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(84, 25);
            this.label8.TabIndex = 40;
            this.label8.Text = "Quantity";
            // 
            // cmbo_item_name
            // 
            this.cmbo_item_name.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_item_name.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_item_name.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbo_item_name.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_item_name.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_item_name.FormattingEnabled = true;
            this.cmbo_item_name.Location = new System.Drawing.Point(176, 73);
            this.cmbo_item_name.Name = "cmbo_item_name";
            this.cmbo_item_name.Size = new System.Drawing.Size(264, 29);
            this.cmbo_item_name.TabIndex = 1;
            this.cmbo_item_name.SelectedIndexChanged += new System.EventHandler(this.cmbo_item_name_SelectedIndexChanged);
            // 
            // cmbo_item_id
            // 
            this.cmbo_item_id.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_item_id.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_item_id.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbo_item_id.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_item_id.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_item_id.FormattingEnabled = true;
            this.cmbo_item_id.Location = new System.Drawing.Point(176, 34);
            this.cmbo_item_id.Name = "cmbo_item_id";
            this.cmbo_item_id.Size = new System.Drawing.Size(264, 29);
            this.cmbo_item_id.TabIndex = 0;
            this.cmbo_item_id.SelectedIndexChanged += new System.EventHandler(this.cmbo_buy_id_SelectedIndexChanged);
            this.cmbo_item_id.SelectedValueChanged += new System.EventHandler(this.cmbo_item_id_SelectedValueChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(24, 224);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 25);
            this.label5.TabIndex = 4;
            this.label5.Text = "Discount";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(24, 153);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Price";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(24, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Item Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(24, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Item ID";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.txt_quantity);
            this.groupBox2.Controls.Add(this.cmbo_vendor_name);
            this.groupBox2.Controls.Add(this.txt_item_left);
            this.groupBox2.Controls.Add(this.txt_price);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.txt_discount);
            this.groupBox2.Location = new System.Drawing.Point(9, 11);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(445, 307);
            this.groupBox2.TabIndex = 42;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Item Specifaction ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(15, 177);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(144, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "Item Remaining";
            // 
            // txt_quantity
            // 
            this.txt_quantity.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_quantity.Location = new System.Drawing.Point(167, 252);
            this.txt_quantity.Name = "txt_quantity";
            this.txt_quantity.Size = new System.Drawing.Size(264, 33);
            this.txt_quantity.TabIndex = 4;
            this.txt_quantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_quantity.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_quantity_KeyDown);
            // 
            // cmbo_vendor_name
            // 
            this.cmbo_vendor_name.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_vendor_name.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_vendor_name.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbo_vendor_name.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_vendor_name.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_vendor_name.FormattingEnabled = true;
            this.cmbo_vendor_name.Location = new System.Drawing.Point(167, 102);
            this.cmbo_vendor_name.Name = "cmbo_vendor_name";
            this.cmbo_vendor_name.Size = new System.Drawing.Size(262, 29);
            this.cmbo_vendor_name.TabIndex = 0;
            this.cmbo_vendor_name.SelectedIndexChanged += new System.EventHandler(this.cmbo_vendor_name_SelectedIndexChanged);
            this.cmbo_vendor_name.SelectedValueChanged += new System.EventHandler(this.cmbo_vendor_name_SelectedValueChanged);
            // 
            // txt_item_left
            // 
            this.txt_item_left.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_item_left.Location = new System.Drawing.Point(167, 180);
            this.txt_item_left.Name = "txt_item_left";
            this.txt_item_left.Size = new System.Drawing.Size(264, 33);
            this.txt_item_left.TabIndex = 2;
            this.txt_item_left.Text = "0";
            this.txt_item_left.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt_price
            // 
            this.txt_price.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_price.Location = new System.Drawing.Point(167, 143);
            this.txt_price.Name = "txt_price";
            this.txt_price.Size = new System.Drawing.Size(264, 33);
            this.txt_price.TabIndex = 1;
            this.txt_price.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(15, 102);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(129, 25);
            this.label9.TabIndex = 33;
            this.label9.Text = "Vendor Name";
            // 
            // txt_discount
            // 
            this.txt_discount.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_discount.Location = new System.Drawing.Point(167, 216);
            this.txt_discount.Name = "txt_discount";
            this.txt_discount.Size = new System.Drawing.Size(264, 33);
            this.txt_discount.TabIndex = 3;
            this.txt_discount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Other
            // 
            this.Other.Controls.Add(this.label18);
            this.Other.Controls.Add(this.date_picker);
            this.Other.Controls.Add(this.btn_clear);
            this.Other.Controls.Add(this.label6);
            this.Other.Controls.Add(this.txt_uname);
            this.Other.Controls.Add(this.txt_standert);
            this.Other.Controls.Add(this.label7);
            this.Other.Controls.Add(this.button14);
            this.Other.Location = new System.Drawing.Point(9, 324);
            this.Other.Name = "Other";
            this.Other.Size = new System.Drawing.Size(445, 249);
            this.Other.TabIndex = 43;
            this.Other.TabStop = false;
            this.Other.Text = "Other";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(15, 121);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(163, 25);
            this.label18.TabIndex = 61;
            this.label18.Text = "Date Of Purchase ";
            // 
            // date_picker
            // 
            this.date_picker.Location = new System.Drawing.Point(183, 121);
            this.date_picker.Name = "date_picker";
            this.date_picker.Size = new System.Drawing.Size(246, 25);
            this.date_picker.TabIndex = 60;
            // 
            // btn_clear
            // 
            this.btn_clear.BackColor = System.Drawing.Color.White;
            this.btn_clear.Image = ((System.Drawing.Image)(resources.GetObject("btn_clear.Image")));
            this.btn_clear.Location = new System.Drawing.Point(241, 182);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(55, 48);
            this.btn_clear.TabIndex = 59;
            this.btn_clear.UseVisualStyleBackColor = false;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(15, 80);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(129, 25);
            this.label6.TabIndex = 41;
            this.label6.Text = "Staff Incharge";
            // 
            // txt_uname
            // 
            this.txt_uname.Location = new System.Drawing.Point(183, 80);
            this.txt_uname.Name = "txt_uname";
            this.txt_uname.Size = new System.Drawing.Size(246, 25);
            this.txt_uname.TabIndex = 1;
            // 
            // txt_standert
            // 
            this.txt_standert.Location = new System.Drawing.Point(183, 37);
            this.txt_standert.Name = "txt_standert";
            this.txt_standert.Size = new System.Drawing.Size(246, 25);
            this.txt_standert.TabIndex = 0;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(15, 37);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 25);
            this.label7.TabIndex = 35;
            this.label7.Text = "Standerd";
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.White;
            this.button14.Image = ((System.Drawing.Image)(resources.GetObject("button14.Image")));
            this.button14.Location = new System.Drawing.Point(320, 182);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(55, 48);
            this.button14.TabIndex = 56;
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // total_pur
            // 
            this.total_pur.BackColor = System.Drawing.Color.Gainsboro;
            this.total_pur.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.total_pur.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.total_pur.Location = new System.Drawing.Point(506, 315);
            this.total_pur.Name = "total_pur";
            this.total_pur.Size = new System.Drawing.Size(111, 43);
            this.total_pur.TabIndex = 69;
            this.total_pur.Text = "0.0";
            // 
            // cmbo_payment
            // 
            this.cmbo_payment.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_payment.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_payment.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbo_payment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_payment.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_payment.FormattingEnabled = true;
            this.cmbo_payment.Items.AddRange(new object[] {
            "1"});
            this.cmbo_payment.Location = new System.Drawing.Point(655, 345);
            this.cmbo_payment.Name = "cmbo_payment";
            this.cmbo_payment.Size = new System.Drawing.Size(174, 29);
            this.cmbo_payment.TabIndex = 34;
            this.cmbo_payment.Text = "1";
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.White;
            this.button11.Image = ((System.Drawing.Image)(resources.GetObject("button11.Image")));
            this.button11.Location = new System.Drawing.Point(99, 695);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(55, 48);
            this.button11.TabIndex = 51;
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // buy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1362, 741);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "buy";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "buy";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.buy_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.Other.ResumeLayout(false);
            this.Other.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_item_left;
        private System.Windows.Forms.ComboBox cmbo_item_name;
        private System.Windows.Forms.ComboBox cmbo_item_id;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_discount;
        private System.Windows.Forms.TextBox txt_price;
        private System.Windows.Forms.TextBox txt_standert;
        private System.Windows.Forms.ComboBox cmbo_vendor_name;
        private System.Windows.Forms.TextBox txt_quantity;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox Other;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txt_uname;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbl_total;
        private System.Windows.Forms.Label lbl_total1;
        private System.Windows.Forms.Label lbl_discount;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Qty;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.Label first_total;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lbl_item_left;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox cmbo_payment;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox cash_amount;
        private System.Windows.Forms.Label lbl_balance;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.DateTimePicker date_picker;
        private System.Windows.Forms.Label total_pur;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
    }
}