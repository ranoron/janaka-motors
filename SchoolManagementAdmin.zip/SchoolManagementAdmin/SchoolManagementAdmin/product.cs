﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;


namespace SchoolManagementAdmin
{
    public partial class product : Form
    {

        SqlParameter img;


        public product(string user_product)
        {
            InitializeComponent();
            txtuser_type.Text = user_product;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "Image files: (*.jpg)|*.jpg|(*.jpeg)|*.jpeg|(*.png)|*.png|(*.Gif)|*.Gif|(*.bmp)|*.bmp| All Files (*.*)|*.*";
            DialogResult res = dlg.ShowDialog();
            if (res == DialogResult.OK)
            {
                string picpath = dlg.FileName.ToString();
                txt_pic_path.Text = picpath;
                picbox_product.ImageLocation = picpath;
                picbox_product.SizeMode = PictureBoxSizeMode.StretchImage;

            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            frmMain frm = new frmMain(txtuser_type.Text);
            frm.Show();
            this.Hide();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("select ident_current('product_table') + 1", con);

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    cmbo_id.Text = dr[0].ToString();

                }
            }
            catch (SqlException ee)
            {
                MessageBox.Show("" + ee);
            }

            txt_pic_path.Text = "";
            picbox_product.Image = null;
            datetime.Text = "";
            txtprice.Text = "";
            cmbo_make.Text = "";
            cmbo_standerd.Text = "";
            txtdisc.Text = "";
            cmbo_name.Text = " ";
            cmbo_model.Text = "";
            cmbo_year.Text = "";
            cmbo_country.Text = "";
            cmbo_quality.Text = "";
            cmbo_condi.Text = "";
            cmbo_color.Text = "";
            cmbo_garanty.Text = "";
            cmbo_return.Text = "";
            cmbo_material.Text = "";
            txt_capa.Text = "";
            cmbo_fit.Text = "";
            cmbo_waranty.Text = "";
            cmbo_discount.Text = "";
            txtothernote.Text = "";
            checkBox1.Checked = false;
            checkbox_Loadid.Checked = false;
            cmbo_name.Items.Clear();
            cmbo_id.Items.Clear();
            picbox_product.BringToFront();
        }

        private void save_to_stock()
        {
            int id;
            id = int.Parse(cmbo_id.Text);

            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();

                cmd = new SqlCommand("insert into stock_table (item_id,item_name,remaining)values('" + id + "','"
                                                                        + cmbo_name.Text + "','" + textBox1 .Text+ "')", con);

                cmd.ExecuteNonQuery();

                con.Close();
                //MessageBox.Show("success");
            }
            catch
                (SqlException ee)
            {
                MessageBox.Show("error" + ee);
            }


        }
        private void save_Click(object sender, EventArgs e)
        {
            if (txtprice.Text == "")
            {
                lbl_empty.BringToFront();
                btn_update_cancel.BringToFront();
            }

            if (cmbo_year.Text == "")
            {
                lbl_empty.BringToFront();
                btn_update_cancel.BringToFront();
            }

            if (picbox_product.Image == null)
            {
                lbl_empty.BringToFront();
                btn_update_cancel.BringToFront();
            }
            else
            {


                try
                {
                    byte[] imagebt = null;
                    FileStream fstream = new FileStream(this.txt_pic_path.Text, FileMode.Open, FileAccess.Read);
                    BinaryReader br = new BinaryReader(fstream);
                    imagebt = br.ReadBytes((int)fstream.Length);

                    int price, year;
                    price = int.Parse(txtprice.Text);
                    year = int.Parse(cmbo_year.Text);
                    DateTime date = DateTime.Parse(datetime.Text);

                    SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                    con.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd = new SqlCommand("insert into product_table(date,price,make,standerd,disc,name,model,year,country,quality,condition,colour,garanty,rtrn,material,capacity,fitfor,waranty,discount,othernote,img) values ('" + date + "',"
                                                                                    + price + ",'"
                                                                                    + cmbo_make.Text + "','"
                                                                                    + cmbo_standerd.Text + "','"
                                                                                    + txtdisc.Text + "','"
                                                                                    + cmbo_name.Text + "','"
                                                                                    + cmbo_model.Text + "',"
                                                                                    + year + ",'"
                                                                                    + cmbo_country.Text + "','"
                                                                                    + cmbo_quality.Text + "','"
                                                                                    + cmbo_condi.Text + "','"
                                                                                    + cmbo_color.Text + "','"
                                                                                    + cmbo_garanty.Text + "','"
                                                                                    + cmbo_return.Text + "','"
                                                                                    + cmbo_material.Text + "','"
                                                                                    + txt_capa.Text + "','"
                                                                                    + cmbo_fit.Text + "','"
                                                                                    + cmbo_waranty.Text + "','"
                                                                                    + cmbo_discount.Text + "','"
                                                                                    + txtothernote.Text + "','"
                                                                                    + imagebt + "')", con);

                    cmd.ExecuteNonQuery();
                    con.Close();

                    save_to_stock();
                    label_error_green.BringToFront();
                    btn_ok.BringToFront();
                    label_error_green.Text = "Data Added Succesfull Click Ok Here To Continue !.....";

                }
                catch (SqlException ee)
                {
                    MessageBox.Show("error" + ee);
                }
            }
        }

        private void delete_Click(object sender, EventArgs e)
        {
            Lbl_deleted.BringToFront();
            btnallow_delete.BringToFront();
            btnCancel_Delete.BringToFront();
            Lbl_deleted.Text = "System Trying To Delete Product Number '" + cmbo_id.Text + "' Permanantly! Are You Sure?";
        }

        private void update_Click(object sender, EventArgs e)
        {
            if (txtprice.Text == "")
            {
                lbl_empty.BringToFront();
                btn_update_cancel.BringToFront();
            }

            if (cmbo_year.Text == "")
            {
                lbl_empty.BringToFront();
                btn_update_cancel.BringToFront();
            }

            if (picbox_product.Image == null)
            {
                lbl_empty.BringToFront();
                btn_update_cancel.BringToFront();
            }

            else
            {

                lbl_update.BringToFront();
                lbl_update.Text = "     System Trying To Modify '" + cmbo_id.Text + "'th Product Permenantly! Are You Sure?";
                btn_update_allow.BringToFront();
                btn_update_cancel.BringToFront();
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            txt_pic_path.Text = "";
            picbox_product.Image = null;
        }

        private void btn_ok_Click(object sender, EventArgs e)
        {

            picboxwhite.BringToFront();
            btn_ok.SendToBack();
            label_error_green.SendToBack();

        }

        private void allow_delete_Click(object sender, EventArgs e)
        {
            picboxwhite.BringToFront();
            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("delete from product_table where id= '" + cmbo_id.Text + "' and name='" + cmbo_name.Text + "' ", con);
                cmd.ExecuteNonQuery();
                con.Close();

                //  MessageBox.Show("Data Deteted");
                label_error_green.BringToFront();
                label_error_green.Text = "     Data Deleted SuccessFully ";
                btn_ok.BringToFront();

            }
            catch (SqlException ee)
            {
                MessageBox.Show("error" + ee);
            }
            datetime.Text = "";
            txtprice.Text = "";
            cmbo_make.Text = "";
            cmbo_standerd.Text = "";
            txtdisc.Text = "";
            cmbo_name.Text = " ";
            cmbo_model.Text = "";
            cmbo_year.Text = "";
            cmbo_country.Text = "";
            cmbo_quality.Text = "";
            cmbo_condi.Text = "";
            cmbo_color.Text = "";
            cmbo_garanty.Text = "";
            cmbo_return.Text = "";
            cmbo_material.Text = "";
            txt_capa.Text = "";
            cmbo_fit.Text = "";
            cmbo_waranty.Text = "";
            cmbo_discount.Text = "";
            txtothernote.Text = "";
            checkBox1.Checked = false;
            checkbox_Loadid.Checked = false;
            cmbo_name.Items.Clear();
            cmbo_id.Items.Clear();

        }

        private void checkbox_Loadid_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("select * from product_table", con);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {

                    cmbo_id.Items.Add(dr["id"].ToString());
                    // cmbo_name.Items.Add(dr["name"].ToString());

                }
            }
            catch (SqlException ee)
            {
                MessageBox.Show("" + ee);
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

            if (checkBox1.Checked == true)
            {
                try
                {
                    SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                    con.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd = new SqlCommand("select * from product_table", con);
                    SqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {

                        // cmbo_id.Items.Add(dr["id"].ToString());
                        cmbo_name.Items.Add(dr["name"].ToString());

                    }
                }
                catch (SqlException ee)
                {
                    MessageBox.Show("" + ee);
                }


            }
        }

        //private void load_img()
        //{
        //     try
        //    {
        //        SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
        //        con.Open();
        //        SqlCommand cmd = new SqlCommand();
        //        cmd = new SqlCommand("select img from product_table where id = '" + cmbo_id.Text + "'", con);
        //        SqlDataReader dr = cmd.ExecuteReader();
        //}

        private void cmbo_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("select * from product_table where id = '" + cmbo_id.Text + "'", con);
                SqlDataReader dr = cmd.ExecuteReader();
                dr.Read();
                if (dr.HasRows)
                {
                    datetime.Text = dr[1].ToString();
                    txtprice.Text = dr[2].ToString();
                    cmbo_make.Text = (dr["make"].ToString());
                    cmbo_standerd.Text = (dr["standerd"].ToString());
                    txtdisc.Text = dr[5].ToString();
                    cmbo_name.Text = (dr["name"].ToString());
                    cmbo_model.Text = (dr["model"].ToString());
                    cmbo_year.Text = (dr["year"].ToString());
                    cmbo_country.Text = (dr["country"].ToString());
                    cmbo_quality.Text = (dr["quality"].ToString());
                    cmbo_condi.Text = (dr["condition"].ToString());
                    cmbo_color.Text = (dr["colour"].ToString());
                    cmbo_garanty.Text = (dr["garanty"].ToString());
                    cmbo_return.Text = (dr["rtrn"].ToString());
                    cmbo_material.Text = (dr["material"].ToString());
                    txt_capa.Text = dr[16].ToString();
                    cmbo_fit.Text = (dr["fitfor"].ToString());
                    cmbo_waranty.Text = (dr["waranty"].ToString());
                    cmbo_discount.Text = (dr["discount"].ToString());
                    txtothernote.Text = dr[18].ToString();

                    //byte[] imgg = (byte[])(dr[21]);
                    //if (imgg == null)
                    //    pictureBox2.Image = null;
                    //else
                    //{
                    //    MemoryStream ms = new MemoryStream(imgg);
                    //    pictureBox2.Image = Image.FromStream(ms);
                    //}

                    picbox_product.SendToBack();
                }
            }

            catch (SqlException ee)
            {
                MessageBox.Show("" + ee);
            }

        }

        private void cmbo_name_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("select * from product_table where name ='" + cmbo_name.Text + "'", con);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    datetime.Text = dr[1].ToString();
                    cmbo_id.Text = (dr["id"].ToString());
                    txtprice.Text = dr["price"].ToString();
                    cmbo_make.Text = (dr["make"].ToString());
                    cmbo_standerd.Text = (dr["standerd"].ToString()); ;
                    txtdisc.Text = dr["disc"].ToString();
                    cmbo_name.Text = (dr["name"].ToString());
                    cmbo_model.Text = (dr["model"].ToString());
                    cmbo_year.Text = (dr["year"].ToString());
                    cmbo_country.Text = (dr["country"].ToString());
                    cmbo_quality.Text = (dr["quality"].ToString());
                    cmbo_condi.Text = (dr["condition"].ToString());
                    cmbo_color.Text = (dr["colour"].ToString());
                    cmbo_garanty.Text = (dr["garanty"].ToString());
                    cmbo_return.Text = (dr["rtrn"].ToString());
                    cmbo_material.Text = (dr["material"].ToString());
                    txt_capa.Text = dr["capacity"].ToString();
                    cmbo_fit.Text = (dr["fitfor"].ToString());
                    cmbo_waranty.Text = (dr["waranty"].ToString());
                    cmbo_discount.Text = (dr["discount"].ToString());
                    txtothernote.Text = dr["othernote"].ToString();
                    //byte[] imgg = (byte[])(dr[21]);
                    //if (imgg == null)
                    //    pictureBox2.Image = null;
                    //else
                    //{
                    //    MemoryStream ms = new MemoryStream(imgg);
                    //    pictureBox2.Image = Image.FromStream(ms);
                    //}

                    picbox_product.SendToBack();
                }
            }
            catch (SqlException ee)
            {
                MessageBox.Show("error" + ee);
            }
        }

        private void checkBox1_CheckStateChanged(object sender, EventArgs e)
        {
            //  cmbo_name.Items.Clear();
        }

        private void btn_update_allow_Click(object sender, EventArgs e)
        {
            picboxwhite.BringToFront();
            int price, year;
            price = int.Parse(txtprice.Text);
            year = int.Parse(cmbo_year.Text);
            DateTime date = DateTime.Parse(datetime.Text);

            byte[] imagebt = null;
            FileStream fstream = new FileStream(this.txt_pic_path.Text, FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fstream);
            imagebt = br.ReadBytes((int)fstream.Length);

            // convrt();
            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("update product_table set date ='" + date + "',price='"
                                                                    + price + "',make='"
                                                                    + cmbo_make.Text + "',standerd='"
                                                                    + cmbo_standerd.Text + "',disc='"
                                                                    + txtdisc.Text + "',name='"
                                                                    + cmbo_name.Text + "',model='"
                                                                    + cmbo_model.Text + "',year='"
                                                                    + year + "',country='"
                                                                    + cmbo_country.Text + "',quality='"
                                                                    + cmbo_quality.Text + "',condition='"
                                                                    + cmbo_condi.Text + "',colour='"
                                                                    + cmbo_color.Text + "',garanty='"
                                                                    + cmbo_garanty.Text + "',rtrn='"
                                                                    + cmbo_return.Text + "',material='"
                                                                    + cmbo_material.Text + "',capacity='"
                                                                    + txt_capa.Text + "',fitfor='"
                                                                    + cmbo_fit.Text + "',waranty='"
                                                                    + cmbo_waranty.Text + "',discount='"
                                                                    + cmbo_discount.Text + "',othernote='"
                                                                    + txtothernote.Text + "',img='" + imagebt + "' where id= '" + cmbo_id.Text + "'", con);
                cmd.ExecuteNonQuery();
                con.Close();

                //MessageBox.Show("done");
                label_error_green.BringToFront();
                label_error_green.Text = "Data Updated Successfully!";
                btn_ok.BringToFront();

            }
            catch (SqlException ee)
            {
                MessageBox.Show("error" + ee);
            }
        }

        private void btn_update_cancel_Click(object sender, EventArgs e)
        {
            picboxwhite.BringToFront();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            camara frm = new camara();
            frm.Show();
        }

        private void picbox_product_Click(object sender, EventArgs e)
        {

        }

        private void load_pic()
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("select img from product_table where id = '" + cmbo_id.Text + "'", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                SqlCommandBuilder cbd = new SqlCommandBuilder(da);
                DataSet ds = new DataSet();
                da.Fill(ds);
                con.Close();

                byte[] ap = (byte[])(ds.Tables[0].Rows[0]["img"]);
                MemoryStream ms = new MemoryStream(ap);
                picbox_product.Image = Image.FromStream(ms);
                ms.Close();

            }
            catch (SqlException ee)
            {
                MessageBox.Show("jchdj" + ee);
            }
        }


        private void product_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("select ident_current('product_table') + 1", con);

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    cmbo_id.Text = dr[0].ToString();

                }
            }
            catch (SqlException ee)
            {
                MessageBox.Show("" + ee);
            }


            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();

                cmd = new SqlCommand("select ident_current('staff_table') + 1", con);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {

                    cmbo_staff_id.Text = dr[0].ToString();
                }
            }
            catch (SqlException ee)
            {
                MessageBox.Show("" + ee);
            }

            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();

                cmd = new SqlCommand("select ident_current('dealer_table') + 1", con);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {

                    cmbo_dealer_id.Text = dr[0].ToString();
                }
            }
            catch (SqlException ee)
            {
                MessageBox.Show("" + ee);
            }



            if (txtuser_type.Text == "staff")
            {
                TabPage t = tcMain.TabPages[1];
                tcMain.SelectedTab = t;
            }
            if (txtuser_type.Text == "dealer")
            {
                TabPage t = tcMain.TabPages[2];
                tcMain.SelectedTab = t;
            }
        }


        private void button5_Click(object sender, EventArgs e)
        {
            if (txt_staffile.Text == "")
            {
                lbl_empty.BringToFront();
                lbl_empty.Text = "File Number,NIC,Land, Mobile, Name Empty ";
                btn_update_cancel.BringToFront();
            }

            if (txt_nic.Text == "")
            {
                lbl_empty.BringToFront();
                lbl_empty.Text = "File Number,NIC,Land, Mobile, Name Empty ";
                btn_update_cancel.BringToFront();
            }
            if (txt_land.Text == "")
            {
                lbl_empty.BringToFront();
                lbl_empty.Text = "File Number,NIC,Land, Mobile, Name Empty ";
                btn_update_cancel.BringToFront();
            }

            if (Txt_phone_numaric.Text == "")
            {
                lbl_empty.BringToFront();
                lbl_empty.Text = "File Number,NIC,Land, Mobile, Name Empty ";
                btn_update_cancel.BringToFront();
            }
            if (picbox_staff.Image == null)
            {
                lbl_empty.BringToFront();
                lbl_empty.Text = "File Number,NIC,Land, Mobile, Name Empty ";
                btn_update_cancel.BringToFront();
            }

            else
            {

                byte[] imagebt = null;
                FileStream fstream = new FileStream(this.txt_picture_path.Text, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fstream);
                imagebt = br.ReadBytes((int)fstream.Length);

                int file, nic, mob, land;
                file = Convert.ToInt32(txt_staffile.Text);
                nic = Convert.ToInt32(txt_nic.Text);
                mob = Convert.ToInt32(Txt_phone_numaric.Text);
                land = Convert.ToInt32(txt_land.Text);
                DateTime date = DateTime.Parse(Staff_dateofbirth.Text);
                DateTime admission_date = DateTime.Parse(staff_addmissiondate.Text);

                //convrt();
                try
                {
                    SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                    con.Open();
                    SqlCommand cmd = new SqlCommand();
                    //  cmd.Parameters.Add(new SqlParameter("@img", imagebt));
                    cmd = new SqlCommand("insert into staff_table (addmission_date,gender,type,religion,relationship,marks,born_place,dateofbirth,section,file_number,title,fname,lname,nic,phone,landline,emil,address,town,uname,pwd,staf_img)values('" + admission_date + "','"
                                                                            + cmbo_staff_gender.Text + "','"
                                                                            + cmbo_staff_type.Text + "','"
                                                                            + cmbo_staff_religion.Text + "','"
                                                                            + txt_staff_relationship.Text + "','"
                                                                            + txt_staff_marks.Text + "','"
                                                                            + Staff_Bornplace.Text + "','"
                                                                            + date + "','"
                                                                            + cmbo_staffsec.Text + "',"
                                                                            + file + ",'"
                                                                            + cmbo_title.Text + "','"
                                                                            + cmbo_fname.Text + "','"
                                                                            + txt_lname.Text + "',"
                                                                            + nic + ","
                                                                            + mob + ","
                                                                            + land + ",'"
                                                                            + txt_email.Text + "','"
                                                                            + txt_add.Text + "','"
                                                                            + txt_town.Text + "','"
                                                                            + txt_uname.Text + "','"
                                                                            + txt_pwd.Text + "','"
                                                                            + imagebt + "')", con);
                    cmd.ExecuteNonQuery();
                    // cmd.Parameters.Add(new SqlParameter("@img", imagebt));
                    con.Close();
                    //MessageBox.Show("done");

                    label_error_green.BringToFront();
                    btn_ok.BringToFront();
                    label_error_green.Text = "Data Added Succesfull Click Ok Here To Continue !.....";
                }
                catch (SqlException ee)
                {
                    MessageBox.Show("error" + ee);
                }
            }
        }

        private void button20_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "Image files: (*.jpg)|*.jpg|(*.jpeg)|*.jpeg|(*.png)|*.png|(*.Gif)|*.Gif|(*.bmp)|*.bmp| All Files (*.*)|*.*";
            DialogResult res = dlg.ShowDialog();
            if (res == DialogResult.OK)
            {
                string picpath = dlg.FileName.ToString();
                txt_picture_path.Text = picpath;
                picbox_staff.ImageLocation = picpath;
                picbox_staff.SizeMode = PictureBoxSizeMode.StretchImage;

            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            txt_picture_path.Text = "";
            picbox_staff.Image = null;
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("select * from staff_table", con);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {

                    cmbo_staff_id.Items.Add(dr["staff_id"].ToString());
                }
            }
            catch (SqlException ee)
            {
                MessageBox.Show("" + ee);
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (chek_name.Checked == true)
            {
                try
                {
                    SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                    con.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd = new SqlCommand("select * from staff_table", con);
                    SqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {

                        // cmbo_staff_id.Items.Add(dr["staff_id"].ToString());
                        cmbo_fname.Items.Add(dr["fname"].ToString());

                    }
                }
                catch (SqlException ee)
                {
                    MessageBox.Show("" + ee);
                }
            }
        }

        private void cmbo_staff_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("select * from staff_table where staff_id = '" + cmbo_staff_id.Text + "'", con);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    staff_addmissiondate.Text = dr["addmission_date"].ToString();
                    cmbo_staff_gender.Text = dr["gender"].ToString();
                    cmbo_staff_type.Text = dr["type"].ToString();
                    cmbo_staff_religion.Text = dr["religion"].ToString();
                    txt_staff_relationship.Text = dr["relationship"].ToString();
                    txt_staff_marks.Text = dr["marks"].ToString();
                    Staff_Bornplace.Text = dr["born_place"].ToString();
                    Staff_dateofbirth.Text = dr["dateofbirth"].ToString();
                    cmbo_staffsec.Text = dr["section"].ToString();
                    txt_staffile.Text = dr["file_number"].ToString();
                    cmbo_title.Text = dr["title"].ToString();
                    cmbo_fname.Text = dr["fname"].ToString();
                    txt_lname.Text = dr["lname"].ToString();
                    txt_nic.Text = dr["nic"].ToString();
                    Txt_phone_numaric.Text = dr["phone"].ToString();
                    txt_land.Text = dr["landline"].ToString();
                    txt_email.Text = dr["emil"].ToString();
                    txt_add.Text = dr["address"].ToString();
                    txt_town.Text = dr["town"].ToString();
                    txt_uname.Text = dr["uname"].ToString();
                    txt_pwd.Text = dr["pwd"].ToString();
                    txt_pwd2.Text = dr["pwd"].ToString();


                    picbox_dummy.BringToFront();

                }
            }
            catch (SqlException ee)
            {
                MessageBox.Show("" + ee);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (txt_staffile.Text == "")
            {
                lbl_empty.BringToFront();
                lbl_empty.Text = "NIC,File Number, Phone , Landline Number and Picture Must Be Entered!!";
                btn_update_cancel.BringToFront();
            }
            if (txt_nic.Text == "")
            {
                lbl_empty.BringToFront();
                lbl_empty.Text = "NIC,File Number, Phone , Landline Number and Picture Must Be Entered!!";
                btn_update_cancel.BringToFront();
            }
            if (Txt_phone_numaric.Text == "")
            {
                lbl_empty.BringToFront();
                lbl_empty.Text = "NIC,File Number, Phone , Landline Number and Picture Must Be Entered!!";
                btn_update_cancel.BringToFront();
            }
            if (txt_land.Text == "")
            {
                lbl_empty.BringToFront();
                lbl_empty.Text = "NIC,File Number, Phone , Landline Number and Picture Must Be Entered!!";
                btn_update_cancel.BringToFront();
            }
            if (picbox_staff.Image == null)
            {
                lbl_empty.BringToFront();
                lbl_empty.Text = "NIC,File Number, Phone , Landline Number and Picture Must Be Entered!!";
                btn_update_cancel.BringToFront();
            }

            else
            {

                lbl_update.BringToFront();
                lbl_update.Text = "     System Trying To Modify staff Number '" + cmbo_staff_id.Text + "' s details Permenantly! Are You Sure?";
                btn_allow_update_staff.BringToFront();
                btn_update_cancel.BringToFront();

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Lbl_deleted.BringToFront();
            btn_staff_delete_allow.BringToFront();
            btnCancel_Delete.BringToFront();
            Lbl_deleted.Text = "     System Trying To Delete Staff Number '" + cmbo_staff_id.Text + "' Permanantly! Are You Sure?";
        }

        private void cmbo_fname_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbo_fname.BackColor = System.Drawing.Color.Gainsboro;
            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("select * from staff_table where fname = '" + cmbo_fname.Text + "'", con);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    cmbo_staff_id.Text = dr["staff_id"].ToString();
                    staff_addmissiondate.Text = dr["addmission_date"].ToString();
                    cmbo_staff_gender.Text = dr["gender"].ToString();
                    cmbo_staff_religion.Text = dr["religion"].ToString();
                    txt_staff_relationship.Text = dr["relationship"].ToString();
                    txt_staff_marks.Text = dr["marks"].ToString();
                    Staff_Bornplace.Text = dr["born_place"].ToString();
                    Staff_dateofbirth.Text = dr["dateofbirth"].ToString();
                    cmbo_staffsec.Text = dr["section"].ToString();
                    txt_staffile.Text = dr["file_number"].ToString();
                    cmbo_title.Text = dr["title"].ToString();
                    cmbo_fname.Text = dr["fname"].ToString();
                    txt_lname.Text = dr["lname"].ToString();
                    txt_nic.Text = dr["nic"].ToString();
                    Txt_phone_numaric.Text = dr["phone"].ToString();
                    txt_land.Text = dr["landline"].ToString();
                    txt_email.Text = dr["emil"].ToString();
                    txt_add.Text = dr["address"].ToString();
                    txt_town.Text = dr["town"].ToString();
                    txt_uname.Text = dr["uname"].ToString();
                    txt_pwd.Text = dr["pwd"].ToString();
                    txt_pwd2.Text = dr["pwd"].ToString();

                    picbox_dummy.BringToFront();

                }
            }
            catch (SqlException ee)
            {
                MessageBox.Show("" + ee);
            }
        }

        private void btn_staff_delete_allow_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("delete from staff_table where staff_id= '" + cmbo_staff_id.Text + "' and fname='" + cmbo_fname.Text + "' ", con);
                cmd.ExecuteNonQuery();
                con.Close();

                //  MessageBox.Show("Data Deteted");
                label_error_green.BringToFront();
                label_error_green.Text = "     Data Deleted SuccessFully ";
                btn_ok.BringToFront();

            }
            catch (SqlException ee)
            {
                MessageBox.Show("error" + ee);
            }
        }

        private void btn_allow_update_staff_Click(object sender, EventArgs e)
        {
            byte[] imagebt_staff = null;
            FileStream fstream = new FileStream(this.txt_picture_path.Text, FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fstream);
            imagebt_staff = br.ReadBytes((int)fstream.Length);

            int nic, phone, land, f_number;

            land = Convert.ToInt32(txt_land.Text);
            phone = Convert.ToInt32(Txt_phone_numaric.Text);
            f_number = Convert.ToInt32(txt_staffile.Text);
            nic = Convert.ToInt32(txt_nic.Text);

            DateTime addmission_date = DateTime.Parse(staff_addmissiondate.Text);
            DateTime dateofbrrth = DateTime.Parse(Staff_dateofbirth.Text);


            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();

                cmd = new SqlCommand("update staff_table set addmission_date='" + addmission_date + "',gender= '"
                                                                        + cmbo_staff_gender.Text + "',type='"
                                                                        + cmbo_staff_type.Text + "',religion='"
                                                                        + cmbo_staff_religion.Text + "',relationship='"
                                                                        + txt_staff_relationship.Text + "',marks='"
                                                                        + txt_staff_marks.Text + "',born_place='"
                                                                        + Staff_Bornplace.Text + "',dateofbirth='"
                                                                        + dateofbrrth + "',section='"
                                                                        + cmbo_staffsec.Text + "',file_number='"
                                                                        + f_number + "',title='"
                                                                        + cmbo_title.Text + "',fname='"
                                                                        + cmbo_fname.Text + "',lname='"
                                                                        + txt_lname.Text + "',nic='"
                                                                        + nic + "',phone='"
                                                                        + phone + "',landline='"
                                                                        + land + "',emil='"
                                                                        + txt_email.Text + "',address='"
                                                                        + txt_add.Text + "',town='"
                                                                        + txt_town.Text + "',uname='"
                                                                        + txt_uname.Text + "',pwd='"
                                                                        + txt_pwd.Text + "',pwd2='"
                                                                        + txt_pwd2.Text + "',staf_img='" + imagebt_staff + "' where staff_id = '" + cmbo_staff_id.Text + "'", con);



                cmd.ExecuteNonQuery();

                con.Close();

                label_error_green.BringToFront();
                btn_ok.BringToFront();
                label_error_green.Text = "Data Added Succesfull Click Ok Here To Continue !.....";
            }
            catch (SqlException ee)
            {
                MessageBox.Show("error" + ee);
            }
        }

        private void Lbl_deleted_Click(object sender, EventArgs e)
        {

        }

        private void tcMain_Selected(object sender, TabControlEventArgs e)
        {

        }

        private void tcMain_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void button17_Click(object sender, EventArgs e)
        {
            frmMain frm = new frmMain("admin");
            frm.Show();
            this.Hide();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnCancel_Delete_Click(object sender, EventArgs e)
        {
            picboxwhite.BringToFront();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();

                cmd = new SqlCommand("select ident_current('staff_table') + 1", con);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {

                    cmbo_staff_id.Text = dr[0].ToString();
                }
            }
            catch (SqlException ee)
            {
                MessageBox.Show("" + ee);
            }

            cmbo_staff_id.Items.Clear();
            cmbo_staff_gender.Text = "";
            cmbo_staff_type.Text = "";
            cmbo_staff_religion.Text = "";
            txt_staff_relationship.Text = "";
            txt_staff_marks.Text = "";
            Staff_Bornplace.Text = "";
            cmbo_staffsec.Text = "";
            txt_staffile.Text = "";
            cmbo_title.Text = "";
            cmbo_fname.Text = "";
            cmbo_fname.Items.Clear();
            txt_lname.Text = "";
            txt_nic.Text = "";
            Txt_phone_numaric.Text = "";
            txt_land.Text = "";
            txt_email.Text = "";
            txt_add.Text = "";
            txt_town.Text = "";
            txt_uname.Text = "";
            txt_pwd.Text = "";
            txt_pwd2.Text = "";
            picbox_staff.Image = null;

            picbox_dummy.SendToBack();
        }

        private void txtprice_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtprice.BackColor = System.Drawing.Color.Gainsboro;
        }

        private void cmbo_name_KeyPress(object sender, KeyPressEventArgs e)
        {
            cmbo_name.BackColor = System.Drawing.Color.Gainsboro;
        }

        private void cmbo_year_KeyPress(object sender, KeyPressEventArgs e)
        {
            cmbo_year.BackColor = System.Drawing.Color.Gainsboro;
        }



        private void txtprice_Validating_1(object sender, CancelEventArgs e)
        {
            if (txtprice.Text == "")
            {
                txtprice.BackColor = System.Drawing.Color.LightPink;
            }

            else
            {
                cmbo_year.BackColor = System.Drawing.Color.Gainsboro;
            }
        }

        private void txtprice_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            txtprice.BackColor = System.Drawing.Color.Gainsboro;
        }

        private void cmbo_name_Validating(object sender, CancelEventArgs e)
        {
            if (cmbo_name.Text == "")
            {
                cmbo_name.BackColor = System.Drawing.Color.LightPink;
            }

            else
            {
                cmbo_name.BackColor = System.Drawing.Color.Gainsboro;
            }
        }

        private void cmbo_year_Validating(object sender, CancelEventArgs e)
        {
            if (cmbo_year.Text == "")
            {
                cmbo_year.BackColor = System.Drawing.Color.LightPink;
            }

            else
            {
                cmbo_year.BackColor = System.Drawing.Color.Gainsboro;
            }
        }

        private void txt_staffile_Validating(object sender, CancelEventArgs e)
        {
            if (txt_staffile.Text == "")
            {
                txt_staffile.BackColor = System.Drawing.Color.LightPink;
            }

            else
            {
                txt_staffile.BackColor = System.Drawing.Color.Gainsboro;
            }
        }

        private void txt_nic_Validating(object sender, CancelEventArgs e)
        {
            if (txt_nic.Text == "")
            {
                txt_nic.BackColor = System.Drawing.Color.LightPink;
            }

            else
            {
                txt_nic.BackColor = System.Drawing.Color.Gainsboro;
            }
        }

        private void txt_staffile_KeyPress(object sender, KeyPressEventArgs e)
        {
            txt_staffile.BackColor = System.Drawing.Color.Gainsboro;
        }

        private void cmbo_fname_KeyPress(object sender, KeyPressEventArgs e)
        {
            cmbo_fname.BackColor = System.Drawing.Color.Gainsboro;
        }

        private void txt_nic_KeyPress(object sender, KeyPressEventArgs e)
        {
            txt_nic.BackColor = System.Drawing.Color.Gainsboro;
        }

        private void Txt_phone_numaric_KeyPress(object sender, KeyPressEventArgs e)
        {
            Txt_phone_numaric.BackColor = System.Drawing.Color.Gainsboro;
        }

        private void txt_land_KeyPress(object sender, KeyPressEventArgs e)
        {
            txt_land.BackColor = System.Drawing.Color.Gainsboro;
        }

        private void Txt_phone_numaric_Validating(object sender, CancelEventArgs e)
        {
            if (Txt_phone_numaric.Text == "")
            {
                Txt_phone_numaric.BackColor = System.Drawing.Color.LightPink;
            }

            else
            {
                Txt_phone_numaric.BackColor = System.Drawing.Color.Gainsboro;
            }
        }

        private void cmbo_fname_Validating(object sender, CancelEventArgs e)
        {
            if (cmbo_fname.Text == "")
            {
                cmbo_fname.BackColor = System.Drawing.Color.LightPink;
            }

            else
            {
                cmbo_fname.BackColor = System.Drawing.Color.Gainsboro;
            }
        }

        private void txt_land_Validating(object sender, CancelEventArgs e)
        {
            if (txt_land.Text == "")
            {
                txt_land.BackColor = System.Drawing.Color.LightPink;
            }

            else
            {
                txt_land.BackColor = System.Drawing.Color.Gainsboro;
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            camara frm = new camara();
            frm.Show();
        }

        private void button22_Click(object sender, EventArgs e)
        {



            if (txt_dealer_name.Text == "")
            {
                lbl_empty.BringToFront();
                lbl_empty.Text = "Name,Date,Reg Number And Account Number Must Be Entered!!";
                btn_update_cancel.BringToFront();
            }
            if (datetime_dealer.Text == "")
            {
                lbl_empty.BringToFront();
                lbl_empty.Text = "Name,Date,Reg Number And Account Number Must Be Entered!!";
                btn_update_cancel.BringToFront();
            }
            if (reg_dealer.Text == "")
            {
                lbl_empty.BringToFront();
                lbl_empty.Text = "Name,Date,Reg Number And Account Number Must Be Entered!!";
                btn_update_cancel.BringToFront();
            }
            if (acc_no.Text == "")
            {
                lbl_empty.BringToFront();
                lbl_empty.Text = "Name,Date,Reg Number And Account Number Must Be Entered!!";
                btn_update_cancel.BringToFront();
            }



            else
            {
                int reg, acc;
                reg = Convert.ToInt32(reg_dealer.Text);
                acc = Convert.ToInt32(acc_no.Text);
                DateTime date_int = DateTime.Parse(datetime_dealer.Text);

                try
                {
                    SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                    con.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd = new SqlCommand("insert into dealer_table(name,item,date,address,company_name,reg_number,acc_number,bank,email)values('" + txt_dealer_name.Text + "','"
                                                                                                                             + cmbo_spec_item.Text + "','"
                                                                                                                             + date_int + "','"
                                                                                                                             + txt_add_dealer.Text + "','"
                                                                                                                             + txt_company.Text + "','"
                                                                                                                             + reg + "','"
                                                                                                                             + acc + "','"
                                                                                                                             + cmbo_bank.Text + "','" + email.Text + "')", con);

                    cmd.ExecuteNonQuery();
                    con.Close();

                    label_error_green.BringToFront();
                    btn_ok.BringToFront();
                    label_error_green.Text = "Data Added Succesfull Click Ok Here To Continue !.....";
                }
                catch (SqlException ee)
                {
                    MessageBox.Show("error" + ee);
                }
            }
        }

        private void groupBox7_Enter(object sender, EventArgs e)
        {

        }

        private void txt_dealer_name_KeyPress(object sender, KeyPressEventArgs e)
        {
            txt_dealer_name.BackColor = System.Drawing.Color.Gainsboro;
        }

        private void reg_dealer_KeyPress(object sender, KeyPressEventArgs e)
        {
            reg_dealer.BackColor = System.Drawing.Color.Gainsboro;
        }

        private void acc_no_KeyPress(object sender, KeyPressEventArgs e)
        {
            acc_no.BackColor = System.Drawing.Color.Gainsboro;
        }

        private void txt_dealer_name_Validating(object sender, CancelEventArgs e)
        {
            if (txt_dealer_name.Text == "")
            {
                txt_dealer_name.BackColor = System.Drawing.Color.LightPink;
            }

            else
            {
                txt_dealer_name.BackColor = System.Drawing.Color.Gainsboro;
            }
        }

        private void reg_dealer_Validating(object sender, CancelEventArgs e)
        {
            if (reg_dealer.Text == "")
            {
                reg_dealer.BackColor = System.Drawing.Color.LightPink;
            }

            else
            {
                reg_dealer.BackColor = System.Drawing.Color.Gainsboro;
            }
        }

        private void acc_no_Validating(object sender, CancelEventArgs e)
        {
            if (acc_no.Text == "")
            {
                acc_no.BackColor = System.Drawing.Color.LightPink;
            }

            else
            {
                acc_no.BackColor = System.Drawing.Color.Gainsboro;
            }
        }

        private void button24_Click(object sender, EventArgs e)
        {
            frmMain frm = new frmMain("admin");
            frm.Show();
            this.Hide();
        }

        private void button23_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();

                cmd = new SqlCommand("select ident_current('dealer_table') + 1", con);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {

                    cmbo_dealer_id.Text = dr[0].ToString();
                }
            }
            catch (SqlException ee)
            {
                MessageBox.Show("" + ee);
            }

            //cmbo_dealer_id.Items.Clear();
            // cmbo_dealer_id.Text = "";
            txt_dealer_name.Text = "";
            txt_dealer_name.Items.Clear();
            cmbo_spec_item.Text = "";
            datetime_dealer.Text = "";
            txt_add_dealer.Text = "";
            txt_company.Text = "";
            reg_dealer.Text = "";
            acc_no.Text = "";
            cmbo_bank.Text = "";
            email.Text = "";
            cmbo_dealer_id.Items.Clear();
        }

        private void button21_Click(object sender, EventArgs e)
        {
            Lbl_deleted.BringToFront();
            btn_allow_delete_dealer.BringToFront();
            btnCancel_Delete.BringToFront();
            Lbl_deleted.Text = "     System Trying To Delete  '" + cmbo_dealer_id.Text + "' th Dealer Permanantly! Are You Sure?";
        }

        private void btn_allow_delete_dealer_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("delete from dealer_table where dealer_id= '" + cmbo_dealer_id.Text + "'", con);
                cmd.ExecuteNonQuery();
                con.Close();

                //  MessageBox.Show("Data Deteted");
                label_error_green.BringToFront();
                label_error_green.Text = "     Data Deleted SuccessFully ";
                btn_ok.BringToFront();

            }
            catch (SqlException ee)
            {
                MessageBox.Show("error" + ee);
            }


            txt_dealer_name.Text = "";
            txt_dealer_name.Items.Clear();
            cmbo_spec_item.Text = "";
            datetime_dealer.Text = "";
            txt_add_dealer.Text = "";
            txt_company.Text = "";
            reg_dealer.Text = "";
            acc_no.Text = "";
            cmbo_bank.Text = "";
            email.Text = "";
            cmbo_dealer_id.Items.Clear();


        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (txt_dealer_name.Text == "")
            {
                lbl_empty.BringToFront();
                lbl_empty.Text = "Name,Date,Reg Number And Account Number Must Be Entered!!";
                btn_update_cancel.BringToFront();
            }
            if (datetime_dealer.Text == "")
            {
                lbl_empty.BringToFront();
                lbl_empty.Text = "Name,Date,Reg Number And Account Number Must Be Entered!!";
                btn_update_cancel.BringToFront();
            }
            if (reg_dealer.Text == "")
            {
                lbl_empty.BringToFront();
                lbl_empty.Text = "Name,Date,Reg Number And Account Number Must Be Entered!!";
                btn_update_cancel.BringToFront();
            }
            if (acc_no.Text == "")
            {
                lbl_empty.BringToFront();
                lbl_empty.Text = "Name,Date,Reg Number And Account Number Must Be Entered!!";
                btn_update_cancel.BringToFront();
            }

            else
            {

                lbl_update.BringToFront();
                lbl_update.Text = "     System Trying To Modify  '" + cmbo_dealer_id.Text + "' th dealer's details Permenantly! Are You Sure?";
                btn_allow_update_dealer.BringToFront();
                btn_update_cancel.BringToFront();

            }
        }

        private void btn_allow_update_dealer_Click(object sender, EventArgs e)
        {

            int reg, acc;
            reg = Convert.ToInt32(reg_dealer.Text);
            acc = Convert.ToInt32(acc_no.Text);
            DateTime date_int = DateTime.Parse(datetime_dealer.Text);

            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();

                cmd = new SqlCommand("update dealer_table set name='" + txt_dealer_name.Text + "',item= '"
                                                                        + cmbo_spec_item.Text + "',date='"
                                                                        + date_int + "',address='"
                                                                        + txt_add_dealer.Text + "',company_name='"
                                                                        + txt_company.Text + "',reg_number='"
                                                                        + reg + "',acc_number='"
                                                                        + acc + "',bank='" + cmbo_bank.Text + "',email = '" + email.Text + "' where dealer_id = '" + cmbo_dealer_id.Text + "'", con);



                cmd.ExecuteNonQuery();

                con.Close();

                label_error_green.BringToFront();
                btn_ok.BringToFront();
                label_error_green.Text = "Data Added Succesfull Click Ok Here To Continue !.....";
            }
            catch (SqlException ee)
            {
                MessageBox.Show("error" + ee);
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("select * from dealer_table", con);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {

                    cmbo_dealer_id.Items.Add(dr["dealer_id"].ToString());

                }
            }
            catch (SqlException ee)
            {
                MessageBox.Show("" + ee);
            }
        }

        private void txt_dealer_name_Validating_1(object sender, CancelEventArgs e)
        {
            if (txt_dealer_name.Text == "")
            {
                txt_dealer_name.BackColor = System.Drawing.Color.LightPink;
            }

            else
            {
                txt_dealer_name.BackColor = System.Drawing.Color.Gainsboro;
            }
        }

        private void txt_dealer_name_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            txt_dealer_name.BackColor = System.Drawing.Color.Gainsboro;
        }

        private void txt_dealer_name_SelectedIndexChanged(object sender, EventArgs e)
        {
            txt_dealer_name.BackColor = System.Drawing.Color.Gainsboro;

            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("select * from dealer_table where name = '" + txt_dealer_name.Text + "'", con);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {

                    cmbo_dealer_id.Text = dr["dealer_id"].ToString();

                    cmbo_spec_item.Text = dr["item"].ToString();
                    datetime_dealer.Text = dr["date"].ToString();
                    txt_add_dealer.Text = dr["address"].ToString();
                    txt_company.Text = dr["company_name"].ToString();
                    reg_dealer.Text = dr["reg_number"].ToString();
                    acc_no.Text = dr["acc_number"].ToString();
                    cmbo_bank.Text = dr["bank"].ToString();

                }

            }

            catch (SqlException ee1)
            {
                MessageBox.Show("" + ee1);
            }
        }

        private void checkBox2_CheckedChanged_1(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("select * from dealer_table", con);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {

                    txt_dealer_name.Items.Add(dr["name"].ToString());
                }
            }
            catch (SqlException ee)
            {
                MessageBox.Show("" + ee);
            }
        }

        private void cmbo_dealer_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("select * from dealer_table where dealer_id = '" + cmbo_dealer_id.Text + "'", con);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {

                    cmbo_dealer_id.Text = dr["dealer_id"].ToString();
                    txt_dealer_name.Text = dr["name"].ToString();
                    cmbo_spec_item.Text = dr["item"].ToString();
                    datetime_dealer.Text = dr["date"].ToString();
                    txt_add_dealer.Text = dr["address"].ToString();
                    txt_company.Text = dr["company_name"].ToString();
                    reg_dealer.Text = dr["reg_number"].ToString();
                    acc_no.Text = dr["acc_number"].ToString();
                    cmbo_bank.Text = dr["bank"].ToString();
                    email.Text = dr["email"].ToString();

                }

            }

            catch (SqlException ee1)
            {
                MessageBox.Show("" + ee1);
            }


        }

        private void checkBox4_CheckStateChanged(object sender, EventArgs e)
        {

        }

        private void email_Validating(object sender, CancelEventArgs e)
        {

            System.Text.RegularExpressions.Regex rEmail = new System.Text.RegularExpressions.Regex(@"^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$");

            if (email.Text.Length > 0 && email.Text.Trim().Length != 0)
            {
                if (!rEmail.IsMatch(email.Text.Trim()))
                {
                    MessageBox.Show("PLEASE ENTER THE VALID EMAIL ID FOR PROCCESS");
                    email.SelectAll();
                    e.Cancel = true;
                }
            }
        }

        private void txt_email_Validating(object sender, CancelEventArgs e)
        {
            System.Text.RegularExpressions.Regex rEmail = new System.Text.RegularExpressions.Regex(@"^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$");

            if (txt_email.Text.Length > 0 && txt_email.Text.Trim().Length != 0)
            {
                if (!rEmail.IsMatch(txt_email.Text.Trim()))
                {
                    MessageBox.Show("PLEASE ENTER THE VALID EMAIL ID FOR PROCCESS");
                    txt_email.SelectAll();
                    e.Cancel = true;
                }
            }
        }

        private void txt_uname_Validating(object sender, CancelEventArgs e)
        {
            try
            {

                SqlConnection cn = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                cn.Open();

                SqlCommand cmd = new SqlCommand("Select * from staff_table where uname='" + txt_uname.Text + "';", cn);
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                int count = 0;

                while (dr.Read())
                {
                    count = count + 1;
                }
                if (count == 1)
                {
                    //MessageBox.Show("alrdy exist");
                    label18.BringToFront();
                    txt_uname.SelectAll();
                    button5.Enabled = false;
                }
                //if (txt_uname.Focused == false)
                else
                {
                    pictureBox1.BringToFront();
                    button5.Enabled = true;
                }
            }
            catch (SqlException ee)
            {
                MessageBox.Show("error" + ee);
            }

        }

        private void txt_pwd2_Validating(object sender, CancelEventArgs e)
        {

            if (string.Compare(txt_pwd.Text, txt_pwd2.Text, true) == 0)

                label34.Visible = false;

            else
                label34.Text = "Password Did Not Match";
            
        }
    }
}
