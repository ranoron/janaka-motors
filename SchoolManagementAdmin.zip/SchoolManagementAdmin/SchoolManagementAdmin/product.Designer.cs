﻿namespace SchoolManagementAdmin
{
    partial class product
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(product));
            this.cmbo_staffsec = new System.Windows.Forms.ComboBox();
            this.txt_staff_marks = new System.Windows.Forms.TextBox();
            this.cmbo_staff_religion = new System.Windows.Forms.ComboBox();
            this.cmbo_staff_type = new System.Windows.Forms.ComboBox();
            this.cmbo_staff_gender = new System.Windows.Forms.ComboBox();
            this.vonders = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.email = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txt_dealer_name = new System.Windows.Forms.ComboBox();
            this.cmbo_spec_item = new System.Windows.Forms.ComboBox();
            this.txt_company = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.cmbo_bank = new System.Windows.Forms.ComboBox();
            this.button7 = new System.Windows.Forms.Button();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.button21 = new System.Windows.Forms.Button();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.button22 = new System.Windows.Forms.Button();
            this.datetime_dealer = new System.Windows.Forms.DateTimePicker();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.acc_no = new NumericTextBox.NumericTextBox();
            this.reg_dealer = new NumericTextBox.NumericTextBox();
            this.cmbo_dealer_id = new System.Windows.Forms.ComboBox();
            this.txt_add_dealer = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txt_staffile = new NumericTextBox.NumericTextBox();
            this.cmbo_staff_id = new System.Windows.Forms.ComboBox();
            this.chek_name = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.Staff_dateofbirth = new System.Windows.Forms.DateTimePicker();
            this.staff_addmissiondate = new System.Windows.Forms.DateTimePicker();
            this.txt_picture_path = new System.Windows.Forms.TextBox();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.txt_staff_relationship = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Staff_Bornplace = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.picbox_staff = new System.Windows.Forms.PictureBox();
            this.picbox_dummy = new System.Windows.Forms.PictureBox();
            this.txt_lname = new System.Windows.Forms.TextBox();
            this.gbStudentDetails = new System.Windows.Forms.GroupBox();
            this.txtprice = new NumericTextBox.NumericTextBox();
            this.txtuser_type = new System.Windows.Forms.TextBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.txt_pic_path = new System.Windows.Forms.TextBox();
            this.checkbox_Loadid = new System.Windows.Forms.CheckBox();
            this.cmbo_year = new System.Windows.Forms.ComboBox();
            this.datetime = new System.Windows.Forms.DateTimePicker();
            this.button15 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.cmbo_name = new System.Windows.Forms.ComboBox();
            this.cmbo_id = new System.Windows.Forms.ComboBox();
            this.cmbo_model = new System.Windows.Forms.ComboBox();
            this.cmbo_make = new System.Windows.Forms.ComboBox();
            this.cmbo_standerd = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.date = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtdisc = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.picbox_product = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.cmbo_discount = new System.Windows.Forms.ComboBox();
            this.cmbo_fit = new System.Windows.Forms.ComboBox();
            this.cmbo_material = new System.Windows.Forms.ComboBox();
            this.cmbo_return = new System.Windows.Forms.ComboBox();
            this.cmbo_garanty = new System.Windows.Forms.ComboBox();
            this.cmbo_condi = new System.Windows.Forms.ComboBox();
            this.cmbo_quality = new System.Windows.Forms.ComboBox();
            this.cmbo_country = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.txtothernote = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label34 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txt_nic = new NumericTextBox.NumericTextBox();
            this.cmbo_fname = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_uname = new System.Windows.Forms.TextBox();
            this.txt_pwd2 = new System.Windows.Forms.TextBox();
            this.txt_pwd = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.txt_town = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbo_title = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_email = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_land = new NumericTextBox.NumericTextBox();
            this.txt_add = new System.Windows.Forms.TextBox();
            this.Txt_phone_numaric = new NumericTextBox.NumericTextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.cmbo_waranty = new System.Windows.Forms.ComboBox();
            this.cmbo_color = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.txt_capa = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button16 = new System.Windows.Forms.Button();
            this.update = new System.Windows.Forms.Button();
            this.delete = new System.Windows.Forms.Button();
            this.save = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.tcMain = new System.Windows.Forms.TabControl();
            this.Products = new System.Windows.Forms.TabPage();
            this.staff = new System.Windows.Forms.TabPage();
            this.lblMainTitle = new System.Windows.Forms.Label();
            this.btn_ok = new System.Windows.Forms.Button();
            this.label_error_green = new System.Windows.Forms.Label();
            this.Lbl_deleted = new System.Windows.Forms.Label();
            this.btnallow_delete = new System.Windows.Forms.Button();
            this.btnCancel_Delete = new System.Windows.Forms.Button();
            this.lbl_update = new System.Windows.Forms.Label();
            this.btn_update_allow = new System.Windows.Forms.Button();
            this.btn_update_cancel = new System.Windows.Forms.Button();
            this.picboxwhite = new System.Windows.Forms.PictureBox();
            this.btn_staff_delete_allow = new System.Windows.Forms.Button();
            this.btn_allow_update_staff = new System.Windows.Forms.Button();
            this.lbl_empty = new System.Windows.Forms.Label();
            this.btn_allow_delete_dealer = new System.Windows.Forms.Button();
            this.btn_allow_update_dealer = new System.Windows.Forms.Button();
            this.vonders.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_staff)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_dummy)).BeginInit();
            this.gbStudentDetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_product)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tcMain.SuspendLayout();
            this.Products.SuspendLayout();
            this.staff.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picboxwhite)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbo_staffsec
            // 
            this.cmbo_staffsec.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_staffsec.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_staffsec.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbo_staffsec.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_staffsec.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_staffsec.FormattingEnabled = true;
            this.cmbo_staffsec.Items.AddRange(new object[] {
            "IT",
            "HR",
            "Cashier",
            "Admin",
            "Staff"});
            this.cmbo_staffsec.Location = new System.Drawing.Point(651, 160);
            this.cmbo_staffsec.Name = "cmbo_staffsec";
            this.cmbo_staffsec.Size = new System.Drawing.Size(291, 29);
            this.cmbo_staffsec.TabIndex = 9;
            // 
            // txt_staff_marks
            // 
            this.txt_staff_marks.BackColor = System.Drawing.Color.Gainsboro;
            this.txt_staff_marks.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_staff_marks.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_staff_marks.Location = new System.Drawing.Point(167, 257);
            this.txt_staff_marks.Multiline = true;
            this.txt_staff_marks.Name = "txt_staff_marks";
            this.txt_staff_marks.Size = new System.Drawing.Size(624, 66);
            this.txt_staff_marks.TabIndex = 6;
            // 
            // cmbo_staff_religion
            // 
            this.cmbo_staff_religion.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_staff_religion.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_staff_religion.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbo_staff_religion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_staff_religion.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_staff_religion.FormattingEnabled = true;
            this.cmbo_staff_religion.Items.AddRange(new object[] {
            "BUDDHISM",
            "CHRISTIANITY",
            "HINDUISM",
            "ISLAM"});
            this.cmbo_staff_religion.Location = new System.Drawing.Point(166, 176);
            this.cmbo_staff_religion.Name = "cmbo_staff_religion";
            this.cmbo_staff_religion.Size = new System.Drawing.Size(325, 29);
            this.cmbo_staff_religion.Sorted = true;
            this.cmbo_staff_religion.TabIndex = 4;
            // 
            // cmbo_staff_type
            // 
            this.cmbo_staff_type.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_staff_type.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_staff_type.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbo_staff_type.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_staff_type.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_staff_type.FormattingEnabled = true;
            this.cmbo_staff_type.Items.AddRange(new object[] {
            "Permanant",
            "Temporary",
            "Trainee",
            "Admin"});
            this.cmbo_staff_type.Location = new System.Drawing.Point(166, 135);
            this.cmbo_staff_type.Name = "cmbo_staff_type";
            this.cmbo_staff_type.Size = new System.Drawing.Size(325, 29);
            this.cmbo_staff_type.TabIndex = 3;
            // 
            // cmbo_staff_gender
            // 
            this.cmbo_staff_gender.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_staff_gender.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_staff_gender.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbo_staff_gender.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_staff_gender.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_staff_gender.FormattingEnabled = true;
            this.cmbo_staff_gender.Items.AddRange(new object[] {
            "FEMALE",
            "MALE"});
            this.cmbo_staff_gender.Location = new System.Drawing.Point(166, 96);
            this.cmbo_staff_gender.Name = "cmbo_staff_gender";
            this.cmbo_staff_gender.Size = new System.Drawing.Size(325, 29);
            this.cmbo_staff_gender.TabIndex = 2;
            // 
            // vonders
            // 
            this.vonders.BackColor = System.Drawing.Color.White;
            this.vonders.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.vonders.Controls.Add(this.groupBox7);
            this.vonders.Controls.Add(this.label6);
            this.vonders.Location = new System.Drawing.Point(4, 35);
            this.vonders.Name = "vonders";
            this.vonders.Padding = new System.Windows.Forms.Padding(3);
            this.vonders.Size = new System.Drawing.Size(1357, 721);
            this.vonders.TabIndex = 3;
            this.vonders.Text = "Dealers";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.email);
            this.groupBox7.Controls.Add(this.label12);
            this.groupBox7.Controls.Add(this.txt_dealer_name);
            this.groupBox7.Controls.Add(this.cmbo_spec_item);
            this.groupBox7.Controls.Add(this.txt_company);
            this.groupBox7.Controls.Add(this.button6);
            this.groupBox7.Controls.Add(this.cmbo_bank);
            this.groupBox7.Controls.Add(this.button7);
            this.groupBox7.Controls.Add(this.checkBox2);
            this.groupBox7.Controls.Add(this.button21);
            this.groupBox7.Controls.Add(this.checkBox4);
            this.groupBox7.Controls.Add(this.button22);
            this.groupBox7.Controls.Add(this.datetime_dealer);
            this.groupBox7.Controls.Add(this.button23);
            this.groupBox7.Controls.Add(this.button24);
            this.groupBox7.Controls.Add(this.acc_no);
            this.groupBox7.Controls.Add(this.reg_dealer);
            this.groupBox7.Controls.Add(this.cmbo_dealer_id);
            this.groupBox7.Controls.Add(this.txt_add_dealer);
            this.groupBox7.Controls.Add(this.label59);
            this.groupBox7.Controls.Add(this.label60);
            this.groupBox7.Controls.Add(this.label62);
            this.groupBox7.Controls.Add(this.label63);
            this.groupBox7.Controls.Add(this.label64);
            this.groupBox7.Controls.Add(this.label65);
            this.groupBox7.Controls.Add(this.label66);
            this.groupBox7.Controls.Add(this.label67);
            this.groupBox7.Controls.Add(this.label68);
            this.groupBox7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox7.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.ForeColor = System.Drawing.Color.Black;
            this.groupBox7.Location = new System.Drawing.Point(6, 1);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(1301, 412);
            this.groupBox7.TabIndex = 5;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Student Details";
            this.groupBox7.Enter += new System.EventHandler(this.groupBox7_Enter);
            // 
            // email
            // 
            this.email.BackColor = System.Drawing.Color.Gainsboro;
            this.email.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.email.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email.Location = new System.Drawing.Point(190, 208);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(325, 26);
            this.email.TabIndex = 4;
            this.email.Validating += new System.ComponentModel.CancelEventHandler(this.email_Validating);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(6, 211);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 21);
            this.label12.TabIndex = 74;
            this.label12.Text = "E-mail";
            // 
            // txt_dealer_name
            // 
            this.txt_dealer_name.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txt_dealer_name.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txt_dealer_name.BackColor = System.Drawing.Color.LightPink;
            this.txt_dealer_name.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.txt_dealer_name.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_dealer_name.FormattingEnabled = true;
            this.txt_dealer_name.Location = new System.Drawing.Point(190, 75);
            this.txt_dealer_name.Name = "txt_dealer_name";
            this.txt_dealer_name.Size = new System.Drawing.Size(328, 29);
            this.txt_dealer_name.TabIndex = 1;
            this.txt_dealer_name.SelectedIndexChanged += new System.EventHandler(this.txt_dealer_name_SelectedIndexChanged);
            this.txt_dealer_name.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_dealer_name_KeyPress_1);
            this.txt_dealer_name.Validating += new System.ComponentModel.CancelEventHandler(this.txt_dealer_name_Validating_1);
            // 
            // cmbo_spec_item
            // 
            this.cmbo_spec_item.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_spec_item.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_spec_item.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbo_spec_item.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_spec_item.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_spec_item.FormattingEnabled = true;
            this.cmbo_spec_item.Items.AddRange(new object[] {
            "Body",
            "Engine",
            "Tyre",
            "Electrical",
            "Other"});
            this.cmbo_spec_item.Location = new System.Drawing.Point(190, 116);
            this.cmbo_spec_item.Name = "cmbo_spec_item";
            this.cmbo_spec_item.Size = new System.Drawing.Size(328, 29);
            this.cmbo_spec_item.TabIndex = 2;
            // 
            // txt_company
            // 
            this.txt_company.BackColor = System.Drawing.Color.Gainsboro;
            this.txt_company.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_company.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_company.Location = new System.Drawing.Point(682, 78);
            this.txt_company.Name = "txt_company";
            this.txt_company.Size = new System.Drawing.Size(286, 26);
            this.txt_company.TabIndex = 6;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.White;
            this.button6.Image = ((System.Drawing.Image)(resources.GetObject("button6.Image")));
            this.button6.Location = new System.Drawing.Point(430, 334);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(55, 48);
            this.button6.TabIndex = 66;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // cmbo_bank
            // 
            this.cmbo_bank.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_bank.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_bank.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbo_bank.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_bank.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_bank.FormattingEnabled = true;
            this.cmbo_bank.Items.AddRange(new object[] {
            "Comercial",
            "BOC",
            "HSBC",
            "Pan Asia ",
            "NDB",
            "Seylan",
            "HNB",
            "Peoples ",
            "Nation Trust",
            "Amana "});
            this.cmbo_bank.Location = new System.Drawing.Point(682, 203);
            this.cmbo_bank.Name = "cmbo_bank";
            this.cmbo_bank.Size = new System.Drawing.Size(286, 29);
            this.cmbo_bank.TabIndex = 9;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.White;
            this.button7.Image = ((System.Drawing.Image)(resources.GetObject("button7.Image")));
            this.button7.Location = new System.Drawing.Point(744, 334);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(55, 48);
            this.button7.TabIndex = 65;
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox2.Location = new System.Drawing.Point(740, 33);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(143, 25);
            this.checkBox2.TabIndex = 68;
            this.checkBox2.Text = "Search By Name";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged_1);
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.White;
            this.button21.Image = ((System.Drawing.Image)(resources.GetObject("button21.Image")));
            this.button21.Location = new System.Drawing.Point(664, 334);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(55, 48);
            this.button21.TabIndex = 64;
            this.button21.UseVisualStyleBackColor = false;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox4.Location = new System.Drawing.Point(568, 33);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(141, 25);
            this.checkBox4.TabIndex = 67;
            this.checkBox4.Text = "Delete / Update ";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            this.checkBox4.CheckStateChanged += new System.EventHandler(this.checkBox4_CheckStateChanged);
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.White;
            this.button22.Image = ((System.Drawing.Image)(resources.GetObject("button22.Image")));
            this.button22.Location = new System.Drawing.Point(591, 334);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(55, 48);
            this.button22.TabIndex = 10;
            this.button22.UseVisualStyleBackColor = false;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // datetime_dealer
            // 
            this.datetime_dealer.Location = new System.Drawing.Point(190, 162);
            this.datetime_dealer.Name = "datetime_dealer";
            this.datetime_dealer.Size = new System.Drawing.Size(325, 25);
            this.datetime_dealer.TabIndex = 3;
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.White;
            this.button23.Image = ((System.Drawing.Image)(resources.GetObject("button23.Image")));
            this.button23.Location = new System.Drawing.Point(364, 334);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(55, 48);
            this.button23.TabIndex = 60;
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.White;
            this.button24.Image = ((System.Drawing.Image)(resources.GetObject("button24.Image")));
            this.button24.Location = new System.Drawing.Point(295, 334);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(55, 48);
            this.button24.TabIndex = 58;
            this.button24.UseVisualStyleBackColor = false;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // acc_no
            // 
            this.acc_no.BackColor = System.Drawing.Color.LightPink;
            this.acc_no.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.acc_no.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acc_no.Location = new System.Drawing.Point(682, 159);
            this.acc_no.Name = "acc_no";
            this.acc_no.Size = new System.Drawing.Size(286, 26);
            this.acc_no.TabIndex = 8;
            this.acc_no.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.acc_no_KeyPress);
            this.acc_no.Validating += new System.ComponentModel.CancelEventHandler(this.acc_no_Validating);
            // 
            // reg_dealer
            // 
            this.reg_dealer.BackColor = System.Drawing.Color.LightPink;
            this.reg_dealer.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.reg_dealer.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reg_dealer.Location = new System.Drawing.Point(682, 114);
            this.reg_dealer.Name = "reg_dealer";
            this.reg_dealer.Size = new System.Drawing.Size(286, 26);
            this.reg_dealer.TabIndex = 7;
            this.reg_dealer.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.reg_dealer_KeyPress);
            this.reg_dealer.Validating += new System.ComponentModel.CancelEventHandler(this.reg_dealer_Validating);
            // 
            // cmbo_dealer_id
            // 
            this.cmbo_dealer_id.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_dealer_id.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_dealer_id.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbo_dealer_id.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_dealer_id.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_dealer_id.FormattingEnabled = true;
            this.cmbo_dealer_id.Location = new System.Drawing.Point(190, 33);
            this.cmbo_dealer_id.Name = "cmbo_dealer_id";
            this.cmbo_dealer_id.Size = new System.Drawing.Size(328, 29);
            this.cmbo_dealer_id.TabIndex = 0;
            this.cmbo_dealer_id.SelectedIndexChanged += new System.EventHandler(this.cmbo_dealer_id_SelectedIndexChanged);
            // 
            // txt_add_dealer
            // 
            this.txt_add_dealer.BackColor = System.Drawing.Color.Gainsboro;
            this.txt_add_dealer.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_add_dealer.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_add_dealer.Location = new System.Drawing.Point(190, 255);
            this.txt_add_dealer.Multiline = true;
            this.txt_add_dealer.Name = "txt_add_dealer";
            this.txt_add_dealer.Size = new System.Drawing.Size(624, 54);
            this.txt_add_dealer.TabIndex = 5;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(6, 267);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(115, 21);
            this.label59.TabIndex = 10;
            this.label59.Text = "Dealer Address";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(551, 206);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(44, 21);
            this.label60.TabIndex = 9;
            this.label60.Text = "Bank";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.Location = new System.Drawing.Point(551, 162);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(128, 21);
            this.label62.TabIndex = 7;
            this.label62.Text = "Account Number";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.Location = new System.Drawing.Point(6, 162);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(103, 21);
            this.label63.TabIndex = 6;
            this.label63.Text = "Register Date";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(551, 119);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(101, 21);
            this.label64.TabIndex = 5;
            this.label64.Text = "REG Number";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(6, 119);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(98, 21);
            this.label65.TabIndex = 4;
            this.label65.Text = "Specific Item\r\n";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(549, 78);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(127, 21);
            this.label66.TabIndex = 3;
            this.label66.Text = "Company Name ";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(6, 78);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(52, 21);
            this.label67.TabIndex = 1;
            this.label67.Text = "Name";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.Location = new System.Drawing.Point(6, 37);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(76, 21);
            this.label68.TabIndex = 0;
            this.label68.Text = "Dealer Id \r\n";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(353, 258);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 25);
            this.label6.TabIndex = 0;
            this.label6.Text = "label6";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(6, 130);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(69, 21);
            this.label35.TabIndex = 25;
            this.label35.Text = "N I C No\r\n";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txt_staffile);
            this.groupBox5.Controls.Add(this.cmbo_staff_id);
            this.groupBox5.Controls.Add(this.chek_name);
            this.groupBox5.Controls.Add(this.checkBox3);
            this.groupBox5.Controls.Add(this.Staff_dateofbirth);
            this.groupBox5.Controls.Add(this.staff_addmissiondate);
            this.groupBox5.Controls.Add(this.txt_picture_path);
            this.groupBox5.Controls.Add(this.button18);
            this.groupBox5.Controls.Add(this.button19);
            this.groupBox5.Controls.Add(this.button20);
            this.groupBox5.Controls.Add(this.txt_staff_relationship);
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Controls.Add(this.cmbo_staffsec);
            this.groupBox5.Controls.Add(this.Staff_Bornplace);
            this.groupBox5.Controls.Add(this.txt_staff_marks);
            this.groupBox5.Controls.Add(this.cmbo_staff_religion);
            this.groupBox5.Controls.Add(this.cmbo_staff_type);
            this.groupBox5.Controls.Add(this.cmbo_staff_gender);
            this.groupBox5.Controls.Add(this.label43);
            this.groupBox5.Controls.Add(this.label44);
            this.groupBox5.Controls.Add(this.label45);
            this.groupBox5.Controls.Add(this.label46);
            this.groupBox5.Controls.Add(this.label47);
            this.groupBox5.Controls.Add(this.label48);
            this.groupBox5.Controls.Add(this.label49);
            this.groupBox5.Controls.Add(this.label50);
            this.groupBox5.Controls.Add(this.label52);
            this.groupBox5.Controls.Add(this.label53);
            this.groupBox5.Controls.Add(this.picbox_staff);
            this.groupBox5.Controls.Add(this.picbox_dummy);
            this.groupBox5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox5.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.ForeColor = System.Drawing.Color.Black;
            this.groupBox5.Location = new System.Drawing.Point(6, 1);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(1311, 342);
            this.groupBox5.TabIndex = 3;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Staff Details";
            // 
            // txt_staffile
            // 
            this.txt_staffile.BackColor = System.Drawing.Color.LightPink;
            this.txt_staffile.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_staffile.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_staffile.Location = new System.Drawing.Point(651, 198);
            this.txt_staffile.Name = "txt_staffile";
            this.txt_staffile.Size = new System.Drawing.Size(291, 26);
            this.txt_staffile.TabIndex = 10;
            this.txt_staffile.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_staffile_KeyPress);
            this.txt_staffile.Validating += new System.ComponentModel.CancelEventHandler(this.txt_staffile_Validating);
            // 
            // cmbo_staff_id
            // 
            this.cmbo_staff_id.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_staff_id.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_staff_id.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbo_staff_id.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_staff_id.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_staff_id.FormattingEnabled = true;
            this.cmbo_staff_id.Location = new System.Drawing.Point(166, 22);
            this.cmbo_staff_id.Name = "cmbo_staff_id";
            this.cmbo_staff_id.Size = new System.Drawing.Size(325, 29);
            this.cmbo_staff_id.TabIndex = 0;
            this.cmbo_staff_id.SelectedIndexChanged += new System.EventHandler(this.cmbo_staff_id_SelectedIndexChanged);
            // 
            // chek_name
            // 
            this.chek_name.AutoSize = true;
            this.chek_name.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chek_name.Location = new System.Drawing.Point(717, 39);
            this.chek_name.Name = "chek_name";
            this.chek_name.Size = new System.Drawing.Size(143, 25);
            this.chek_name.TabIndex = 59;
            this.chek_name.Text = "Search By Name";
            this.chek_name.UseVisualStyleBackColor = true;
            this.chek_name.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox3.Location = new System.Drawing.Point(545, 39);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(141, 25);
            this.checkBox3.TabIndex = 58;
            this.checkBox3.Text = "Delete / Update ";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // Staff_dateofbirth
            // 
            this.Staff_dateofbirth.Location = new System.Drawing.Point(651, 129);
            this.Staff_dateofbirth.Name = "Staff_dateofbirth";
            this.Staff_dateofbirth.Size = new System.Drawing.Size(291, 25);
            this.Staff_dateofbirth.TabIndex = 8;
            // 
            // staff_addmissiondate
            // 
            this.staff_addmissiondate.Location = new System.Drawing.Point(167, 60);
            this.staff_addmissiondate.Name = "staff_addmissiondate";
            this.staff_addmissiondate.Size = new System.Drawing.Size(324, 25);
            this.staff_addmissiondate.TabIndex = 1;
            // 
            // txt_picture_path
            // 
            this.txt_picture_path.BackColor = System.Drawing.Color.Gainsboro;
            this.txt_picture_path.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_picture_path.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_picture_path.Location = new System.Drawing.Point(975, 242);
            this.txt_picture_path.Name = "txt_picture_path";
            this.txt_picture_path.Size = new System.Drawing.Size(315, 26);
            this.txt_picture_path.TabIndex = 54;
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.White;
            this.button18.Image = ((System.Drawing.Image)(resources.GetObject("button18.Image")));
            this.button18.Location = new System.Drawing.Point(1188, 275);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(55, 48);
            this.button18.TabIndex = 53;
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.White;
            this.button19.Image = ((System.Drawing.Image)(resources.GetObject("button19.Image")));
            this.button19.Location = new System.Drawing.Point(1109, 275);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(55, 48);
            this.button19.TabIndex = 52;
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.White;
            this.button20.Image = ((System.Drawing.Image)(resources.GetObject("button20.Image")));
            this.button20.Location = new System.Drawing.Point(1032, 275);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(55, 48);
            this.button20.TabIndex = 11;
            this.button20.UseVisualStyleBackColor = false;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // txt_staff_relationship
            // 
            this.txt_staff_relationship.BackColor = System.Drawing.Color.Gainsboro;
            this.txt_staff_relationship.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_staff_relationship.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_staff_relationship.Location = new System.Drawing.Point(167, 218);
            this.txt_staff_relationship.Name = "txt_staff_relationship";
            this.txt_staff_relationship.Size = new System.Drawing.Size(324, 26);
            this.txt_staff_relationship.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(7, 217);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(155, 21);
            this.label3.TabIndex = 32;
            this.label3.Text = "Realationship Status ";
            // 
            // Staff_Bornplace
            // 
            this.Staff_Bornplace.BackColor = System.Drawing.Color.Gainsboro;
            this.Staff_Bornplace.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Staff_Bornplace.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Staff_Bornplace.Location = new System.Drawing.Point(651, 90);
            this.Staff_Bornplace.Name = "Staff_Bornplace";
            this.Staff_Bornplace.Size = new System.Drawing.Size(288, 26);
            this.Staff_Bornplace.TabIndex = 7;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(7, 260);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(154, 21);
            this.label43.TabIndex = 10;
            this.label43.Text = "Identification Marks :";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(526, 198);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(96, 21);
            this.label44.TabIndex = 9;
            this.label44.Text = "File Number\r\n";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(6, 175);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(74, 21);
            this.label45.TabIndex = 8;
            this.label45.Text = "Religion :";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(526, 163);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(68, 21);
            this.label46.TabIndex = 7;
            this.label46.Text = "Section :";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(6, 130);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(79, 21);
            this.label47.TabIndex = 6;
            this.label47.Text = "Staff Type\r\n";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(526, 128);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(104, 21);
            this.label48.TabIndex = 5;
            this.label48.Text = "Date of Birth :";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(6, 95);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(79, 21);
            this.label49.TabIndex = 4;
            this.label49.Text = "Gender : *";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(526, 93);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(104, 21);
            this.label50.TabIndex = 3;
            this.label50.Text = "Place Of Birth";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(6, 60);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(126, 21);
            this.label52.TabIndex = 1;
            this.label52.Text = "Admission Date :";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(6, 25);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(59, 21);
            this.label53.TabIndex = 0;
            this.label53.Text = "Staff Id\r\n";
            // 
            // picbox_staff
            // 
            this.picbox_staff.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picbox_staff.BackgroundImage")));
            this.picbox_staff.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picbox_staff.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picbox_staff.Location = new System.Drawing.Point(1008, 25);
            this.picbox_staff.Name = "picbox_staff";
            this.picbox_staff.Size = new System.Drawing.Size(253, 213);
            this.picbox_staff.TabIndex = 50;
            this.picbox_staff.TabStop = false;
            // 
            // picbox_dummy
            // 
            this.picbox_dummy.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picbox_dummy.BackgroundImage")));
            this.picbox_dummy.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picbox_dummy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picbox_dummy.Image = ((System.Drawing.Image)(resources.GetObject("picbox_dummy.Image")));
            this.picbox_dummy.Location = new System.Drawing.Point(1008, 24);
            this.picbox_dummy.Name = "picbox_dummy";
            this.picbox_dummy.Size = new System.Drawing.Size(246, 213);
            this.picbox_dummy.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picbox_dummy.TabIndex = 60;
            this.picbox_dummy.TabStop = false;
            // 
            // txt_lname
            // 
            this.txt_lname.BackColor = System.Drawing.Color.Gainsboro;
            this.txt_lname.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_lname.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_lname.Location = new System.Drawing.Point(166, 94);
            this.txt_lname.Name = "txt_lname";
            this.txt_lname.Size = new System.Drawing.Size(323, 26);
            this.txt_lname.TabIndex = 2;
            // 
            // gbStudentDetails
            // 
            this.gbStudentDetails.Controls.Add(this.txtprice);
            this.gbStudentDetails.Controls.Add(this.txtuser_type);
            this.gbStudentDetails.Controls.Add(this.checkBox1);
            this.gbStudentDetails.Controls.Add(this.txt_pic_path);
            this.gbStudentDetails.Controls.Add(this.checkbox_Loadid);
            this.gbStudentDetails.Controls.Add(this.cmbo_year);
            this.gbStudentDetails.Controls.Add(this.datetime);
            this.gbStudentDetails.Controls.Add(this.button15);
            this.gbStudentDetails.Controls.Add(this.button1);
            this.gbStudentDetails.Controls.Add(this.button14);
            this.gbStudentDetails.Controls.Add(this.cmbo_name);
            this.gbStudentDetails.Controls.Add(this.cmbo_id);
            this.gbStudentDetails.Controls.Add(this.cmbo_model);
            this.gbStudentDetails.Controls.Add(this.cmbo_make);
            this.gbStudentDetails.Controls.Add(this.cmbo_standerd);
            this.gbStudentDetails.Controls.Add(this.label17);
            this.gbStudentDetails.Controls.Add(this.label16);
            this.gbStudentDetails.Controls.Add(this.label15);
            this.gbStudentDetails.Controls.Add(this.label14);
            this.gbStudentDetails.Controls.Add(this.label13);
            this.gbStudentDetails.Controls.Add(this.label11);
            this.gbStudentDetails.Controls.Add(this.label10);
            this.gbStudentDetails.Controls.Add(this.date);
            this.gbStudentDetails.Controls.Add(this.label7);
            this.gbStudentDetails.Controls.Add(this.txtdisc);
            this.gbStudentDetails.Controls.Add(this.textBox1);
            this.gbStudentDetails.Controls.Add(this.picbox_product);
            this.gbStudentDetails.Controls.Add(this.pictureBox2);
            this.gbStudentDetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gbStudentDetails.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbStudentDetails.ForeColor = System.Drawing.Color.Black;
            this.gbStudentDetails.Location = new System.Drawing.Point(6, 6);
            this.gbStudentDetails.Name = "gbStudentDetails";
            this.gbStudentDetails.Size = new System.Drawing.Size(1284, 350);
            this.gbStudentDetails.TabIndex = 0;
            this.gbStudentDetails.TabStop = false;
            this.gbStudentDetails.Text = "Product Deatail";
            // 
            // txtprice
            // 
            this.txtprice.BackColor = System.Drawing.Color.Pink;
            this.txtprice.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtprice.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtprice.Location = new System.Drawing.Point(166, 103);
            this.txtprice.Name = "txtprice";
            this.txtprice.Size = new System.Drawing.Size(262, 26);
            this.txtprice.TabIndex = 2;
            this.txtprice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtprice_KeyPress_1);
            this.txtprice.Validating += new System.ComponentModel.CancelEventHandler(this.txtprice_Validating_1);
            // 
            // txtuser_type
            // 
            this.txtuser_type.BackColor = System.Drawing.Color.Gainsboro;
            this.txtuser_type.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtuser_type.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtuser_type.Location = new System.Drawing.Point(969, 12);
            this.txtuser_type.Name = "txtuser_type";
            this.txtuser_type.Size = new System.Drawing.Size(252, 26);
            this.txtuser_type.TabIndex = 50;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(646, 24);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(143, 25);
            this.checkBox1.TabIndex = 47;
            this.checkBox1.Text = "Search By Name";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            this.checkBox1.CheckStateChanged += new System.EventHandler(this.checkBox1_CheckStateChanged);
            // 
            // txt_pic_path
            // 
            this.txt_pic_path.BackColor = System.Drawing.Color.Gainsboro;
            this.txt_pic_path.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_pic_path.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_pic_path.Location = new System.Drawing.Point(959, 256);
            this.txt_pic_path.Name = "txt_pic_path";
            this.txt_pic_path.Size = new System.Drawing.Size(203, 26);
            this.txt_pic_path.TabIndex = 9;
            this.txt_pic_path.Text = "gh";
            // 
            // checkbox_Loadid
            // 
            this.checkbox_Loadid.AutoSize = true;
            this.checkbox_Loadid.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkbox_Loadid.Location = new System.Drawing.Point(474, 24);
            this.checkbox_Loadid.Name = "checkbox_Loadid";
            this.checkbox_Loadid.Size = new System.Drawing.Size(141, 25);
            this.checkbox_Loadid.TabIndex = 46;
            this.checkbox_Loadid.Text = "Delete / Update ";
            this.checkbox_Loadid.UseVisualStyleBackColor = true;
            this.checkbox_Loadid.CheckedChanged += new System.EventHandler(this.checkbox_Loadid_CheckedChanged);
            // 
            // cmbo_year
            // 
            this.cmbo_year.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_year.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_year.BackColor = System.Drawing.Color.Pink;
            this.cmbo_year.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_year.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_year.FormattingEnabled = true;
            this.cmbo_year.Items.AddRange(new object[] {
            "1980",
            "1981",
            "1982",
            "1983",
            "1984",
            "1985",
            "1986",
            "1987",
            "1988",
            "1989",
            "1990",
            "----------",
            "1991",
            "1992",
            "1993",
            "1994",
            "1995",
            "1996",
            "1997",
            "1998",
            "1999",
            "----------",
            "2000",
            "2001",
            "2002",
            "2003",
            "2004",
            "2005",
            "2006",
            "2007",
            "2008",
            "2009",
            "2010",
            "----------",
            "2011",
            "2012",
            "2013",
            "2014",
            "2015"});
            this.cmbo_year.Location = new System.Drawing.Point(646, 145);
            this.cmbo_year.Name = "cmbo_year";
            this.cmbo_year.Size = new System.Drawing.Size(274, 29);
            this.cmbo_year.TabIndex = 8;
            this.cmbo_year.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbo_year_KeyPress);
            this.cmbo_year.Validating += new System.ComponentModel.CancelEventHandler(this.cmbo_year_Validating);
            // 
            // datetime
            // 
            this.datetime.Location = new System.Drawing.Point(166, 63);
            this.datetime.Name = "datetime";
            this.datetime.Size = new System.Drawing.Size(262, 25);
            this.datetime.TabIndex = 1;
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.White;
            this.button15.Image = ((System.Drawing.Image)(resources.GetObject("button15.Image")));
            this.button15.Location = new System.Drawing.Point(1156, 292);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(55, 48);
            this.button15.TabIndex = 43;
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(1077, 292);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(55, 48);
            this.button1.TabIndex = 42;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.White;
            this.button14.Image = ((System.Drawing.Image)(resources.GetObject("button14.Image")));
            this.button14.Location = new System.Drawing.Point(1000, 292);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(55, 48);
            this.button14.TabIndex = 10;
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // cmbo_name
            // 
            this.cmbo_name.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_name.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_name.BackColor = System.Drawing.Color.Pink;
            this.cmbo_name.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_name.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_name.FormattingEnabled = true;
            this.cmbo_name.Location = new System.Drawing.Point(646, 57);
            this.cmbo_name.Name = "cmbo_name";
            this.cmbo_name.Size = new System.Drawing.Size(274, 29);
            this.cmbo_name.TabIndex = 6;
            this.cmbo_name.SelectedIndexChanged += new System.EventHandler(this.cmbo_name_SelectedIndexChanged);
            this.cmbo_name.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbo_name_KeyPress);
            this.cmbo_name.Validating += new System.ComponentModel.CancelEventHandler(this.cmbo_name_Validating);
            // 
            // cmbo_id
            // 
            this.cmbo_id.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_id.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_id.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbo_id.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_id.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_id.FormattingEnabled = true;
            this.cmbo_id.Location = new System.Drawing.Point(166, 22);
            this.cmbo_id.Name = "cmbo_id";
            this.cmbo_id.Size = new System.Drawing.Size(262, 29);
            this.cmbo_id.TabIndex = 0;
            this.cmbo_id.SelectedIndexChanged += new System.EventHandler(this.cmbo_id_SelectedIndexChanged);
            // 
            // cmbo_model
            // 
            this.cmbo_model.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_model.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_model.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbo_model.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_model.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_model.FormattingEnabled = true;
            this.cmbo_model.Items.AddRange(new object[] {
            "Car",
            "Van ",
            "Lorry ",
            "Bus",
            "Bike",
            "Autoricshow ",
            "Double Cab",
            "Jeep",
            "Tracktor ",
            "Havaster"});
            this.cmbo_model.Location = new System.Drawing.Point(646, 101);
            this.cmbo_model.Name = "cmbo_model";
            this.cmbo_model.Size = new System.Drawing.Size(274, 29);
            this.cmbo_model.TabIndex = 7;
            // 
            // cmbo_make
            // 
            this.cmbo_make.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_make.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_make.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbo_make.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_make.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_make.FormattingEnabled = true;
            this.cmbo_make.Items.AddRange(new object[] {
            "",
            "Abarth",
            "ABI",
            "Acura",
            "Alfa Romeo",
            "Ashok Leyland",
            "Audi",
            "Autobianchi",
            "Bajaj",
            "Bharat",
            "Bitter",
            "BML",
            "BMW",
            "BMW",
            "Büssing",
            "Chinkara",
            "Cizeta",
            "Daihatsu",
            "Datsun",
            "DC",
            "De Tomaso",
            "Dome",
            "DR Motor",
            "DRDO",
            "Eicher",
            "Escorts",
            "Ferrari",
            "Fiat",
            "Force",
            "Gumpert",
            "Hero",
            "Hindustan",
            "Hino",
            "Honda",
            "ICML",
            "Infiniti",
            "Intermeccanica",
            "Isuzu",
            "Lamborghini",
            "Lancia",
            "Lexus",
            "Mahindra",
            "MAN",
            "Maruti Suzuki",
            "Maserati",
            "Mazda",
            "Mercedes-Benz",
            "Micro",
            "Mitsubishi",
            "Mitsuoka",
            "Multicar",
            "Neoplan",
            "Nissan",
            "NSU",
            "Opel",
            "Pagani",
            "Porsche",
            "Premier",
            "Robur",
            "Royal Enfield",
            "San",
            "Scion",
            "Siata",
            "Subaru",
            "Suzuki",
            "Vignale",
            "Volkswagen"});
            this.cmbo_make.Location = new System.Drawing.Point(166, 146);
            this.cmbo_make.Name = "cmbo_make";
            this.cmbo_make.Size = new System.Drawing.Size(262, 29);
            this.cmbo_make.Sorted = true;
            this.cmbo_make.TabIndex = 3;
            // 
            // cmbo_standerd
            // 
            this.cmbo_standerd.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_standerd.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_standerd.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbo_standerd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_standerd.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_standerd.FormattingEnabled = true;
            this.cmbo_standerd.Items.AddRange(new object[] {
            "ISO(9000)",
            "ISO (9001)",
            "ISO/TC 22/SC 1 Ignition equipment",
            "ISO/TC 22/SC 2 Braking systems and equipment",
            "ISO/TC 22/SC 3 Electrical and electronic equipment",
            "ISO/TC 22/SC 4 Caravans and light trailers",
            "ISO/TC 22/SC 5 Engine tests",
            "ISO/TC 22/SC 7 Injection equipment and filters for use on road vehicles",
            "ISO/TC 22/SC 8 Lighting and light-signalling",
            "ISO/TC 22/SC 9 Vehicle dynamics and road-holding ability",
            "ISO/TC 22/SC 10 Impact test procedures",
            "ISO/TC 22/SC 11 Safety glazing materials",
            "ISO 3795:1989  Road vehicles, and tractors and machinery for agriculture and fore" +
                "stry ",
            "ISO/TC 22/SC 34 Propulsion, powertrain and powertrain fluids",
            "ISO/TC 22/SC 35 Lighting and visibility",
            "ISO/TC 22/SC 36 Safety aspects and impact testing",
            "ISO/TC 22/SC 37 Electrically propelled vehicles",
            "ISO/TC 22/SC 38 Motorcycles and mopeds",
            "ISO/TC 22/SC 39 Ergonomics",
            "ISO/TC 22/SC 40 Specific aspects for commercial vehicles, busses and trailers",
            "ISO/TC 22/SC 41 Specific aspects for gaseous fuels"});
            this.cmbo_standerd.Location = new System.Drawing.Point(166, 186);
            this.cmbo_standerd.Name = "cmbo_standerd";
            this.cmbo_standerd.Size = new System.Drawing.Size(561, 29);
            this.cmbo_standerd.TabIndex = 4;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(6, 229);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(96, 21);
            this.label17.TabIndex = 10;
            this.label17.Text = "Describtion :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(470, 150);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(48, 21);
            this.label16.TabIndex = 9;
            this.label16.Text = "Year :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(6, 149);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(55, 21);
            this.label15.TabIndex = 8;
            this.label15.Text = "Make :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(470, 106);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(61, 21);
            this.label14.TabIndex = 7;
            this.label14.Text = "Model :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(6, 189);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(80, 21);
            this.label13.TabIndex = 6;
            this.label13.Text = "Standard :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(6, 109);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(58, 21);
            this.label11.TabIndex = 4;
            this.label11.Text = "Price: *";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(470, 62);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 21);
            this.label10.TabIndex = 3;
            this.label10.Text = "Name :";
            // 
            // date
            // 
            this.date.AutoSize = true;
            this.date.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date.Location = new System.Drawing.Point(6, 67);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(103, 21);
            this.date.TabIndex = 1;
            this.date.Text = "Adding Date :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(6, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(90, 21);
            this.label7.TabIndex = 0;
            this.label7.Text = "Product ID :";
            // 
            // txtdisc
            // 
            this.txtdisc.BackColor = System.Drawing.Color.Gainsboro;
            this.txtdisc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtdisc.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdisc.Location = new System.Drawing.Point(167, 229);
            this.txtdisc.Multiline = true;
            this.txtdisc.Name = "txtdisc";
            this.txtdisc.Size = new System.Drawing.Size(753, 111);
            this.txtdisc.TabIndex = 5;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(779, 259);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 25);
            this.textBox1.TabIndex = 52;
            this.textBox1.Text = "0";
            // 
            // picbox_product
            // 
            this.picbox_product.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picbox_product.BackgroundImage")));
            this.picbox_product.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picbox_product.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picbox_product.Location = new System.Drawing.Point(969, 44);
            this.picbox_product.Name = "picbox_product";
            this.picbox_product.Size = new System.Drawing.Size(252, 213);
            this.picbox_product.TabIndex = 22;
            this.picbox_product.TabStop = false;
            this.picbox_product.Click += new System.EventHandler(this.picbox_product_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(968, 44);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(253, 213);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 51;
            this.pictureBox2.TabStop = false;
            // 
            // cmbo_discount
            // 
            this.cmbo_discount.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_discount.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_discount.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbo_discount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_discount.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_discount.FormattingEnabled = true;
            this.cmbo_discount.Items.AddRange(new object[] {
            "5",
            "10",
            "15",
            "20",
            "25"});
            this.cmbo_discount.Location = new System.Drawing.Point(742, 189);
            this.cmbo_discount.Name = "cmbo_discount";
            this.cmbo_discount.Size = new System.Drawing.Size(323, 29);
            this.cmbo_discount.TabIndex = 12;
            // 
            // cmbo_fit
            // 
            this.cmbo_fit.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_fit.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_fit.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbo_fit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_fit.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_fit.FormattingEnabled = true;
            this.cmbo_fit.Items.AddRange(new object[] {
            "Body",
            "Engine ",
            "Tire",
            "Gear",
            "Roof",
            "Sheet",
            "Electric Item"});
            this.cmbo_fit.Location = new System.Drawing.Point(742, 107);
            this.cmbo_fit.Name = "cmbo_fit";
            this.cmbo_fit.Size = new System.Drawing.Size(323, 29);
            this.cmbo_fit.TabIndex = 10;
            // 
            // cmbo_material
            // 
            this.cmbo_material.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_material.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_material.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbo_material.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_material.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_material.FormattingEnabled = true;
            this.cmbo_material.Items.AddRange(new object[] {
            "Plastic",
            "Matal",
            "Fiber",
            "Rubber",
            "Aluminium ",
            "Cellolight",
            "Lether"});
            this.cmbo_material.Location = new System.Drawing.Point(742, 22);
            this.cmbo_material.Name = "cmbo_material";
            this.cmbo_material.Size = new System.Drawing.Size(323, 29);
            this.cmbo_material.TabIndex = 8;
            // 
            // cmbo_return
            // 
            this.cmbo_return.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_return.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_return.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbo_return.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_return.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_return.FormattingEnabled = true;
            this.cmbo_return.Items.AddRange(new object[] {
            "Yes",
            "No",
            "1 Year",
            "No Cash Back",
            "Other"});
            this.cmbo_return.Location = new System.Drawing.Point(168, 221);
            this.cmbo_return.Name = "cmbo_return";
            this.cmbo_return.Size = new System.Drawing.Size(325, 29);
            this.cmbo_return.TabIndex = 7;
            // 
            // cmbo_garanty
            // 
            this.cmbo_garanty.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_garanty.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_garanty.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbo_garanty.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_garanty.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_garanty.FormattingEnabled = true;
            this.cmbo_garanty.Items.AddRange(new object[] {
            "Yes",
            "No",
            "1 Year",
            "Other"});
            this.cmbo_garanty.Location = new System.Drawing.Point(166, 184);
            this.cmbo_garanty.Name = "cmbo_garanty";
            this.cmbo_garanty.Size = new System.Drawing.Size(325, 29);
            this.cmbo_garanty.TabIndex = 6;
            // 
            // cmbo_condi
            // 
            this.cmbo_condi.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_condi.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_condi.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbo_condi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_condi.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_condi.FormattingEnabled = true;
            this.cmbo_condi.Items.AddRange(new object[] {
            "Brand New",
            "Re Conditioned ",
            "Used ",
            "Dameged ",
            "Some Isuses ",
            "Mager Issue "});
            this.cmbo_condi.Location = new System.Drawing.Point(168, 107);
            this.cmbo_condi.Name = "cmbo_condi";
            this.cmbo_condi.Size = new System.Drawing.Size(323, 29);
            this.cmbo_condi.TabIndex = 2;
            // 
            // cmbo_quality
            // 
            this.cmbo_quality.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_quality.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_quality.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbo_quality.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_quality.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_quality.FormattingEnabled = true;
            this.cmbo_quality.Items.AddRange(new object[] {
            "Afghanistan",
            "Albania",
            "Algeria",
            "Andorra",
            "Angola",
            "Antigua and Barbuda",
            "Argentina",
            "Armenia",
            "Aruba",
            "Australia",
            "Austria",
            "Azerbaijan",
            "Bahamas, The",
            "Bahrain",
            "Bangladesh",
            "Barbados",
            "Belarus",
            "Belgium",
            "Belize",
            "Benin",
            "Bhutan",
            "Bolivia",
            "Bosnia and Herzegovina",
            "Botswana",
            "Brazil",
            "Brunei ",
            "Bulgaria",
            "Burkina Faso",
            "Burma",
            "Burundi",
            "Cambodia",
            "Cameroon",
            "Canada",
            "Cape Verde",
            "Central African Republic",
            "Chad",
            "Chile",
            "China",
            "Colombia",
            "Comoros",
            "Congo, Democratic Republic of the",
            "Congo, Republic of the",
            "Costa Rica",
            "Cote d\'Ivoire",
            "Croatia",
            "Cuba",
            "Curacao",
            "Cyprus",
            "Czech Republic",
            "Denmark",
            "Djibouti",
            "Dominica",
            "Dominican Republic",
            "East Timor (see Timor-Leste)",
            "Ecuador",
            "Egypt",
            "El Salvador",
            "Equatorial Guinea",
            "Eritrea",
            "Estonia",
            "Ethiopia",
            "Saint Kitts and Nevis",
            "Saint Lucia",
            "Saint Vincent and the Grenadines",
            "Samoa ",
            "San Marino",
            "Sao Tome and Principe",
            "Saudi Arabia",
            "Senegal",
            "Serbia",
            "Seychelles",
            "Sierra Leone",
            "Singapore",
            "Sint Maarten",
            "Slovakia",
            "Slovenia",
            "Solomon Islands",
            "Somalia",
            "South Africa",
            "South Korea",
            "South Sudan",
            "Spain ",
            "Sri Lanka",
            "Sudan",
            "Suriname",
            "Swaziland ",
            "Sweden",
            "Switzerland",
            "Syria"});
            this.cmbo_quality.Location = new System.Drawing.Point(168, 65);
            this.cmbo_quality.Name = "cmbo_quality";
            this.cmbo_quality.Size = new System.Drawing.Size(323, 29);
            this.cmbo_quality.TabIndex = 4;
            // 
            // cmbo_country
            // 
            this.cmbo_country.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_country.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_country.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbo_country.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_country.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_country.FormattingEnabled = true;
            this.cmbo_country.Items.AddRange(new object[] {
            "Afghanistan",
            "Albania",
            "Algeria",
            "Andorra",
            "Angola",
            "Antigua and Barbuda",
            "Argentina",
            "Armenia",
            "Aruba",
            "Australia",
            "Austria",
            "Azerbaijan",
            "Bahamas, The",
            "Bahrain",
            "Bangladesh",
            "Barbados",
            "Belarus",
            "Belgium",
            "Belize",
            "Benin",
            "Bhutan",
            "Bolivia",
            "Bosnia and Herzegovina",
            "Botswana",
            "Brazil",
            "Brunei ",
            "Bulgaria",
            "Burkina Faso",
            "Burma",
            "Burundi",
            "Cambodia",
            "Cameroon",
            "Canada",
            "Cape Verde",
            "Central African Republic",
            "Chad",
            "Chile",
            "China",
            "Colombia",
            "Comoros",
            "Congo, Democratic Republic of the",
            "Congo, Republic of the",
            "Costa Rica",
            "Cote d\'Ivoire",
            "Croatia",
            "Cuba",
            "Curacao",
            "Cyprus",
            "Czech Republic",
            "Denmark",
            "Djibouti",
            "Dominica",
            "Dominican Republic",
            "East Timor (see Timor-Leste)",
            "Ecuador",
            "Egypt",
            "El Salvador",
            "Equatorial Guinea",
            "Eritrea",
            "Estonia",
            "Ethiopia",
            "Saint Kitts and Nevis",
            "Saint Lucia",
            "Saint Vincent and the Grenadines",
            "Samoa ",
            "San Marino",
            "Sao Tome and Principe",
            "Saudi Arabia",
            "Senegal",
            "Serbia",
            "Seychelles",
            "Sierra Leone",
            "Singapore",
            "Sint Maarten",
            "Slovakia",
            "Slovenia",
            "Solomon Islands",
            "Somalia",
            "South Africa",
            "South Korea",
            "South Sudan",
            "Spain ",
            "Sri Lanka",
            "Sudan",
            "Suriname",
            "Swaziland ",
            "Sweden",
            "Switzerland",
            "Syria"});
            this.cmbo_country.Location = new System.Drawing.Point(168, 24);
            this.cmbo_country.Name = "cmbo_country";
            this.cmbo_country.Size = new System.Drawing.Size(323, 29);
            this.cmbo_country.TabIndex = 0;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(572, 182);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(78, 21);
            this.label30.TabIndex = 31;
            this.label30.Text = "Discount :";
            // 
            // txtothernote
            // 
            this.txtothernote.BackColor = System.Drawing.Color.Gainsboro;
            this.txtothernote.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtothernote.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtothernote.Location = new System.Drawing.Point(742, 228);
            this.txtothernote.Multiline = true;
            this.txtothernote.Name = "txtothernote";
            this.txtothernote.Size = new System.Drawing.Size(323, 66);
            this.txtothernote.TabIndex = 13;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(572, 223);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(106, 21);
            this.label29.TabIndex = 29;
            this.label29.Text = "Other Notes  :";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label34);
            this.groupBox4.Controls.Add(this.pictureBox1);
            this.groupBox4.Controls.Add(this.txt_nic);
            this.groupBox4.Controls.Add(this.cmbo_fname);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.txt_uname);
            this.groupBox4.Controls.Add(this.txt_pwd2);
            this.groupBox4.Controls.Add(this.txt_pwd);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.button2);
            this.groupBox4.Controls.Add(this.button3);
            this.groupBox4.Controls.Add(this.button4);
            this.groupBox4.Controls.Add(this.button5);
            this.groupBox4.Controls.Add(this.button13);
            this.groupBox4.Controls.Add(this.button17);
            this.groupBox4.Controls.Add(this.txt_town);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.cmbo_title);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.txt_email);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.label35);
            this.groupBox4.Controls.Add(this.txt_land);
            this.groupBox4.Controls.Add(this.txt_add);
            this.groupBox4.Controls.Add(this.Txt_phone_numaric);
            this.groupBox4.Controls.Add(this.txt_lname);
            this.groupBox4.Controls.Add(this.label32);
            this.groupBox4.Controls.Add(this.label31);
            this.groupBox4.Controls.Add(this.label33);
            this.groupBox4.Controls.Add(this.label40);
            this.groupBox4.Controls.Add(this.label41);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(16, 349);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1301, 352);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Important Details";
            // 
            // label34
            // 
            this.label34.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.Red;
            this.label34.Location = new System.Drawing.Point(1040, 192);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(218, 33);
            this.label34.TabIndex = 67;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(1021, 131);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(259, 50);
            this.pictureBox1.TabIndex = 65;
            this.pictureBox1.TabStop = false;
            // 
            // txt_nic
            // 
            this.txt_nic.BackColor = System.Drawing.Color.LightPink;
            this.txt_nic.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_nic.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nic.Location = new System.Drawing.Point(166, 131);
            this.txt_nic.Name = "txt_nic";
            this.txt_nic.Size = new System.Drawing.Size(323, 26);
            this.txt_nic.TabIndex = 3;
            this.txt_nic.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_nic_KeyPress);
            this.txt_nic.Validating += new System.ComponentModel.CancelEventHandler(this.txt_nic_Validating);
            // 
            // cmbo_fname
            // 
            this.cmbo_fname.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_fname.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_fname.BackColor = System.Drawing.Color.LightPink;
            this.cmbo_fname.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_fname.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_fname.FormattingEnabled = true;
            this.cmbo_fname.Location = new System.Drawing.Point(166, 59);
            this.cmbo_fname.Name = "cmbo_fname";
            this.cmbo_fname.Size = new System.Drawing.Size(325, 29);
            this.cmbo_fname.TabIndex = 1;
            this.cmbo_fname.SelectedIndexChanged += new System.EventHandler(this.cmbo_fname_SelectedIndexChanged);
            this.cmbo_fname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbo_fname_KeyPress);
            this.cmbo_fname.Validating += new System.ComponentModel.CancelEventHandler(this.cmbo_fname_Validating);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(520, 130);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 21);
            this.label9.TabIndex = 63;
            this.label9.Text = "Username";
            // 
            // txt_uname
            // 
            this.txt_uname.BackColor = System.Drawing.Color.Gainsboro;
            this.txt_uname.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_uname.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_uname.Location = new System.Drawing.Point(667, 127);
            this.txt_uname.Name = "txt_uname";
            this.txt_uname.Size = new System.Drawing.Size(350, 26);
            this.txt_uname.TabIndex = 9;
            this.txt_uname.Validating += new System.ComponentModel.CancelEventHandler(this.txt_uname_Validating);
            // 
            // txt_pwd2
            // 
            this.txt_pwd2.BackColor = System.Drawing.Color.Gainsboro;
            this.txt_pwd2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_pwd2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_pwd2.Location = new System.Drawing.Point(667, 205);
            this.txt_pwd2.Name = "txt_pwd2";
            this.txt_pwd2.Size = new System.Drawing.Size(350, 26);
            this.txt_pwd2.TabIndex = 11;
            this.txt_pwd2.UseSystemPasswordChar = true;
            this.txt_pwd2.Validating += new System.ComponentModel.CancelEventHandler(this.txt_pwd2_Validating);
            // 
            // txt_pwd
            // 
            this.txt_pwd.BackColor = System.Drawing.Color.Gainsboro;
            this.txt_pwd.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_pwd.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_pwd.Location = new System.Drawing.Point(667, 166);
            this.txt_pwd.Name = "txt_pwd";
            this.txt_pwd.Size = new System.Drawing.Size(350, 26);
            this.txt_pwd.TabIndex = 10;
            this.txt_pwd.UseSystemPasswordChar = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(520, 209);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(125, 21);
            this.label8.TabIndex = 59;
            this.label8.Text = "Password Again ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(520, 169);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 21);
            this.label5.TabIndex = 58;
            this.label5.Text = "Password";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(301, 288);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(55, 48);
            this.button2.TabIndex = 56;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.Location = new System.Drawing.Point(615, 288);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(55, 48);
            this.button3.TabIndex = 55;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.White;
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.Location = new System.Drawing.Point(535, 288);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(55, 48);
            this.button4.TabIndex = 54;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.White;
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.Location = new System.Drawing.Point(462, 288);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(55, 48);
            this.button5.TabIndex = 53;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.White;
            this.button13.Image = ((System.Drawing.Image)(resources.GetObject("button13.Image")));
            this.button13.Location = new System.Drawing.Point(235, 288);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(55, 48);
            this.button13.TabIndex = 52;
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.White;
            this.button17.Image = ((System.Drawing.Image)(resources.GetObject("button17.Image")));
            this.button17.Location = new System.Drawing.Point(166, 288);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(55, 48);
            this.button17.TabIndex = 51;
            this.button17.UseVisualStyleBackColor = false;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // txt_town
            // 
            this.txt_town.BackColor = System.Drawing.Color.Gainsboro;
            this.txt_town.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_town.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_town.Location = new System.Drawing.Point(667, 89);
            this.txt_town.Name = "txt_town";
            this.txt_town.Size = new System.Drawing.Size(350, 26);
            this.txt_town.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(520, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 21);
            this.label2.TabIndex = 30;
            this.label2.Text = "Town";
            // 
            // cmbo_title
            // 
            this.cmbo_title.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_title.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_title.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbo_title.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_title.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_title.FormattingEnabled = true;
            this.cmbo_title.Items.AddRange(new object[] {
            "Mr.",
            "Mrs.",
            "Master."});
            this.cmbo_title.Location = new System.Drawing.Point(166, 17);
            this.cmbo_title.Name = "cmbo_title";
            this.cmbo_title.Size = new System.Drawing.Size(325, 29);
            this.cmbo_title.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(7, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 21);
            this.label1.TabIndex = 27;
            this.label1.Text = "Title";
            // 
            // txt_email
            // 
            this.txt_email.BackColor = System.Drawing.Color.Gainsboro;
            this.txt_email.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_email.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_email.Location = new System.Drawing.Point(667, 244);
            this.txt_email.Name = "txt_email";
            this.txt_email.Size = new System.Drawing.Size(350, 26);
            this.txt_email.TabIndex = 6;
            this.txt_email.Validating += new System.ComponentModel.CancelEventHandler(this.txt_email_Validating);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(520, 247);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 21);
            this.label4.TabIndex = 19;
            this.label4.Text = "Email ID :";
            // 
            // txt_land
            // 
            this.txt_land.BackColor = System.Drawing.Color.LightPink;
            this.txt_land.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_land.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_land.Location = new System.Drawing.Point(166, 199);
            this.txt_land.Name = "txt_land";
            this.txt_land.Size = new System.Drawing.Size(325, 26);
            this.txt_land.TabIndex = 5;
            this.txt_land.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_land_KeyPress);
            this.txt_land.Validating += new System.ComponentModel.CancelEventHandler(this.txt_land_Validating);
            // 
            // txt_add
            // 
            this.txt_add.BackColor = System.Drawing.Color.Gainsboro;
            this.txt_add.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_add.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_add.Location = new System.Drawing.Point(667, 17);
            this.txt_add.Multiline = true;
            this.txt_add.Name = "txt_add";
            this.txt_add.Size = new System.Drawing.Size(350, 61);
            this.txt_add.TabIndex = 7;
            // 
            // Txt_phone_numaric
            // 
            this.Txt_phone_numaric.BackColor = System.Drawing.Color.LightPink;
            this.Txt_phone_numaric.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Txt_phone_numaric.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txt_phone_numaric.Location = new System.Drawing.Point(166, 165);
            this.Txt_phone_numaric.Name = "Txt_phone_numaric";
            this.Txt_phone_numaric.Size = new System.Drawing.Size(325, 26);
            this.Txt_phone_numaric.TabIndex = 4;
            this.Txt_phone_numaric.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Txt_phone_numaric_KeyPress);
            this.Txt_phone_numaric.Validating += new System.ComponentModel.CancelEventHandler(this.Txt_phone_numaric_Validating);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(6, 207);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(138, 21);
            this.label32.TabIndex = 12;
            this.label32.Text = "Landline Number :";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(520, 21);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(73, 21);
            this.label31.TabIndex = 15;
            this.label31.Text = "Address :";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(7, 167);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(127, 21);
            this.label33.TabIndex = 11;
            this.label33.Text = "Mobile Number :";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(6, 92);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(88, 21);
            this.label40.TabIndex = 10;
            this.label40.Text = "Last Name ";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(7, 57);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(97, 21);
            this.label41.TabIndex = 9;
            this.label41.Text = "First  Name :";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.Red;
            this.label18.Location = new System.Drawing.Point(1023, 148);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(162, 17);
            this.label18.TabIndex = 66;
            this.label18.Text = "Already Exist! Try Another!";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(8, 223);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(64, 21);
            this.label27.TabIndex = 28;
            this.label27.Text = "Return :";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(8, 184);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(72, 21);
            this.label28.TabIndex = 27;
            this.label28.Text = "Garanty :";
            // 
            // cmbo_waranty
            // 
            this.cmbo_waranty.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_waranty.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_waranty.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbo_waranty.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_waranty.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_waranty.FormattingEnabled = true;
            this.cmbo_waranty.Items.AddRange(new object[] {
            "Yes",
            "No",
            "1 Year",
            "Other"});
            this.cmbo_waranty.Location = new System.Drawing.Point(742, 147);
            this.cmbo_waranty.Name = "cmbo_waranty";
            this.cmbo_waranty.Size = new System.Drawing.Size(323, 29);
            this.cmbo_waranty.TabIndex = 11;
            // 
            // cmbo_color
            // 
            this.cmbo_color.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbo_color.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbo_color.BackColor = System.Drawing.Color.Gainsboro;
            this.cmbo_color.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbo_color.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbo_color.FormattingEnabled = true;
            this.cmbo_color.Items.AddRange(new object[] {
            "black",
            "blue",
            "brown",
            "gray",
            "green",
            "orange",
            "pink",
            "purple",
            "red",
            "white",
            "yellow"});
            this.cmbo_color.Location = new System.Drawing.Point(166, 144);
            this.cmbo_color.Name = "cmbo_color";
            this.cmbo_color.Size = new System.Drawing.Size(325, 29);
            this.cmbo_color.TabIndex = 5;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(572, 147);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(76, 21);
            this.label26.TabIndex = 26;
            this.label26.Text = "Waranty :";
            // 
            // txt_capa
            // 
            this.txt_capa.BackColor = System.Drawing.Color.Gainsboro;
            this.txt_capa.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_capa.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_capa.Location = new System.Drawing.Point(742, 68);
            this.txt_capa.Name = "txt_capa";
            this.txt_capa.Size = new System.Drawing.Size(323, 26);
            this.txt_capa.TabIndex = 9;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(572, 104);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(65, 21);
            this.label22.TabIndex = 14;
            this.label22.Text = "Fit For  :";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(572, 68);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(76, 21);
            this.label23.TabIndex = 13;
            this.label23.Text = "Capacity :";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(572, 25);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(74, 21);
            this.label24.TabIndex = 12;
            this.label24.Text = "Material :";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(6, 104);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(85, 21);
            this.label19.TabIndex = 11;
            this.label19.Text = "Condition :";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(6, 67);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(67, 21);
            this.label20.TabIndex = 10;
            this.label20.Text = "Quality :";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(6, 30);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(70, 21);
            this.label21.TabIndex = 9;
            this.label21.Text = "country :";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button16);
            this.groupBox1.Controls.Add(this.cmbo_discount);
            this.groupBox1.Controls.Add(this.cmbo_fit);
            this.groupBox1.Controls.Add(this.cmbo_material);
            this.groupBox1.Controls.Add(this.cmbo_return);
            this.groupBox1.Controls.Add(this.cmbo_garanty);
            this.groupBox1.Controls.Add(this.cmbo_condi);
            this.groupBox1.Controls.Add(this.cmbo_quality);
            this.groupBox1.Controls.Add(this.cmbo_country);
            this.groupBox1.Controls.Add(this.update);
            this.groupBox1.Controls.Add(this.delete);
            this.groupBox1.Controls.Add(this.save);
            this.groupBox1.Controls.Add(this.button11);
            this.groupBox1.Controls.Add(this.label30);
            this.groupBox1.Controls.Add(this.txtothernote);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.cmbo_waranty);
            this.groupBox1.Controls.Add(this.cmbo_color);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.txt_capa);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(6, 355);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1338, 323);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Other Details";
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.White;
            this.button16.Image = ((System.Drawing.Image)(resources.GetObject("button16.Image")));
            this.button16.Location = new System.Drawing.Point(310, 258);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(55, 48);
            this.button16.TabIndex = 13;
            this.button16.UseVisualStyleBackColor = false;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // update
            // 
            this.update.BackColor = System.Drawing.Color.White;
            this.update.Image = ((System.Drawing.Image)(resources.GetObject("update.Image")));
            this.update.Location = new System.Drawing.Point(616, 258);
            this.update.Name = "update";
            this.update.Size = new System.Drawing.Size(55, 48);
            this.update.TabIndex = 40;
            this.update.UseVisualStyleBackColor = false;
            this.update.Click += new System.EventHandler(this.update_Click);
            // 
            // delete
            // 
            this.delete.BackColor = System.Drawing.Color.White;
            this.delete.Image = ((System.Drawing.Image)(resources.GetObject("delete.Image")));
            this.delete.Location = new System.Drawing.Point(536, 258);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(55, 48);
            this.delete.TabIndex = 39;
            this.delete.UseVisualStyleBackColor = false;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // save
            // 
            this.save.BackColor = System.Drawing.Color.White;
            this.save.Image = ((System.Drawing.Image)(resources.GetObject("save.Image")));
            this.save.Location = new System.Drawing.Point(463, 258);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(55, 48);
            this.save.TabIndex = 14;
            this.save.UseVisualStyleBackColor = false;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.White;
            this.button11.Image = ((System.Drawing.Image)(resources.GetObject("button11.Image")));
            this.button11.Location = new System.Drawing.Point(235, 258);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(55, 48);
            this.button11.TabIndex = 3;
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(6, 145);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(64, 21);
            this.label25.TabIndex = 25;
            this.label25.Text = "Colour :";
            // 
            // tcMain
            // 
            this.tcMain.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tcMain.Controls.Add(this.Products);
            this.tcMain.Controls.Add(this.staff);
            this.tcMain.Controls.Add(this.vonders);
            this.tcMain.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tcMain.HotTrack = true;
            this.tcMain.Location = new System.Drawing.Point(5, 37);
            this.tcMain.Name = "tcMain";
            this.tcMain.SelectedIndex = 0;
            this.tcMain.Size = new System.Drawing.Size(1365, 760);
            this.tcMain.TabIndex = 8;
            this.tcMain.TabStop = false;
            this.tcMain.Selected += new System.Windows.Forms.TabControlEventHandler(this.tcMain_Selected);
            this.tcMain.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tcMain_MouseClick);
            // 
            // Products
            // 
            this.Products.BackColor = System.Drawing.Color.White;
            this.Products.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Products.Controls.Add(this.groupBox1);
            this.Products.Controls.Add(this.gbStudentDetails);
            this.Products.Location = new System.Drawing.Point(4, 35);
            this.Products.Name = "Products";
            this.Products.Padding = new System.Windows.Forms.Padding(3);
            this.Products.Size = new System.Drawing.Size(1357, 721);
            this.Products.TabIndex = 0;
            this.Products.Text = "Adding New Products ";
            // 
            // staff
            // 
            this.staff.BackColor = System.Drawing.Color.White;
            this.staff.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.staff.Controls.Add(this.groupBox4);
            this.staff.Controls.Add(this.groupBox5);
            this.staff.Location = new System.Drawing.Point(4, 35);
            this.staff.Name = "staff";
            this.staff.Padding = new System.Windows.Forms.Padding(3);
            this.staff.Size = new System.Drawing.Size(1357, 721);
            this.staff.TabIndex = 1;
            this.staff.Text = "Staff ";
            // 
            // lblMainTitle
            // 
            this.lblMainTitle.AutoSize = true;
            this.lblMainTitle.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMainTitle.Location = new System.Drawing.Point(-13, -42);
            this.lblMainTitle.Name = "lblMainTitle";
            this.lblMainTitle.Size = new System.Drawing.Size(212, 30);
            this.lblMainTitle.TabIndex = 9;
            this.lblMainTitle.Text = "MANAGE PRODUCTS";
            // 
            // btn_ok
            // 
            this.btn_ok.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btn_ok.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ok.Location = new System.Drawing.Point(1232, 1);
            this.btn_ok.Name = "btn_ok";
            this.btn_ok.Size = new System.Drawing.Size(92, 30);
            this.btn_ok.TabIndex = 42;
            this.btn_ok.Text = "ok";
            this.btn_ok.UseVisualStyleBackColor = false;
            this.btn_ok.Click += new System.EventHandler(this.btn_ok_Click);
            // 
            // label_error_green
            // 
            this.label_error_green.BackColor = System.Drawing.Color.LimeGreen;
            this.label_error_green.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_error_green.ForeColor = System.Drawing.Color.Black;
            this.label_error_green.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label_error_green.Location = new System.Drawing.Point(0, -4);
            this.label_error_green.Name = "label_error_green";
            this.label_error_green.Size = new System.Drawing.Size(1370, 37);
            this.label_error_green.TabIndex = 51;
            this.label_error_green.Text = "                                        Data Added Successful Click Ok Here To Co" +
    "ntinue!.......";
            // 
            // Lbl_deleted
            // 
            this.Lbl_deleted.BackColor = System.Drawing.Color.Red;
            this.Lbl_deleted.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_deleted.ForeColor = System.Drawing.Color.Black;
            this.Lbl_deleted.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.Lbl_deleted.Location = new System.Drawing.Point(0, -2);
            this.Lbl_deleted.Name = "Lbl_deleted";
            this.Lbl_deleted.Size = new System.Drawing.Size(1370, 32);
            this.Lbl_deleted.TabIndex = 52;
            this.Lbl_deleted.Text = "     System Trying To Delete Data Permanantly! Are You Sure?";
            this.Lbl_deleted.Click += new System.EventHandler(this.Lbl_deleted_Click);
            // 
            // btnallow_delete
            // 
            this.btnallow_delete.BackColor = System.Drawing.Color.Red;
            this.btnallow_delete.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnallow_delete.Location = new System.Drawing.Point(1024, 1);
            this.btnallow_delete.Name = "btnallow_delete";
            this.btnallow_delete.Size = new System.Drawing.Size(92, 30);
            this.btnallow_delete.TabIndex = 53;
            this.btnallow_delete.Text = "Allow";
            this.btnallow_delete.UseVisualStyleBackColor = false;
            this.btnallow_delete.Click += new System.EventHandler(this.allow_delete_Click);
            // 
            // btnCancel_Delete
            // 
            this.btnCancel_Delete.BackColor = System.Drawing.Color.Red;
            this.btnCancel_Delete.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel_Delete.Location = new System.Drawing.Point(1134, 0);
            this.btnCancel_Delete.Name = "btnCancel_Delete";
            this.btnCancel_Delete.Size = new System.Drawing.Size(92, 30);
            this.btnCancel_Delete.TabIndex = 54;
            this.btnCancel_Delete.Text = "Cancel";
            this.btnCancel_Delete.UseVisualStyleBackColor = false;
            this.btnCancel_Delete.Click += new System.EventHandler(this.btnCancel_Delete_Click);
            // 
            // lbl_update
            // 
            this.lbl_update.BackColor = System.Drawing.Color.Red;
            this.lbl_update.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_update.ForeColor = System.Drawing.Color.Black;
            this.lbl_update.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.lbl_update.Location = new System.Drawing.Point(0, 0);
            this.lbl_update.Name = "lbl_update";
            this.lbl_update.Size = new System.Drawing.Size(1370, 32);
            this.lbl_update.TabIndex = 55;
            this.lbl_update.Text = "     System Trying To Update Data Permanantly! Are You Sure?";
            // 
            // btn_update_allow
            // 
            this.btn_update_allow.BackColor = System.Drawing.Color.Red;
            this.btn_update_allow.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update_allow.Location = new System.Drawing.Point(1024, 1);
            this.btn_update_allow.Name = "btn_update_allow";
            this.btn_update_allow.Size = new System.Drawing.Size(92, 30);
            this.btn_update_allow.TabIndex = 56;
            this.btn_update_allow.Text = "Allow";
            this.btn_update_allow.UseVisualStyleBackColor = false;
            this.btn_update_allow.Click += new System.EventHandler(this.btn_update_allow_Click);
            // 
            // btn_update_cancel
            // 
            this.btn_update_cancel.BackColor = System.Drawing.Color.Red;
            this.btn_update_cancel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update_cancel.Location = new System.Drawing.Point(1134, 2);
            this.btn_update_cancel.Name = "btn_update_cancel";
            this.btn_update_cancel.Size = new System.Drawing.Size(92, 30);
            this.btn_update_cancel.TabIndex = 57;
            this.btn_update_cancel.Text = "Cancel";
            this.btn_update_cancel.UseVisualStyleBackColor = false;
            this.btn_update_cancel.Click += new System.EventHandler(this.btn_update_cancel_Click);
            // 
            // picboxwhite
            // 
            this.picboxwhite.BackColor = System.Drawing.Color.Black;
            this.picboxwhite.Image = ((System.Drawing.Image)(resources.GetObject("picboxwhite.Image")));
            this.picboxwhite.Location = new System.Drawing.Point(0, -4);
            this.picboxwhite.Name = "picboxwhite";
            this.picboxwhite.Size = new System.Drawing.Size(1380, 39);
            this.picboxwhite.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picboxwhite.TabIndex = 40;
            this.picboxwhite.TabStop = false;
            // 
            // btn_staff_delete_allow
            // 
            this.btn_staff_delete_allow.BackColor = System.Drawing.Color.Red;
            this.btn_staff_delete_allow.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_staff_delete_allow.Location = new System.Drawing.Point(1024, 1);
            this.btn_staff_delete_allow.Name = "btn_staff_delete_allow";
            this.btn_staff_delete_allow.Size = new System.Drawing.Size(92, 30);
            this.btn_staff_delete_allow.TabIndex = 61;
            this.btn_staff_delete_allow.Text = "Allow";
            this.btn_staff_delete_allow.UseVisualStyleBackColor = false;
            this.btn_staff_delete_allow.Click += new System.EventHandler(this.btn_staff_delete_allow_Click);
            // 
            // btn_allow_update_staff
            // 
            this.btn_allow_update_staff.BackColor = System.Drawing.Color.Red;
            this.btn_allow_update_staff.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_allow_update_staff.Location = new System.Drawing.Point(1024, 2);
            this.btn_allow_update_staff.Name = "btn_allow_update_staff";
            this.btn_allow_update_staff.Size = new System.Drawing.Size(92, 30);
            this.btn_allow_update_staff.TabIndex = 62;
            this.btn_allow_update_staff.Text = "Allow";
            this.btn_allow_update_staff.UseVisualStyleBackColor = false;
            this.btn_allow_update_staff.Click += new System.EventHandler(this.btn_allow_update_staff_Click);
            // 
            // lbl_empty
            // 
            this.lbl_empty.BackColor = System.Drawing.Color.Red;
            this.lbl_empty.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_empty.ForeColor = System.Drawing.Color.Black;
            this.lbl_empty.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.lbl_empty.Location = new System.Drawing.Point(0, -1);
            this.lbl_empty.Name = "lbl_empty";
            this.lbl_empty.Size = new System.Drawing.Size(1370, 32);
            this.lbl_empty.TabIndex = 63;
            this.lbl_empty.Text = "Price,Year,Image,Name Must Be Entered";
            // 
            // btn_allow_delete_dealer
            // 
            this.btn_allow_delete_dealer.BackColor = System.Drawing.Color.Red;
            this.btn_allow_delete_dealer.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_allow_delete_dealer.Location = new System.Drawing.Point(1024, 1);
            this.btn_allow_delete_dealer.Name = "btn_allow_delete_dealer";
            this.btn_allow_delete_dealer.Size = new System.Drawing.Size(92, 30);
            this.btn_allow_delete_dealer.TabIndex = 73;
            this.btn_allow_delete_dealer.Text = "Allow";
            this.btn_allow_delete_dealer.UseVisualStyleBackColor = false;
            this.btn_allow_delete_dealer.Click += new System.EventHandler(this.btn_allow_delete_dealer_Click);
            // 
            // btn_allow_update_dealer
            // 
            this.btn_allow_update_dealer.BackColor = System.Drawing.Color.Red;
            this.btn_allow_update_dealer.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_allow_update_dealer.Location = new System.Drawing.Point(1024, 2);
            this.btn_allow_update_dealer.Name = "btn_allow_update_dealer";
            this.btn_allow_update_dealer.Size = new System.Drawing.Size(92, 30);
            this.btn_allow_update_dealer.TabIndex = 74;
            this.btn_allow_update_dealer.Text = "Allow";
            this.btn_allow_update_dealer.UseVisualStyleBackColor = false;
            this.btn_allow_update_dealer.Click += new System.EventHandler(this.btn_allow_update_dealer_Click);
            // 
            // product
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1370, 772);
            this.Controls.Add(this.picboxwhite);
            this.Controls.Add(this.lblMainTitle);
            this.Controls.Add(this.btnCancel_Delete);
            this.Controls.Add(this.btn_update_cancel);
            this.Controls.Add(this.btn_ok);
            this.Controls.Add(this.tcMain);
            this.Controls.Add(this.btn_allow_update_staff);
            this.Controls.Add(this.btn_allow_delete_dealer);
            this.Controls.Add(this.btn_staff_delete_allow);
            this.Controls.Add(this.btnallow_delete);
            this.Controls.Add(this.label_error_green);
            this.Controls.Add(this.lbl_empty);
            this.Controls.Add(this.btn_update_allow);
            this.Controls.Add(this.btn_allow_update_dealer);
            this.Controls.Add(this.Lbl_deleted);
            this.Controls.Add(this.lbl_update);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "product";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "product";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.product_Load);
            this.vonders.ResumeLayout(false);
            this.vonders.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_staff)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_dummy)).EndInit();
            this.gbStudentDetails.ResumeLayout(false);
            this.gbStudentDetails.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_product)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tcMain.ResumeLayout(false);
            this.Products.ResumeLayout(false);
            this.staff.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picboxwhite)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbo_staffsec;
        private System.Windows.Forms.TextBox txt_staff_marks;
        private System.Windows.Forms.ComboBox cmbo_staff_religion;
        private System.Windows.Forms.ComboBox cmbo_staff_type;
        private System.Windows.Forms.ComboBox cmbo_staff_gender;
        private System.Windows.Forms.TabPage vonders;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.ComboBox cmbo_dealer_id;
        private System.Windows.Forms.TextBox txt_add_dealer;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox txt_lname;
        private System.Windows.Forms.GroupBox gbStudentDetails;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox txt_pic_path;
        private System.Windows.Forms.CheckBox checkbox_Loadid;
        private System.Windows.Forms.ComboBox cmbo_year;
        private System.Windows.Forms.DateTimePicker datetime;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.ComboBox cmbo_name;
        private System.Windows.Forms.ComboBox cmbo_id;
        private System.Windows.Forms.PictureBox picbox_product;
        private System.Windows.Forms.ComboBox cmbo_model;
        private System.Windows.Forms.TextBox txtdisc;
        private System.Windows.Forms.ComboBox cmbo_make;
        private System.Windows.Forms.ComboBox cmbo_standerd;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label date;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.ComboBox cmbo_discount;
        private System.Windows.Forms.ComboBox cmbo_fit;
        private System.Windows.Forms.ComboBox cmbo_material;
        private System.Windows.Forms.ComboBox cmbo_return;
        private System.Windows.Forms.ComboBox cmbo_garanty;
        private System.Windows.Forms.ComboBox cmbo_condi;
        private System.Windows.Forms.ComboBox cmbo_quality;
        private System.Windows.Forms.ComboBox cmbo_country;
        private System.Windows.Forms.Button update;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtothernote;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button save;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.ComboBox cmbo_waranty;
        private System.Windows.Forms.ComboBox cmbo_color;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txt_capa;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TabControl tcMain;
        private System.Windows.Forms.TabPage Products;
        private System.Windows.Forms.TabPage staff;
        private System.Windows.Forms.TextBox txt_email;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_add;
        private System.Windows.Forms.Label label31;
        private NumericTextBox.NumericTextBox txt_land;
        private NumericTextBox.NumericTextBox Txt_phone_numaric;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label lblMainTitle;
        private System.Windows.Forms.TextBox txtuser_type;
        private System.Windows.Forms.PictureBox picboxwhite;
        private System.Windows.Forms.Button btn_ok;
        private System.Windows.Forms.Label label_error_green;
        private System.Windows.Forms.Button btnCancel_Delete;
        private System.Windows.Forms.Label Lbl_deleted;
        private System.Windows.Forms.Button btnallow_delete;
        private System.Windows.Forms.Label lbl_update;
        private System.Windows.Forms.Button btn_update_allow;
        private System.Windows.Forms.Button btn_update_cancel;
        private System.Windows.Forms.TextBox txt_picture_path;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.PictureBox picbox_staff;
        private System.Windows.Forms.TextBox txt_staff_relationship;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.TextBox txt_town;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbo_title;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_uname;
        private System.Windows.Forms.TextBox txt_pwd2;
        private System.Windows.Forms.TextBox txt_pwd;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Staff_Bornplace;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.DateTimePicker Staff_dateofbirth;
        private System.Windows.Forms.DateTimePicker staff_addmissiondate;
        private System.Windows.Forms.CheckBox chek_name;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.ComboBox cmbo_staff_id;
        private System.Windows.Forms.ComboBox cmbo_fname;
        private System.Windows.Forms.Button btn_staff_delete_allow;
        private System.Windows.Forms.Button btn_allow_update_staff;
        private System.Windows.Forms.Label lbl_empty;
        private NumericTextBox.NumericTextBox txt_staffile;
        private NumericTextBox.NumericTextBox txt_nic;
        private NumericTextBox.NumericTextBox txtprice;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.ComboBox cmbo_bank;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.DateTimePicker datetime_dealer;
        private NumericTextBox.NumericTextBox acc_no;
        private NumericTextBox.NumericTextBox reg_dealer;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.ComboBox cmbo_spec_item;
        private System.Windows.Forms.TextBox txt_company;
        private System.Windows.Forms.Button btn_allow_delete_dealer;
        private System.Windows.Forms.Button btn_allow_update_dealer;
        private System.Windows.Forms.ComboBox txt_dealer_name;
        private System.Windows.Forms.TextBox email;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox picbox_dummy;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox textBox1;
    }
}