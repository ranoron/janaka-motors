﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WinFormCharpWebCam;


namespace SchoolManagementAdmin
{
    public partial class camara : Form
    {
        public camara()
        {
            InitializeComponent();
        }
        WebCam webcam;
        private void camara_Load(object sender, EventArgs e)
        {
            webcam = new WebCam();
            webcam.InitializeWebCam(ref imgVideo);
           
        }

        private void bntStart_Click(object sender, EventArgs e)
        {
            webcam.Start();
        }

        private void bntStop_Click(object sender, EventArgs e)
        {
            webcam.Stop();
        }

        private void bntContinue_Click(object sender, EventArgs e)
        {
            webcam.Continue();
        }

        private void bntCapture_Click(object sender, EventArgs e)
        {
            imgCapture.Image = imgVideo.Image;
            imgVideo.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void bntSave_Click(object sender, EventArgs e)
        {
            Helper.SaveImageCapture(imgCapture.Image);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
                imgVideo.Image = null;
        }

        private void bntVideoFormat_Click(object sender, EventArgs e)
        {

        }

        private void bntVideoSource_Click(object sender, EventArgs e)
        {

        }
    }
}
