﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

using ExcelLibrary.CompoundDocumentFormat;
using ExcelLibrary.SpreadSheet;
using ExcelLibrary.BinaryDrawingFormat;
using ExcelLibrary.BinaryFileFormat;



namespace SchoolManagementAdmin
{
    public partial class product_stock : Form
    {
        public product_stock(string uname)
        {
            InitializeComponent();
            txt_uname.Text = uname;
        }

        DataTable dbdataset;
        private void total()
        {

            int sum = 0;
           

            for (int i = 0; i < dataGridView1.Rows.Count; ++i)
            {
                sum += Convert.ToInt32(dataGridView1.Rows[i].Cells[9].Value);
            }
            int counting_row = dataGridView1.Rows.Count;

            double avg = sum / counting_row;
            txt_avg.Text = avg.ToString();
            txt_total.Text = sum.ToString();
        }
        private void button11_Click(object sender, EventArgs e)
        {
            frmMain frm = new frmMain(txt_uname.Text);
            frm.Show();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void product_stock_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'janaka_dbDataSet1.purchasing_history' table. You can move, or remove it, as needed.
            this.purchasing_historyTableAdapter.Fill(this.janaka_dbDataSet1.purchasing_history);
          
           total();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //string filepath = "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe";
            //Process.start(filepath);

            total();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
           
            try
            {
                this.purchasing_historyTableAdapter.FillBy(this.janaka_dbDataSet1.purchasing_history, dateTimePicker1.Text, dateTimePicker2.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            total();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
            DataView dv = new DataView(dbdataset);
            dv.RowFilter = string.Format("item_name LIKE '%{0}%'", textBox1.Text);
            dataGridView1.DataSource = dv;

        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            

                printPreviewDialog1.Document = printDocument1;
                printPreviewDialog1.ShowDialog();
            
           
            
          

        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Bitmap bm = new Bitmap(this.dataGridView1.Width, this.dataGridView1.Height);
            dataGridView1.DrawToBitmap(bm, new Rectangle(0, 0, this.dataGridView1.Width, this.dataGridView1.Height));
            e.Graphics.DrawImage(bm, 0, 0);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            //string file = "D:\\newdoc.xls";
            //Workbook workbook = new Workbook();
            //Worksheet worksheet = new Worksheet("First Sheet");
            //worksheet.Cells[0, 1] = new Cell((short)1);
            //worksheet.Cells[4, 0] = new Cell(9999999);
            //worksheet.Cells[3, 3] = new Cell((decimal)3.45);
            //worksheet.Cells[2, 2] = new Cell("Text string");
            //worksheet.Cells[2, 4] = new Cell("Second string");
            //worksheet.Cells[4, 0] = new Cell(32764.5, "#,##0.00");
            //worksheet.Cells[5, 1] = new Cell(DateTime.Now, @"YYYY\-MM\-DD");
            //worksheet.Cells.ColumnWidth[0, 1] = 3000;
            //workbook.Worksheets.Add(worksheet);
            //workbook.Save(file);

            //// open xls file
            //Workbook book = Workbook.Load(file);
            //Worksheet sheet = book.Worksheets[0];
            try
            {

                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("Select * from purchasing_history", con);

                SqlDataAdapter sda = new SqlDataAdapter();
                sda.SelectCommand = cmd;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource bsource = new BindingSource();

                DataSet ds = new DataSet("New Dataset");
                ds.Locale = System.Threading.Thread.CurrentThread.CurrentCulture;
                sda.Fill(dbdataset);
                ds.Tables.Add(dbdataset);
                ExcelLibrary.DataSetHelper.CreateWorkbook("D:\\janaka\\Purchesing_History.xls", ds);
                pictureBox1.BringToFront();
                label7.BringToFront();
                button4.BringToFront();


            }
            catch (SqlException ee)
            {
                MessageBox.Show("error" + ee);
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            dataGridView1.BringToFront();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}
