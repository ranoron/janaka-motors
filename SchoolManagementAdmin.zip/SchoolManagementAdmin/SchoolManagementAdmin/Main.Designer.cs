﻿namespace SchoolManagementAdmin
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.pnlRightOptions = new System.Windows.Forms.Panel();
            this.pnlRightMain = new System.Windows.Forms.Panel();
            this.pbExit = new System.Windows.Forms.PictureBox();
            this.pbHome = new System.Windows.Forms.PictureBox();
            this.pbLogout = new System.Windows.Forms.PictureBox();
            this.RightOptions = new System.Windows.Forms.Timer(this.components);
            this.FirstColumn = new System.Windows.Forms.Timer(this.components);
            this.pnlMain = new System.Windows.Forms.Panel();
            this.pnlSearch = new System.Windows.Forms.Panel();
            this.pbSearch = new System.Windows.Forms.PictureBox();
            this.lblSearch = new System.Windows.Forms.Label();
            this.pnlAccounts = new System.Windows.Forms.Panel();
            this.pbRestore = new System.Windows.Forms.PictureBox();
            this.lblRestore = new System.Windows.Forms.Label();
            this.pnlRestore = new System.Windows.Forms.Panel();
            this.pbAccounts = new System.Windows.Forms.PictureBox();
            this.lblAccounts = new System.Windows.Forms.Label();
            this.pnlReports = new System.Windows.Forms.Panel();
            this.pbReports = new System.Windows.Forms.PictureBox();
            this.lblReports = new System.Windows.Forms.Label();
            this.lblCopyright = new System.Windows.Forms.Label();
            this.lbl2name = new System.Windows.Forms.Label();
            this.lbluname_main = new System.Windows.Forms.Label();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.pnlLogo = new System.Windows.Forms.Panel();
            this.lblFaltu = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pnlBackup = new System.Windows.Forms.Panel();
            this.pbBackup = new System.Windows.Forms.PictureBox();
            this.lblBackup = new System.Windows.Forms.Label();
            this.pnlAttendance = new System.Windows.Forms.Panel();
            this.pbAttendance = new System.Windows.Forms.PictureBox();
            this.lblAttendance = new System.Windows.Forms.Label();
            this.pnlEmployees = new System.Windows.Forms.Panel();
            this.pbEmployees = new System.Windows.Forms.PictureBox();
            this.lblEmployees = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pnlproduct = new System.Windows.Forms.Panel();
            this.pbproduct = new System.Windows.Forms.PictureBox();
            this.lblStudents = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lblMainTitle = new System.Windows.Forms.Label();
            this.Clock = new CalendarClock.CalendarClock();
            this.txtunamemain = new System.Windows.Forms.TextBox();
            this.pnlRightOptions.SuspendLayout();
            this.pnlRightMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHome)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogout)).BeginInit();
            this.pnlMain.SuspendLayout();
            this.pnlSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSearch)).BeginInit();
            this.pnlAccounts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbRestore)).BeginInit();
            this.pnlRestore.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAccounts)).BeginInit();
            this.pnlReports.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbReports)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.pnlLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlBackup.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbBackup)).BeginInit();
            this.pnlAttendance.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAttendance)).BeginInit();
            this.pnlEmployees.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbEmployees)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.pnlproduct.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbproduct)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlRightOptions
            // 
            this.pnlRightOptions.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.pnlRightOptions.Controls.Add(this.pnlRightMain);
            this.pnlRightOptions.Location = new System.Drawing.Point(1196, -40);
            this.pnlRightOptions.Name = "pnlRightOptions";
            this.pnlRightOptions.Size = new System.Drawing.Size(77, 641);
            this.pnlRightOptions.TabIndex = 18;
            // 
            // pnlRightMain
            // 
            this.pnlRightMain.Controls.Add(this.pbExit);
            this.pnlRightMain.Controls.Add(this.pbHome);
            this.pnlRightMain.Controls.Add(this.pbLogout);
            this.pnlRightMain.Location = new System.Drawing.Point(6, 55);
            this.pnlRightMain.Name = "pnlRightMain";
            this.pnlRightMain.Size = new System.Drawing.Size(70, 393);
            this.pnlRightMain.TabIndex = 1;
            // 
            // pbExit
            // 
            this.pbExit.Image = global::SchoolManagementAdmin.Properties.Resources.appbar_power;
            this.pbExit.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pbExit.Location = new System.Drawing.Point(0, 323);
            this.pbExit.Name = "pbExit";
            this.pbExit.Size = new System.Drawing.Size(76, 73);
            this.pbExit.TabIndex = 5;
            this.pbExit.TabStop = false;
            this.pbExit.Click += new System.EventHandler(this.pbExit_Click);
            // 
            // pbHome
            // 
            this.pbHome.Image = global::SchoolManagementAdmin.Properties.Resources.appbar_home;
            this.pbHome.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pbHome.Location = new System.Drawing.Point(0, 163);
            this.pbHome.Name = "pbHome";
            this.pbHome.Size = new System.Drawing.Size(76, 73);
            this.pbHome.TabIndex = 4;
            this.pbHome.TabStop = false;
            this.pbHome.Click += new System.EventHandler(this.pbHome_Click);
            // 
            // pbLogout
            // 
            this.pbLogout.Image = global::SchoolManagementAdmin.Properties.Resources.appbar_lock;
            this.pbLogout.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pbLogout.Location = new System.Drawing.Point(0, 3);
            this.pbLogout.Name = "pbLogout";
            this.pbLogout.Size = new System.Drawing.Size(76, 73);
            this.pbLogout.TabIndex = 3;
            this.pbLogout.TabStop = false;
            this.pbLogout.Click += new System.EventHandler(this.pbLogout_Click);
            // 
            // RightOptions
            // 
            this.RightOptions.Interval = 1;
            this.RightOptions.Tick += new System.EventHandler(this.RightOptions_Tick);
            // 
            // FirstColumn
            // 
            this.FirstColumn.Interval = 2000;
            this.FirstColumn.Tick += new System.EventHandler(this.FirstColumn_Tick);
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.Transparent;
            this.pnlMain.Controls.Add(this.pnlSearch);
            this.pnlMain.Controls.Add(this.pnlAccounts);
            this.pnlMain.Controls.Add(this.pnlRestore);
            this.pnlMain.Controls.Add(this.pnlReports);
            this.pnlMain.Controls.Add(this.lbl2name);
            this.pnlMain.Controls.Add(this.lbluname_main);
            this.pnlMain.Controls.Add(this.pictureBox13);
            this.pnlMain.Controls.Add(this.pictureBox6);
            this.pnlMain.Controls.Add(this.panel10);
            this.pnlMain.Controls.Add(this.panel9);
            this.pnlMain.Controls.Add(this.panel5);
            this.pnlMain.Controls.Add(this.pnlLogo);
            this.pnlMain.Controls.Add(this.pnlBackup);
            this.pnlMain.Controls.Add(this.pnlAttendance);
            this.pnlMain.Controls.Add(this.pnlEmployees);
            this.pnlMain.Controls.Add(this.groupBox1);
            this.pnlMain.Controls.Add(this.lblMainTitle);
            this.pnlMain.Controls.Add(this.Clock);
            this.pnlMain.Controls.Add(this.txtunamemain);
            this.pnlMain.ForeColor = System.Drawing.Color.White;
            this.pnlMain.Location = new System.Drawing.Point(7, 3);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1189, 718);
            this.pnlMain.TabIndex = 19;
            this.pnlMain.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlMain_Paint);
            // 
            // pnlSearch
            // 
            this.pnlSearch.BackColor = System.Drawing.Color.Green;
            this.pnlSearch.Controls.Add(this.pbSearch);
            this.pnlSearch.Controls.Add(this.lblSearch);
            this.pnlSearch.Location = new System.Drawing.Point(452, 131);
            this.pnlSearch.Name = "pnlSearch";
            this.pnlSearch.Size = new System.Drawing.Size(125, 122);
            this.pnlSearch.TabIndex = 34;
            // 
            // pbSearch
            // 
            this.pbSearch.BackColor = System.Drawing.Color.Transparent;
            this.pbSearch.Image = ((System.Drawing.Image)(resources.GetObject("pbSearch.Image")));
            this.pbSearch.Location = new System.Drawing.Point(26, 26);
            this.pbSearch.Name = "pbSearch";
            this.pbSearch.Size = new System.Drawing.Size(76, 73);
            this.pbSearch.TabIndex = 2;
            this.pbSearch.TabStop = false;
            this.pbSearch.Click += new System.EventHandler(this.pbSearch_Click);
            // 
            // lblSearch
            // 
            this.lblSearch.AutoSize = true;
            this.lblSearch.BackColor = System.Drawing.Color.Transparent;
            this.lblSearch.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearch.Location = new System.Drawing.Point(5, 101);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(86, 19);
            this.lblSearch.TabIndex = 0;
            this.lblSearch.Text = "Selling Items";
            // 
            // pnlAccounts
            // 
            this.pnlAccounts.BackColor = System.Drawing.Color.Purple;
            this.pnlAccounts.Controls.Add(this.pbRestore);
            this.pnlAccounts.Controls.Add(this.lblRestore);
            this.pnlAccounts.Location = new System.Drawing.Point(321, 534);
            this.pnlAccounts.Name = "pnlAccounts";
            this.pnlAccounts.Size = new System.Drawing.Size(125, 122);
            this.pnlAccounts.TabIndex = 7;
            // 
            // pbRestore
            // 
            this.pbRestore.BackColor = System.Drawing.Color.Transparent;
            this.pbRestore.Image = ((System.Drawing.Image)(resources.GetObject("pbRestore.Image")));
            this.pbRestore.Location = new System.Drawing.Point(27, 23);
            this.pbRestore.Name = "pbRestore";
            this.pbRestore.Size = new System.Drawing.Size(76, 73);
            this.pbRestore.TabIndex = 2;
            this.pbRestore.TabStop = false;
            this.pbRestore.Click += new System.EventHandler(this.pbRestore_Click);
            // 
            // lblRestore
            // 
            this.lblRestore.AutoSize = true;
            this.lblRestore.BackColor = System.Drawing.Color.Transparent;
            this.lblRestore.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRestore.Location = new System.Drawing.Point(10, 106);
            this.lblRestore.Name = "lblRestore";
            this.lblRestore.Size = new System.Drawing.Size(96, 19);
            this.lblRestore.TabIndex = 0;
            this.lblRestore.Text = "Stock Balance ";
            // 
            // pnlRestore
            // 
            this.pnlRestore.BackColor = System.Drawing.Color.LightSeaGreen;
            this.pnlRestore.Controls.Add(this.pbAccounts);
            this.pnlRestore.Controls.Add(this.lblAccounts);
            this.pnlRestore.Location = new System.Drawing.Point(452, 534);
            this.pnlRestore.Name = "pnlRestore";
            this.pnlRestore.Size = new System.Drawing.Size(125, 122);
            this.pnlRestore.TabIndex = 36;
            // 
            // pbAccounts
            // 
            this.pbAccounts.BackColor = System.Drawing.Color.Transparent;
            this.pbAccounts.Image = ((System.Drawing.Image)(resources.GetObject("pbAccounts.Image")));
            this.pbAccounts.Location = new System.Drawing.Point(24, 27);
            this.pbAccounts.Name = "pbAccounts";
            this.pbAccounts.Size = new System.Drawing.Size(76, 73);
            this.pbAccounts.TabIndex = 2;
            this.pbAccounts.TabStop = false;
            this.pbAccounts.Click += new System.EventHandler(this.pbAccounts_Click);
            // 
            // lblAccounts
            // 
            this.lblAccounts.AutoSize = true;
            this.lblAccounts.BackColor = System.Drawing.Color.Transparent;
            this.lblAccounts.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAccounts.Location = new System.Drawing.Point(9, 103);
            this.lblAccounts.Name = "lblAccounts";
            this.lblAccounts.Size = new System.Drawing.Size(97, 19);
            this.lblAccounts.TabIndex = 0;
            this.lblAccounts.Text = "Purchas Histry";
            // 
            // pnlReports
            // 
            this.pnlReports.BackColor = System.Drawing.Color.DarkMagenta;
            this.pnlReports.Controls.Add(this.pbReports);
            this.pnlReports.Controls.Add(this.lblReports);
            this.pnlReports.Controls.Add(this.lblCopyright);
            this.pnlReports.Location = new System.Drawing.Point(321, 277);
            this.pnlReports.Name = "pnlReports";
            this.pnlReports.Size = new System.Drawing.Size(257, 239);
            this.pnlReports.TabIndex = 35;
            // 
            // pbReports
            // 
            this.pbReports.BackColor = System.Drawing.Color.Transparent;
            this.pbReports.Image = ((System.Drawing.Image)(resources.GetObject("pbReports.Image")));
            this.pbReports.Location = new System.Drawing.Point(35, 30);
            this.pbReports.Name = "pbReports";
            this.pbReports.Size = new System.Drawing.Size(197, 184);
            this.pbReports.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbReports.TabIndex = 2;
            this.pbReports.TabStop = false;
            this.pbReports.Click += new System.EventHandler(this.pbReports_Click);
            // 
            // lblReports
            // 
            this.lblReports.AutoSize = true;
            this.lblReports.BackColor = System.Drawing.Color.Transparent;
            this.lblReports.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReports.Location = new System.Drawing.Point(23, 220);
            this.lblReports.Name = "lblReports";
            this.lblReports.Size = new System.Drawing.Size(70, 19);
            this.lblReports.TabIndex = 0;
            this.lblReports.Text = "Buy Items";
            // 
            // lblCopyright
            // 
            this.lblCopyright.AutoSize = true;
            this.lblCopyright.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCopyright.Location = new System.Drawing.Point(31, 184);
            this.lblCopyright.Name = "lblCopyright";
            this.lblCopyright.Size = new System.Drawing.Size(183, 21);
            this.lblCopyright.TabIndex = 2;
            this.lblCopyright.Text = "Copyright @ ONIR, 2014";
            // 
            // lbl2name
            // 
            this.lbl2name.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2name.Location = new System.Drawing.Point(927, 51);
            this.lbl2name.Name = "lbl2name";
            this.lbl2name.Size = new System.Drawing.Size(79, 37);
            this.lbl2name.TabIndex = 30;
            // 
            // lbluname_main
            // 
            this.lbluname_main.Location = new System.Drawing.Point(925, 21);
            this.lbluname_main.Name = "lbluname_main";
            this.lbluname_main.Size = new System.Drawing.Size(79, 37);
            this.lbluname_main.TabIndex = 29;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox13.Image")));
            this.pictureBox13.Location = new System.Drawing.Point(1086, 33);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(52, 45);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 27;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.Click += new System.EventHandler(this.pictureBox13_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(1009, 29);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(54, 53);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 26;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.panel10.Controls.Add(this.pictureBox8);
            this.panel10.Controls.Add(this.label10);
            this.panel10.Location = new System.Drawing.Point(637, 534);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(256, 122);
            this.panel10.TabIndex = 9;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(95, 25);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(76, 73);
            this.pictureBox8.TabIndex = 2;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Click += new System.EventHandler(this.pictureBox8_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(6, 103);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(96, 19);
            this.label10.TabIndex = 0;
            this.label10.Text = "Selling History";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.DeepPink;
            this.panel9.Controls.Add(this.pictureBox7);
            this.panel9.Controls.Add(this.label9);
            this.panel9.Location = new System.Drawing.Point(637, 396);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(125, 122);
            this.panel9.TabIndex = 12;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(27, 27);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(76, 73);
            this.pictureBox7.TabIndex = 2;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Click += new System.EventHandler(this.pictureBox7_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(6, 103);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 19);
            this.label9.TabIndex = 0;
            this.label9.Text = "Notification";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Green;
            this.panel5.Controls.Add(this.pictureBox3);
            this.panel5.Controls.Add(this.label5);
            this.panel5.Location = new System.Drawing.Point(151, 396);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(125, 120);
            this.panel5.TabIndex = 20;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Enabled = false;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(27, 27);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(75, 68);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 101);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 19);
            this.label5.TabIndex = 0;
            this.label5.Text = "Chat";
            // 
            // pnlLogo
            // 
            this.pnlLogo.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlLogo.Controls.Add(this.lblFaltu);
            this.pnlLogo.Controls.Add(this.pictureBox1);
            this.pnlLogo.Location = new System.Drawing.Point(917, 134);
            this.pnlLogo.Name = "pnlLogo";
            this.pnlLogo.Size = new System.Drawing.Size(256, 122);
            this.pnlLogo.TabIndex = 14;
            // 
            // lblFaltu
            // 
            this.lblFaltu.AutoSize = true;
            this.lblFaltu.BackColor = System.Drawing.Color.Transparent;
            this.lblFaltu.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFaltu.ForeColor = System.Drawing.Color.Black;
            this.lblFaltu.Location = new System.Drawing.Point(42, 95);
            this.lblFaltu.Name = "lblFaltu";
            this.lblFaltu.Size = new System.Drawing.Size(182, 30);
            this.lblFaltu.TabIndex = 2;
            this.lblFaltu.Text = "COMPANY LOGO";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(6, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(250, 122);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // pnlBackup
            // 
            this.pnlBackup.BackColor = System.Drawing.Color.DeepPink;
            this.pnlBackup.Controls.Add(this.pbBackup);
            this.pnlBackup.Controls.Add(this.lblBackup);
            this.pnlBackup.Location = new System.Drawing.Point(917, 268);
            this.pnlBackup.Name = "pnlBackup";
            this.pnlBackup.Size = new System.Drawing.Size(132, 122);
            this.pnlBackup.TabIndex = 11;
            // 
            // pbBackup
            // 
            this.pbBackup.BackColor = System.Drawing.Color.Transparent;
            this.pbBackup.Image = ((System.Drawing.Image)(resources.GetObject("pbBackup.Image")));
            this.pbBackup.Location = new System.Drawing.Point(27, 27);
            this.pbBackup.Name = "pbBackup";
            this.pbBackup.Size = new System.Drawing.Size(76, 73);
            this.pbBackup.TabIndex = 2;
            this.pbBackup.TabStop = false;
            this.pbBackup.Click += new System.EventHandler(this.pbBackup_Click);
            // 
            // lblBackup
            // 
            this.lblBackup.AutoSize = true;
            this.lblBackup.BackColor = System.Drawing.Color.Transparent;
            this.lblBackup.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBackup.Location = new System.Drawing.Point(6, 103);
            this.lblBackup.Name = "lblBackup";
            this.lblBackup.Size = new System.Drawing.Size(56, 19);
            this.lblBackup.TabIndex = 0;
            this.lblBackup.Text = "Camara";
            // 
            // pnlAttendance
            // 
            this.pnlAttendance.BackColor = System.Drawing.Color.DarkOrange;
            this.pnlAttendance.Controls.Add(this.pbAttendance);
            this.pnlAttendance.Controls.Add(this.lblAttendance);
            this.pnlAttendance.Location = new System.Drawing.Point(20, 396);
            this.pnlAttendance.Name = "pnlAttendance";
            this.pnlAttendance.Size = new System.Drawing.Size(125, 122);
            this.pnlAttendance.TabIndex = 6;
            // 
            // pbAttendance
            // 
            this.pbAttendance.BackColor = System.Drawing.Color.Transparent;
            this.pbAttendance.Enabled = false;
            this.pbAttendance.Image = ((System.Drawing.Image)(resources.GetObject("pbAttendance.Image")));
            this.pbAttendance.Location = new System.Drawing.Point(27, 27);
            this.pbAttendance.Name = "pbAttendance";
            this.pbAttendance.Size = new System.Drawing.Size(76, 73);
            this.pbAttendance.TabIndex = 2;
            this.pbAttendance.TabStop = false;
            this.pbAttendance.Click += new System.EventHandler(this.pbAttendance_Click);
            // 
            // lblAttendance
            // 
            this.lblAttendance.AutoSize = true;
            this.lblAttendance.BackColor = System.Drawing.Color.Transparent;
            this.lblAttendance.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAttendance.Location = new System.Drawing.Point(10, 103);
            this.lblAttendance.Name = "lblAttendance";
            this.lblAttendance.Size = new System.Drawing.Size(71, 19);
            this.lblAttendance.TabIndex = 0;
            this.lblAttendance.Text = "New  Staff";
            // 
            // pnlEmployees
            // 
            this.pnlEmployees.BackColor = System.Drawing.Color.Red;
            this.pnlEmployees.Controls.Add(this.pbEmployees);
            this.pnlEmployees.Controls.Add(this.lblEmployees);
            this.pnlEmployees.Location = new System.Drawing.Point(151, 532);
            this.pnlEmployees.Name = "pnlEmployees";
            this.pnlEmployees.Size = new System.Drawing.Size(125, 122);
            this.pnlEmployees.TabIndex = 5;
            // 
            // pbEmployees
            // 
            this.pbEmployees.BackColor = System.Drawing.Color.Transparent;
            this.pbEmployees.Enabled = false;
            this.pbEmployees.Image = ((System.Drawing.Image)(resources.GetObject("pbEmployees.Image")));
            this.pbEmployees.Location = new System.Drawing.Point(27, 27);
            this.pbEmployees.Name = "pbEmployees";
            this.pbEmployees.Size = new System.Drawing.Size(76, 73);
            this.pbEmployees.TabIndex = 2;
            this.pbEmployees.TabStop = false;
            this.pbEmployees.Click += new System.EventHandler(this.pbEmployees_Click);
            // 
            // lblEmployees
            // 
            this.lblEmployees.AutoSize = true;
            this.lblEmployees.BackColor = System.Drawing.Color.Transparent;
            this.lblEmployees.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmployees.Location = new System.Drawing.Point(6, 103);
            this.lblEmployees.Name = "lblEmployees";
            this.lblEmployees.Size = new System.Drawing.Size(54, 19);
            this.lblEmployees.TabIndex = 0;
            this.lblEmployees.Text = "Dealers";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.pnlproduct);
            this.groupBox1.Controls.Add(this.panel4);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(13, 106);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(287, 565);
            this.groupBox1.TabIndex = 32;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "ADMIN AREA";
            // 
            // pnlproduct
            // 
            this.pnlproduct.BackColor = System.Drawing.Color.Crimson;
            this.pnlproduct.Controls.Add(this.pbproduct);
            this.pnlproduct.Controls.Add(this.lblStudents);
            this.pnlproduct.Location = new System.Drawing.Point(12, 31);
            this.pnlproduct.Name = "pnlproduct";
            this.pnlproduct.Size = new System.Drawing.Size(256, 122);
            this.pnlproduct.TabIndex = 3;
            // 
            // pbproduct
            // 
            this.pbproduct.BackColor = System.Drawing.Color.Transparent;
            this.pbproduct.Enabled = false;
            this.pbproduct.Image = ((System.Drawing.Image)(resources.GetObject("pbproduct.Image")));
            this.pbproduct.Location = new System.Drawing.Point(85, 23);
            this.pbproduct.Name = "pbproduct";
            this.pbproduct.Size = new System.Drawing.Size(76, 73);
            this.pbproduct.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbproduct.TabIndex = 4;
            this.pbproduct.TabStop = false;
            this.pbproduct.Click += new System.EventHandler(this.pbproduct_Click);
            // 
            // lblStudents
            // 
            this.lblStudents.AutoSize = true;
            this.lblStudents.BackColor = System.Drawing.Color.Transparent;
            this.lblStudents.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStudents.Location = new System.Drawing.Point(6, 103);
            this.lblStudents.Name = "lblStudents";
            this.lblStudents.Size = new System.Drawing.Size(57, 19);
            this.lblStudents.TabIndex = 0;
            this.lblStudents.Text = "Product";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel4.Controls.Add(this.pictureBox2);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Location = new System.Drawing.Point(138, 161);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(128, 123);
            this.panel4.TabIndex = 19;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Enabled = false;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(28, 30);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(65, 65);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 19);
            this.label4.TabIndex = 0;
            this.label4.Text = "Mail";
            // 
            // lblMainTitle
            // 
            this.lblMainTitle.AutoSize = true;
            this.lblMainTitle.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMainTitle.Location = new System.Drawing.Point(28, 15);
            this.lblMainTitle.Name = "lblMainTitle";
            this.lblMainTitle.Size = new System.Drawing.Size(295, 37);
            this.lblMainTitle.TabIndex = 0;
            this.lblMainTitle.Text = "Janaka Motors (pvt) Ltd";
            // 
            // Clock
            // 
            this.Clock.BackColor = System.Drawing.Color.White;
            this.Clock.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clock.Location = new System.Drawing.Point(637, 134);
            this.Clock.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.Clock.Name = "Clock";
            this.Clock.Size = new System.Drawing.Size(256, 253);
            this.Clock.TabIndex = 15;
            // 
            // txtunamemain
            // 
            this.txtunamemain.Location = new System.Drawing.Point(651, 157);
            this.txtunamemain.Name = "txtunamemain";
            this.txtunamemain.Size = new System.Drawing.Size(71, 35);
            this.txtunamemain.TabIndex = 31;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1203, 733);
            this.Controls.Add(this.pnlRightOptions);
            this.Controls.Add(this.pnlMain);
            this.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.Name = "frmMain";
            this.Text = "Main";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.frmMain_MouseMove);
            this.pnlRightOptions.ResumeLayout(false);
            this.pnlRightMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHome)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogout)).EndInit();
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.pnlSearch.ResumeLayout(false);
            this.pnlSearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSearch)).EndInit();
            this.pnlAccounts.ResumeLayout(false);
            this.pnlAccounts.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbRestore)).EndInit();
            this.pnlRestore.ResumeLayout(false);
            this.pnlRestore.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAccounts)).EndInit();
            this.pnlReports.ResumeLayout(false);
            this.pnlReports.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbReports)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.pnlLogo.ResumeLayout(false);
            this.pnlLogo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlBackup.ResumeLayout(false);
            this.pnlBackup.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbBackup)).EndInit();
            this.pnlAttendance.ResumeLayout(false);
            this.pnlAttendance.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAttendance)).EndInit();
            this.pnlEmployees.ResumeLayout(false);
            this.pnlEmployees.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbEmployees)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.pnlproduct.ResumeLayout(false);
            this.pnlproduct.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbproduct)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pbExit;
        private System.Windows.Forms.PictureBox pbHome;
        private System.Windows.Forms.PictureBox pbLogout;
        private System.Windows.Forms.Panel pnlRightOptions;
        private System.Windows.Forms.Panel pnlRightMain;
        private System.Windows.Forms.Timer RightOptions;
        private System.Windows.Forms.Timer FirstColumn;
        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlSearch;
        private System.Windows.Forms.PictureBox pbSearch;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.Panel pnlRestore;
        private System.Windows.Forms.PictureBox pbRestore;
        private System.Windows.Forms.Label lblRestore;
        private System.Windows.Forms.Panel pnlReports;
        private System.Windows.Forms.PictureBox pbReports;
        private System.Windows.Forms.Label lblReports;
        private System.Windows.Forms.Label lbl2name;
        private System.Windows.Forms.Label lbluname_main;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label4;
        private CalendarClock.CalendarClock Clock;
        private System.Windows.Forms.Panel pnlLogo;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblFaltu;
        private System.Windows.Forms.Panel pnlBackup;
        private System.Windows.Forms.PictureBox pbBackup;
        private System.Windows.Forms.Label lblBackup;
        private System.Windows.Forms.Panel pnlAccounts;
        private System.Windows.Forms.PictureBox pbAccounts;
        private System.Windows.Forms.Label lblAccounts;
        private System.Windows.Forms.Panel pnlAttendance;
        private System.Windows.Forms.PictureBox pbAttendance;
        private System.Windows.Forms.Label lblAttendance;
        private System.Windows.Forms.Panel pnlEmployees;
        private System.Windows.Forms.PictureBox pbEmployees;
        private System.Windows.Forms.Label lblEmployees;
        private System.Windows.Forms.Panel pnlproduct;
        private System.Windows.Forms.Label lblStudents;
        private System.Windows.Forms.Label lblCopyright;
        private System.Windows.Forms.Label lblMainTitle;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtunamemain;
        private System.Windows.Forms.PictureBox pbproduct;
    }
}