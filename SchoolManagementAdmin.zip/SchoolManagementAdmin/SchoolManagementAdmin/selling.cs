﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SchoolManagementAdmin
{
    public partial class selling : Form
    {
        public selling(string uname)
        {
            InitializeComponent();
            txt_uname.Text = uname;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            frmMain frm = new frmMain(txt_uname.Text);
            frm.Show();
        }

        private void save_data()
        {
            int item_id, price, qty1, discount, total5;
            DateTime date1 = DateTime.Parse(dateTimePicker1.Text);
           
            item_id = Convert.ToInt32(txt_id.Text);
            price = Convert.ToInt32(txt_unit_price.Text);
            qty1 = Convert.ToInt32(txt_qty.Text);
            discount = Convert.ToInt32(lbl_discount.Text);
            total5 = Convert.ToInt32(lbl_total.Text);


            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();

                cmd = new SqlCommand("insert into selling_history (item_id,item_name,price,quantity,payment_type,discount,total,date)values("
                                                                                                                    + item_id + ",'"
                                                                                                                    + cmbo_item_name.Text + "',"
                                                                                                                    + price + ","
                                                                                                                    + qty1 + ",'"
                                                                                                                    + cmbo_payment.Text + "',"
                                                                                                                    + discount +", "
                                                                                                                    + total5 + ",'"+date1+"')", con);

                cmd.ExecuteNonQuery();

                con.Close();
                //MessageBox.Show("saved");


            }
            catch (SqlException ee)
            {
                MessageBox.Show("error" + ee);
            }
        }

        private void update_amount()
        {
            try
            {

                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("update stock_table set remaining ='" + lbl_item_left.Text + "' where item_id= '" + txt_id.Text + "'", con);
                cmd.ExecuteNonQuery();
                con.Close();
                //MessageBox.Show("done");
            }

            catch (SqlException error)
            {
                MessageBox.Show("error" + error);
            }

        }
        private void send_grid()
        {
            int n = dataGridView1.Rows.Add();
            dataGridView1.Rows[n].Cells[0].Value = txt_uname.Text;
            dataGridView1.Rows[n].Cells[1].Value = cmbo_item_name.Text;
            dataGridView1.Rows[n].Cells[2].Value = txt_id.Text;
            dataGridView1.Rows[n].Cells[3].Value = txt_unit_price.Text;
            dataGridView1.Rows[n].Cells[4].Value = txt_discount.Text;
            dataGridView1.Rows[n].Cells[5].Value = txt_qty.Text;
            dataGridView1.Rows[n].Cells[6].Value = txt_waranty.Text;
            dataGridView1.Rows[n].Cells[7].Value = lbl_total.Text;
            
        }

        private void load_left()
    {

        try
        {
            SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd = new SqlCommand("select * from stock_table where item_id='" + txt_id.Text + "'", con);
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {

                txt_left.Text = dr["remaining"].ToString();
            }
           // MessageBox.Show("remaining loaded");
        }
        catch (SqlException ee)
        {
            MessageBox.Show("" + ee);
        }
    }
        private void button12_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txt_uname_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void selling_Load(object sender, EventArgs e)
        {
            timer1.Start();
            
            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("select * from product_table", con);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    cmbo_item_name.Items.Add(dr["name"].ToString());
                }
            }
            catch (SqlException ee)
            {
                MessageBox.Show("" + ee);
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime DateTime = DateTime.Now;
            lbl_time.Text = DateTime.ToString();
        }

        private void cmbo_item_name_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("select * from product_table where name='" + cmbo_item_name.Text + "';", con);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {

                    txt_id.Text = dr["id"].ToString();
                    txt_unit_price.Text = dr["price"].ToString();
                    //txt_qty.Text = dr[""].ToString();
                    txt_discount.Text = dr["discount"].ToString();
                    txt_condi.Text = dr["condition"].ToString();
                    txt_waranty.Text = dr["waranty"].ToString();
                    txt_color.Text = dr["colour"].ToString();
                    txt_make.Text = dr["make"].ToString();

                }
            }
            catch (SqlException ee)
            {
                MessageBox.Show("" + ee);
            }
            load_left();
        }

        private void txt_qty_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == 13)
            {
                int price, amount, total, discount, discount2, gtotal, total2, totalg,item,qty,item_left;
                try
                {
                    price = Convert.ToInt32(txt_unit_price.Text);
                    amount = Convert.ToInt32(txt_qty.Text);
                    discount = Convert.ToInt32(txt_discount.Text);
                    total2 = Convert.ToInt32(lbl_total1.Text);
                    item = Convert.ToInt32(txt_left.Text);
                    qty = Convert.ToInt32(txt_qty.Text);


                    total = price * amount;
                    first_total.Text = total.ToString();
                    discount2 = total * discount / 100;
                    lbl_discount.Text = discount2.ToString();
                    gtotal = total - discount2;
                    lbl_total.Text = gtotal.ToString();
                    totalg = gtotal + total2;
                    lbl_total1.Text = totalg.ToString();
                    item_left = item - qty;
                    lbl_item_left.Text = item_left.ToString();
                    //button14.Focus();
                    

                }

                catch (SqlException ee)
                {
                    MessageBox.Show("please enter the amount and price " + ee);

                }
                update_amount();
                send_grid();
                save_data();
                cash_amount.Focus();
            }
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            cmbo_item_name.Text = "";
            txt_id.Text = "";
            txt_unit_price.Text = "";
            txt_discount.Text = "";
            txt_left.Text = "";
            txt_qty.Text = "";
            txt_condi.Text = "";
            txt_waranty.Text = "";
            txt_color.Text = "";
            txt_make.Text = "";
            cmbo_payment.Text = "";
            cash_amount.Text = "";
            lbl_balance.Text = "";
            first_total.Text = "";
            lbl_discount.Text = "";
            lbl_total.Text = "";
            lbl_item_left.Text = "";
            lbl_total1.Text = "";
            dataGridView1.Rows.Clear();


        }

        private void button14_Click(object sender, EventArgs e)
        {

        }

        private void cash_amount_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == 13)

                if (cash_amount.Text != "")
                {
                    int cash, total,balance;
                    cash = Convert.ToInt32(cash_amount.Text);
                    total = Convert.ToInt32(lbl_total1.Text);

                    balance = cash - total;
                    lbl_balance.Text = balance.ToString();


                    btn_clear.Focus();

                }
            else

                {
                    DialogResult Confirmation;
                    Confirmation = MessageBox.Show("Cash Amount Is Empty Do You Like To Add Another Item", "Remove", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (Confirmation == DialogResult.Yes)
                    {
                        cmbo_item_name.Text = "";
                        txt_id.Text = "";
                        txt_unit_price.Text = "";
                        txt_discount.Text = "";
                        txt_left.Text = "";
                        txt_qty.Text = "";
                        txt_condi.Text = "";
                        txt_waranty.Text = "";
                        txt_color.Text = "";
                        txt_make.Text = "";
                        cmbo_payment.Text = "";
                        cash_amount.Text = "";
                        lbl_balance.Text = "";
                        first_total.Text = "";
                        lbl_discount.Text = "";
                       lbl_total.Text = "";
                        lbl_item_left.Text = "";
                    }
                    else
                    {
                        cash_amount.Focus();
                    }
        }
        }
    }
}
