﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SchoolManagementAdmin
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void login_Load(object sender, EventArgs e)
        {
            timer3.Start();
        }

        private void label1_MouseHover(object sender, EventArgs e)
        {
            label1.ForeColor = System.Drawing.Color.Chartreuse;
        }

        private void label1_MouseLeave(object sender, EventArgs e)
        {
            label1.ForeColor = System.Drawing.Color.Blue;
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {

            string uname = txtuname.Text;
            string pwd = txtpwd.Text;



            if (txtuname.Text == ""|| txtpwd.Text == "")
            {

                picboxwhite.BringToFront();
                lbl_error.BringToFront();
                btn_ok.BringToFront();
                lbl_error.Text = "Please Enter Both UserName And Password ........!";
                txtpwd.Enabled = false;
                txtuname.Enabled = false;
            }
            else
            {
                this.timer1.Start();
                pictureBox3.BringToFront();
            }





        }

        private void btn_ok_Click(object sender, EventArgs e)
        {
           picboxwhite.SendToBack();
           lbl_error.SendToBack();
           btn_ok.SendToBack();
           picboxblak.BringToFront();
           txtpwd.Enabled = true;
           txtuname.Enabled = true;
           txtuname.Focus();

           
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.progressBar1.Increment(1);
            if (progressBar1.Value >= 75)
            {
                lbl_error.Text = "Wait For A moment ";
            }
            if (progressBar1.Value == 100)
            {

                try
                {

                    SqlConnection cn = new SqlConnection("Data Source=.\\SQLexpress;Initial Catalog=janaka_db;Integrated Security=True");
                    cn.Open();
                    
                    SqlCommand cmd = new SqlCommand("Select * from staff_table where uname='" + txtuname.Text + "' and pwd = '" + txtpwd.Text + "';", cn);
                    SqlDataReader dr;
                    dr = cmd.ExecuteReader();
                    int count = 0;

                    while (dr.Read())
                    {
                        count = count + 1;
                    }

                    if (count == 0)
                    {
                        picboxwhite.BringToFront();
                        lbl_error.BringToFront();
                        lbl_error.Text = "Invalid Credential ........!";
                        pictureBox3.SendToBack();
                        button1.BringToFront();
                    }
                    else 
                    {

                        this.timer2.Start();
                        this.progressBar2.Increment(1);
                        if (progressBar2.Value >= 20)
                        {
                            label8.BringToFront();

                            label8.Text = "Hello " + txtuname.Text + " Login Complete please wait For A Moment.. ";
                        }
                        if (progressBar2.Value == 100)
                        {
                            frmMain frm = new frmMain(txtuname.Text);
                            frm.Show();
                            this.Hide();
                            timer1.Stop();
                            timer2.Stop();
                        }

                    }
                }
                catch (SqlException ee)
                {
                    MessageBox.Show("" + ee);
                }

            }
        }

        private void btn_ok2_Click(object sender, EventArgs e)
        {
            picboxblak.BringToFront();
            picboxwhite.SendToBack();
            lbl_error.SendToBack();
            btn_ok.SendToBack();
            //picboxblak.BringToFront();
            txtpwd.Enabled = true;
            txtuname.Enabled = true;
            txtuname.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //picboxblak.BringToFront();
            login frm = new login();
            frm.Show();
            this.Hide();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            product frm = new product("admin");
            frm.Show();
            this.Hide();
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            DateTime DateTime = DateTime.Now;
            lbltime.Text = DateTime.ToString();

            
        }

        private void txtpwd_KeyDown(object sender, KeyEventArgs e)
        {
           if (e.KeyValue == 13)
           {
               

               string uname = txtuname.Text;
               string pwd = txtpwd.Text;

               if (txtuname.Text == "" || txtpwd.Text == "")
               {

                   picboxwhite.BringToFront();
                   lbl_error.BringToFront();
                   btn_ok.BringToFront();
                   lbl_error.Text = "Please Enter Both UserName And Password ........!";
                   txtpwd.Enabled = false;
                   txtuname.Enabled = false;
               }
               else
               {
                   this.timer1.Start();
                   pictureBox3.BringToFront();
               }




           }
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
        }

        private void picboxblak_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
          
           
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            picboxblak.BringToFront();
            login frm = new login();
            frm.Show();
            this.Hide();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            product frm = new product("admin");
            frm.Show();
        }

        private void button2_Click_2(object sender, EventArgs e)
        {
            frmMain frm = new frmMain("admin");
            frm.Show();
        }
    }
}
